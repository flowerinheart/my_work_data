# Meridian ERP 发票新建链路 · 测试验证框架

> **Skill：** `meridian-invoice-test-plan`（`work/week02-skills/my-test-plan-skill.md`）  
> **依据：** `work/week01/test-task-template.md` Context / Constraint / AC  
> **自检 Rules：** `work/week01b-rules/testing-rules.md`（RULE-TEST-001～016）+ `work/week01b-rules/data-and-db-rules.md`（RULE-DB-001～005）  
> **输出物：** 测试步骤 + 验证标准框架（不写自动化脚本、不改源码/表结构）

---

## 6.1 测试范围

**模块：** Accounting / Invoices（发票新建）  
**链路：** 列表 → 新建表单（`form.id` 为空）→ 填写 → POST 保存 → **302** 跳转详情页 → 详情字段与 DB 核对  
**截止点：** 保存成功后详情页验证完毕（含 flash、UUID、主表/分项落库）。  
**明确不测：** edit、delete、payment（含详情页 Record Payment 提交、付款后 `PARTIAL`/`PAID`）。详情页上 Edit / Delete / Record Payment **仅允许观察权限可见性**，不得走这些提交链路。

**入口与 URL（来自 Context，表单 POST 非 JSON API）：**

| 步骤 | 方法 | URL | PermissionType |
|------|------|-----|----------------|
| 列表 | GET | `/accounting/invoices` | `ACCOUNTING_VIEW` |
| 新建表单 | GET | `/accounting/invoices/new` | `ACCOUNTING_EDIT` |
| 保存 | POST | `/accounting/invoices/save` | `ACCOUNTING_EDIT` |
| 详情 | GET | `/accounting/invoices/{uuid}` | `ACCOUNTING_VIEW` |

**保存成功 HTTP 期望：** POST `/save` → **302**，`Location` = `/accounting/invoices/{uuid}`（不是 200 JSON）。  
**无权限 HTTP 期望：** Spring Security **403** + 模板 `errors/403`（不是 list 页）。  
**新建业务期望：** `form.id == null` 时系统生成 `invoiceNumber = INV-{4位序号}`（匹配 `INV-\d{4}`），`status = DRAFT`。新建表单不可手填发票号。

---

## 6.2 测试前置

### 环境

| 项 | 值 | 说明 |
|----|----|------|
| Web | 默认可访问 `http://localhost:8080`（以实际部署为准） | 登录页 `/login` |
| DB | H2 控制台 `/h2-console`；JDBC `jdbc:h2:file:./data/erpdb`；用户 `sa`；密码空 | 来自项目 README / `application.properties` |
| 应用配置 | `hibernate.globally_quoted_identifiers=true` | SELECT 若列名报错，记录 **实测物理列名**，标「DB 列名实测待确认」，不得编造列名 |
| CSRF | 应用启用 CSRF（仅 `/h2-console/**` 忽略） | **绕过前端的 POST 必须带同一会话 CSRF**；缺 CSRF 的 403 **不得**记为权限 403 |

### 账号（PermissionType，不是 InvoiceStatus）

| 角色 | 账号 | 权限 | 用途 |
|------|------|------|------|
| 正向主账号 | `admin@erp.com` / `Admin@1234` | `ACCOUNTING_VIEW` + `ACCOUNTING_EDIT` | 正向、金额、To-Be 负向、幂等 |
| 对照 A（VIEW-only） | **待确认：须临时创建** | 仅 `ACCOUNTING_VIEW`，无 `ACCOUNTING_EDIT` | 权限 UI + API |
| 对照 B（无 Accounting） | 种子账号可用：`mehedi.emp@erp.com` / `Admin@1234`（Employee） | 无 `ACCOUNTING_VIEW`、无 `ACCOUNTING_EDIT` | 权限 UI + API |

**对照 A 缺口：** 种子角色矩阵中 Accountant / Super Admin 同时具备 VIEW+EDIT，**没有**现成「仅 VIEW」账号。须用 admin 在 `/settings` 建临时用户或改角色矩阵。创建后记录：邮箱、角色、权限勾选截图。未创建前本框架仍写出对照 A 步骤，执行阻塞项标「权限账号待确认」。

### 数据准备

- `customerName` 使用可追踪唯一值：`AutoTest_yyyyMMdd_HHmmss`（RULE-DB-001），禁止固定 `TestCustomer`。
- 至少 1 条有效分项：`description` 非空；正向建议 `quantity > 0` 且 `unitPrice > 0`。
- 新建：隐藏域 `id` 为空（`form.id == null`）。
- 行项目规则：`description` 为空的行跳过、不入库。
- 表单默认约 5 行空分项槽位；只填需要的行。

### 执行前基线（每个会触发 save 的用例都要取）

在 H2 执行并记入执行记录：

```sql
SELECT COUNT(*) AS cnt_invoices FROM acc_invoices;
SELECT COUNT(*) AS cnt_items FROM acc_invoice_items;
SELECT MAX(invoice_number) AS max_invoice_number FROM acc_invoices;
```

记：`N0`（主表行数）、`M0`（分项行数）、`max_invoice_number`。负向「不得新增」用 `N0`/`M0` 对照；正向期望主表 `N0+1`、分项 `M0+M`（`M` = 有效分项数）。

### 金额公式（As-Is，不得改写）

- `quantity ≤ 0` 时按 **0** 处理
- `lineTotal = unitPrice × quantity`
- `subtotal` = 该发票所有**有效行** lineTotal 之和
- `taxAmount = subtotal × taxRate ÷ 100`（保留 2 位小数，`RoundingMode.HALF_UP`）
- `total = max(subtotal + taxAmount - discount, 0)`

### 金额对照规则（不得擅自改写）

| 阶段 | 对照关系 | 不一致时 |
|------|----------|----------|
| 保存前 | 手算（HALF_UP）= Alpine 预览（`#sub-out` / `#tax-out` / `#total-out`） | 记缺陷 |
| 保存后 | 详情展示 = DB 落库 | 记缺陷 |
| 跨阶段 | 保存前记录的 Alpine vs 保存后 DB | 记缺陷 |

**禁止：** 跳过页面核对、单方面写「以 DB 为准」判 pass。三处任一不一致都记缺陷，并保留三组数值。

---

## 6.3 测试步骤（正向主路径）

适用场景：INV-CREATE-001（账号：`admin@erp.com`）。每步须留下页面 / HTTP / DB 中至少两类证据。

### 步骤 0 — 基线

1. 登录主账号。  
2. 执行 §6.2 基线 SQL，记录 `N0`、`M0`、`max_invoice_number`。  
3. **检查点：** 查询成功，数值写入执行记录。  
4. **失败证据：** SQL 原文、结果截图、时间戳。

### 步骤 1 — 列表（GET `/accounting/invoices`）

1. 打开 Accounting / Invoices 列表。  
2. **预期：** HTTP **200**（非 403）；页面标题 Invoices；可见可用 **「+ New Invoice」**（依赖 `ACCOUNTING_EDIT`）。  
3. **检查点：** 状态码；按钮可见且 `href` 指向 `/accounting/invoices/new`；侧栏 Accounting 可见。  
4. **失败证据：** 响应状态、列表截图、账号权限。  
5. **不测：** 列表上的 Edit / Delete 点击提交。

### 步骤 2 — 进入新建（GET `/accounting/invoices/new`）

1. 点击「+ New Invoice」。  
2. **预期：** HTTP **200**；页标题 New Invoice；隐藏域 `id` 为空；**无**可编辑发票号输入（新建不可手填）；可见 **Save Invoice**。  
3. **检查点：** 非 403、非 `errors/403`；`customerName` 带 HTML `required`；quantity / unitPrice / taxRate / discount 带 `min="0"`。  
4. **失败证据：** URL、状态码、新建页截图。

### 步骤 3 — 填表 + 保存前手算与 Alpine

**推荐数据集 A（整数，写入执行记录）：**

| 字段 | 值 |
|------|-----|
| customerName | `AutoTest_20260910_2022`（按执行时刻改时间戳） |
| issueDate | 当天或过去日（非未来） |
| dueDate | ≥ issueDate |
| 行1 description | `Widget A` |
| 行1 quantity | `2` |
| 行1 unitPrice | `100.00` |
| 行2 description | 空（用于确认空行不入库，可与 INV-CREATE-002 合并观察） |
| taxRate | `10` |
| discount | `5.00` |
| notes | `create-path-notes` |

**手算过程（HALF_UP）：**

1. 行1 `lineTotal = 100.00 × 2 = 200.00`；空行不计入。  
2. `subtotal = 200.00`  
3. `taxAmount = 200.00 × 10 ÷ 100 = 20.00`（已是 2 位）  
4. `total = max(200.00 + 20.00 − 5.00, 0) = 215.00`

**保存前 Alpine（form 底部）：** 记录 `#sub-out`、`#tax-out`、`#disc-out`、`#total-out` 及行 Line Total。  
**本步裁决：** Alpine = 手算，否则记缺陷，**仍继续保存**以便对照 DB（跨阶段）。  
**失败证据：** 手算底稿、Alpine 截图。

### 步骤 4 — 保存（POST `/accounting/invoices/save`）

1. 点击 **Save Invoice**（`multipart/form-urlencoded` 表单，不是 JSON）。  
2. **预期 HTTP：** **302**；`Location` = `/accounting/invoices/{uuid}`（uuid 为新建主键）。  
3. **禁止判 pass：** 仅看到「跳转了」但未记录 302 与 Location uuid。  
4. **失败证据：** 请求方法/URL（可从 DevTools Network 复制，不要写脚本）、状态码、`Location` 头、表单字段（可打码无关 cookie）。

### 步骤 5 — 详情页验证（GET `/accounting/invoices/{uuid}`）

跟随 302 打开详情。

| 核对项 | 预期 |
|--------|------|
| 地址栏 | `/accounting/invoices/{uuid}`，uuid 与 Location 一致 |
| flash | `Invoice INV-xxxx saved.`，其中 `INV-xxxx` 与页内发票号一致（RULE-TEST-015） |
| 发票号 | 匹配 `INV-\d{4}`，系统生成，非手填 |
| 状态 | 页内徽章 **Draft**；DB `status = 'DRAFT'`（新建不得为 SENT/PARTIAL/PAID） |
| 客户/日期/备注 | 与表单一致 |
| 行项目 | 仅有效行；空 description 行不出现 |
| 金额 | Subtotal / Tax / Discount / Total 与手算、与即将查询的 DB 一致 |
| 付款区 | 本链路**不提交付款**；新建后 Amount paid 观察值应为 0（若展示），**不点 Record Payment** |

**失败证据：** 详情全页截图（含 URL、flash、状态、金额）、uuid 抄录。

### 步骤 6 — DB 核对

用地址栏 uuid 查询（列名以 Rules 为准；若 H2 报错则改用实测列名并标注）：

```sql
SELECT id, status, invoice_number, customer_name, issue_date, due_date,
       subtotal, tax_rate, tax_amount, discount, total, notes
FROM acc_invoices
WHERE id = '{uuid}';

SELECT id, invoice_id, description, quantity, unit_price, line_total
FROM acc_invoice_items
WHERE invoice_id = '{uuid}';

SELECT COUNT(*) FROM acc_invoices;
SELECT COUNT(*) FROM acc_invoice_items;
SELECT SUM(line_total) FROM acc_invoice_items WHERE invoice_id = '{uuid}';
```

**断言：**

1. 主表对该 uuid **有且仅有 1 行**；`id` = 地址栏 uuid。  
2. `status = 'DRAFT'`；`invoice_number` 匹配 `INV-\d{4}`，且环境内不与其它行重复。  
3. 主表 count = `N0+1`；分项 count = `M0+1`（仅 1 条有效行时）。  
4. 每条分项 `invoice_id` = 该 uuid。  
5. `SUM(line_total) = acc_invoices.subtotal`。  
6. 金额列不超过 2 位小数；`subtotal/tax_amount/discount/total` = 手算 = 详情展示。  
7. 跨阶段：步骤 3 记录的 Alpine vs 本步 DB，不一致记缺陷。  
8. 用户填写字段：customerName、issueDate、dueDate、notes、taxRate、discount 及行 description/quantity/unitPrice 详情 = DB。

**失败证据：** SELECT 结果、count 前后对比、uuid、手算与三处金额对照表。

---

## 6.4 测试维度说明

### 正向链路

- POST save **302** + `Location=/accounting/invoices/{uuid}`  
- `status=DRAFT`（页内 Draft）  
- `invoiceNumber` 匹配 `INV-\d{4}`，系统生成  
- 地址栏 uuid = `acc_invoices.id` = `acc_invoice_items.invoice_id`  
- 空 description 行不入库；有效行 M 条则分项 +M  
- flash 含同一 `invoiceNumber`

### 权限（必须 UI + API，禁止只写 403）

| 对照 | UI | API | DB |
|------|----|-----|-----|
| VIEW+EDIT | 列表「+ New Invoice」可用；新建页 Save Invoice 可用 | GET `/new` 200；POST `/save` 成功 302 | 允许按正向新增 |
| 仅 VIEW（对照 A） | 列表无可用「+ New Invoice」；不得通过空列表 emptyState 进入新建；若强行打开新建页则无可用 Save Invoice | GET `/new`、POST `/save` → **403** + `errors/403`；列表与**已存在**详情可读 | POST 后两表 count 仍为 `N0`/`M0` |
| 无 VIEW（对照 B） | 列表/详情/新建均不得正常展示发票业务内容 | GET 列表、详情、`/new` 及 POST `/save` 均为 **403** + `errors/403` | 不得读取业务数据、不得写入；count 不变 |

API 绕过前端时：使用对照账号自己的会话 + CSRF。不要用主账号 cookie 测「无权限」。

### 金额

- 公式见 §6.2；必须含手算过程。  
- 三阶段对照见 §6.2 表。  
- 必含除不尽（如 subtotal=1.00、taxRate=7.5 → taxAmount=0.08）。  
- 必含 `quantity≤0` 按 0；`total` 下限 0。  
- Alpine 用 JS `parseFloat` + `toLocaleString` 四舍五入；服务端 `BigDecimal HALF_UP`。两者不一致记缺陷，不得用「以 DB 为准」吞掉 Alpine 差异。

### 业务规则负向（To-Be）

以下按财务基准设计；As-Is 服务端**未见**统一拦截（Context 已确认）。**未拦截不得判 pass**，标注「预期缺陷」。

1. 未来 `issueDate` 应拦截，阻止落库。  
2. 负 `taxRate` / `discount` / `quantity` / `unitPrice` 应拦截（须**绕过**浏览器 `min="0"` 做 POST）。  
3. 必填：至少 `customerName` + 至少 1 条有效行；无有效行仅填客户名应阻止保存。  
4. `dueDate ≥ issueDate`（RULE-TEST-010）。  
5. 权限不足 403，不得执行后续写入。

---

## 6.5 测试层级（UI / HTTP / DB）

| 层级 | 测什么 | 不测什么 |
|------|--------|----------|
| **UI** | 按钮/入口可见性（「+ New Invoice」、Save Invoice）；表单 `required`/`min`；Alpine 预览；详情字段、状态徽章、flash；403 页是否像业务页 | 不写 Playwright；不点 Edit/Delete/Record Payment 做功能测试 |
| **HTTP** | GET/POST 的 **200 / 302 / 403 / 404**；`Location`；`errors/403`、`errors/404`；表单 POST（含 CSRF） | 不编造 REST JSON；不把 CSRF 失败当成权限失败 |
| **DB** | 测前 count；测后主表/分项 count；按 uuid SELECT 字段清单；`SUM(line_total)=subtotal`；空行不入库；uuid 外键 | 不改表结构；不把「页面对了」当成已落库 |

权限场景检查点必须同时有：**页面按钮/入口** + **接口状态** + **DB 前后对比**。

---

## 6.6 验证标准框架

### 手算基准（执行时按实际填写重算，下列为标准底稿）

**数据集 A — INV-AMT-001 / 并入 INV-CREATE-001 金额列**

- 行：`Widget A`，qty=2，unitPrice=100.00 → lineTotal=200.00  
- taxRate=10，discount=5.00  
- taxAmount=20.00，total=215.00  

**数据集 B — INV-AMT-002（除不尽 HALF_UP）**

- 行：`Rounding Item`，qty=1，unitPrice=1.00 → subtotal=1.00  
- taxRate=7.5，discount=0  
- `taxAmount = 1.00 × 7.5 ÷ 100 = 0.075` → HALF_UP 2 位 = **0.08**  
- total = max(1.00+0.08−0, 0) = **1.08**  
- DB：`acc_invoices.tax_amount` 应为 0.08；lineTotal/subtotal/taxAmount/total 均不得超过 2 位小数。

**数据集 C — INV-AMT-003（qty≤0 按 0）**

- 行：description 非空，qty=0，unitPrice=100.00 → lineTotal=0  
- 若绕过前端提交 qty&lt;0：As-Is 服务端 `quantity > 0 ? qty : 0`，期望落库 quantity=0、lineTotal=0；Alpine 若把负数乘进预览，则保存前 Alpine≠手算（按服务端规则）或跨阶段 Alpine≠DB，记缺陷。

**数据集 D — INV-AMT-004（total 下限）**

- 行：qty=1，unitPrice=100.00，taxRate=0，discount=150.00  
- total = max(100+0−150, 0) = **0**（不得为 −50）

### 场景表

| 场景编号 | 场景名称 | 前置数据 | 操作步骤 | 预期结果 | 检查点 | 失败证据 | 风险类型 |
|----------|----------|----------|----------|----------|--------|----------|----------|
| INV-CREATE-001 | 合法数据新建发票成功 | 主账号 VIEW+EDIT；`form.id` 空；唯一 `customerName`；≥1 条有效行；已记 `N0`/`M0` | 列表 → + New Invoice → 填数据集 A → 记录 Alpine → Save → 跟随 302 打开详情 → 按 uuid SELECT 两表 | POST **302**，Location=`/accounting/invoices/{uuid}`；flash=`Invoice INV-xxxx saved.`；号匹配 `INV-\d{4}`；`status=DRAFT`；主表 +1、分项 +M；URL uuid = 主表 id = 分项 invoice_id | HTTP 302+Location；详情字段与 flash；`acc_invoices`/`acc_invoice_items` 字段清单与 count | 请求参数、响应状态与 Location、详情截图（含 URL）、SQL 结果、三处金额表 | 正向链路 / 数据落库 / UUID |
| INV-CREATE-002 | description 空行不入库 | 主账号；5 行槽位中只填 2 行有效、其余 description 空（空行可带 qty/price 以暴露 Alpine 差异） | 保存前记录 Alpine（是否把空行金额加进 Subtotal）→ Save → 查分项条数与 description | To-Be/As-Is 落库：仅 M 条有效行入库，空 description 在 DB 中不存在；`SUM(line_total)=subtotal`；若 Alpine 计入空行金额而 DB 未计入 → 跨阶段记缺陷 | 表单行数 N vs 分项 +M；SELECT description；Alpine vs DB | 表单截图、Alpine 值、分项 SELECT、count 对比 | 数据一致性 / 空行 |
| INV-AUTH-001 | 有 VIEW 无 EDIT 不能新建 | 对照 A（仅 VIEW）；测前 `N0`/`M0`；另备一张已存在发票 uuid（主账号预置，本场景不新建） | **UI：** 登录 A → GET 列表：无可用「+ New Invoice」（含 emptyState 入口）→ 若能打开 `/new` 则 Save 不可用。**API：** 用 A 的会话+CSRF：GET `/accounting/invoices/new`、POST `/accounting/invoices/save`（合法表单）。**对照：** GET 列表与已有详情应可 200 | UI 无新建/保存入口；`/new` 与 POST save 为 **403** + `errors/403`；列表/已有详情可读；两表无新增、无新 invoice_number | 按钮可见性；HTTP 403 与模板；DB count=`N0`/`M0` | 账号权限截图、列表/403 页截图、请求/响应、DB 前后 count | 权限 / 越权写入 |
| INV-AUTH-002 | 无 VIEW 无 EDIT 不能访问发票模块 | 对照 B（如 `mehedi.emp@erp.com`）；测前 `N0`/`M0`；准备一已存在 uuid | **UI：** 列表/详情/新建均不得展示发票业务内容。**API：** GET `/accounting/invoices`、GET `/new`、GET `/accounting/invoices/{uuid}`、POST `/save` | 四处均为 **403** + `errors/403`；不得读取或写入；count 不变 | 页面表现、HTTP 403、模板、DB 无新增 | 账号权限、四处请求/响应、403 页、DB count | 权限 / 越权读取 / 越权写入 |
| INV-AMT-001 | 金额计算三阶段对照（整数） | 数据集 A；主账号 | 保存前手算并记录 Alpine → Save → 详情金额 → SELECT subtotal/tax_amount/discount/total | 保存前 Alpine=手算 200.00/20.00/215.00；保存后详情=DB；跨阶段 Alpine=DB；公式符合 Context | 手算底稿、`#sub-out/#tax-out/#total-out`、详情、DB 列 | 手算、页面值、DB 值、差异记录 | 金额精度 / 数据一致性 |
| INV-AMT-002 | 除不尽 HALF_UP | 数据集 B（taxRate=7.5，subtotal=1.00） | 同上三阶段；核对 tax_amount 小数位 | taxAmount 手算 0.075→**0.08**；详情与 `acc_invoices.tax_amount` 均为 0.08；total=1.08；金额列 ≤2 位小数 | 手算过程、详情 Tax、DB tax_amount | 手算底稿、页面、SQL | 金额精度 / 四舍五入 |
| INV-AMT-003 | quantity≤0 按 0 计 | description 非空；qty=0（及绕过 min 的 qty&lt;0 一组） | 记录 Alpine → POST save → 查分项 quantity、line_total、主表 subtotal | 服务端有效 qty 按 0，lineTotal=0；total 符合公式；负 qty 若 Alpine≠DB 记缺陷 | 分项 quantity/line_total、三阶段金额 | 请求 qty、Alpine、DB | 边界值 / 金额 |
| INV-AMT-004 | total 下限为 0 | 数据集 D，折扣大于小计+税 | 三阶段核对 Total | total=0，不得为负；详情=DB=手算 | Alpine Total、详情 Total、`acc_invoices.total` | 三处数值 | 金额 / 财务底线 |
| INV-NEG-001 | 负数类输入应被拦截 | 主账号；绕过 `min="0"`，分别或组合提交负 taxRate、负 discount、负 quantity、负 unitPrice；测前 count | 构造 POST `/save`（带 CSRF，id 空，customerName 合法，至少一有效 description） | **To-Be：** 拒绝保存，非 302 落库。**As-Is：** 服务端未见统一拦截 → 若 302 且负数入库，标「预期缺陷：{字段} 非预期入库」 | HTTP 状态、错误提示、DB 是否落库、金额是否为负 | 请求参数、响应、DB 前后对比、缺陷描述 | 边界值 / 财务风险 |
| INV-DATE-001 | 未来开票日应被拦截 | 主账号；`issueDate` = 明天或更晚；测前 count | 页面选未来日保存；再绕过前端 POST 同一未来日 | **To-Be：** 拦截且两表不增。**As-Is：** 未见统一拦截 → 落库则「预期缺陷：未来 issueDate 非预期入库」 | HTTP、提示、DB issue_date 与 count | 日期值、响应、SELECT issue_date | 业务规则 / 财务合规 |
| INV-DATE-002 | dueDate 早于 issueDate 应被拦截 | `dueDate` &lt; `issueDate`；页面 + 绕过前端各一次 | 提交保存 | **To-Be：** 拦截不落库。未拦截标预期缺陷 | HTTP、提示、DB 两日期与 count | 请求日期、响应、SELECT | 业务规则 / 日期 |
| INV-REQ-001 | customerName 为空 | 主账号 | **UI：** 清空客户名点保存，观察 HTML `required`。**API：** 绕过 required POST 空 customerName（可带有效行） | **As-Is UI：** 浏览器拦截不发请求。**绕过前端：** 记录实际 4xx/5xx/302；To-Be 应阻止落库；若入库标预期缺陷 | 页面校验、HTTP、DB count 与 customer_name | 两种路径的请求/响应、DB | 空值 / 必填 |
| INV-REQ-002 | 无有效行仅填 customerName | 唯一客户名；全部 description 空；测前 count | 页面保存 + 绕过前端 POST | **To-Be：** 阻止保存。**As-Is：** 未见统一拦截 → 若主表 +1 且分项 +0，标「预期缺陷：无有效行仍入库主表」 | HTTP、提示、主表/分项 count | 表单、响应、两表 count | 业务规则 / 完整性 |
| INV-LEN-001 | 超长客户名/描述 | customerName **151** 字符；description **256** 字符（各至少一单）；禁止写成「required 拦截超长」 | 页面提交 + 绕过前端 POST；查 DB 长度/截断/500 | 记录 As-Is：报错 / 截断 / 500 / 原样入库；To-Be：customerName≤150、description≤255 应拒绝或安全截断并提示 | HTTP、页面错误、DB 字段 LENGTH() | 字符串长度、响应、SELECT LENGTH | 边界 / 截断风险 |
| INV-UUID-001 | 非法 UUID 与不存在 UUID 访问详情 | 主账号（有 VIEW）；不走 save | ① GET `/accounting/invoices/not-a-uuid` ② GET `/accounting/invoices/{合法格式但不存在的 uuid}` | 不得 500；不得展示正常发票；期望 **404** 或统一错误页（As-Is：路径正则不匹配 → 无 handler；不存在 id → `errors/404`）。执行时记录实测状态与模板 | HTTP 状态、错误页、响应体无发票字段 | 两个 URL、状态码、错误页截图 | 异常入参 / 详情边界 |
| INV-IDEM-001 | 同一会话重复提交 | 主账号；同一新建表单数据；测前 count | 快速双击 Save，或同一表单重复 POST（同一会话+CSRF） | 记录主表新增条数、invoice_number 是否重复或跳号。**As-Is 可能多条**，如实记录，不得先写「幂等只 1 条」再判 pass | Network 请求次数、DB count、invoice_number 列表 | 两次请求、两条 SELECT | 重复提交 / 号码生成 |
| INV-IDEM-002 | 两独立会话各提交一次相同业务数据 | 两个浏览器或两个 JSESSIONID，均 VIEW+EDIT；客户名可相同但建议时间戳区分以便追踪 | 各提交一次新建 save | **期望 2 条发票、2 个不同 invoice_number**（不是合并为 1 条）。若号码碰撞（生成器用 `count()+1`）标缺陷 | 两 uuid、两个 invoice_number、主表 +2 | 两会话证据、DB | 并发 / 号码唯一性 |

---

## 6.7 风险与待确认项（As-Is vs To-Be）

| # | 项 | As-Is（已实现/缺口） | To-Be（财务基准） | 测试处理 |
|---|-----|----------------------|-------------------|----------|
| R1 | 未来 issueDate | Context：服务端未见统一拦截 | 必须阻止错误日期落库 | INV-DATE-001；未拦 = 预期缺陷 |
| R2 | 负税率/折扣/数量/单价 | 前端 `min="0"`；服务端未见统一拦截；qty≤0 仅按 0 计，**不拒绝** | 负数应拦截，不能只靠浏览器 | INV-NEG-001，必须绕过前端 |
| R3 | 无有效行仅 customerName | 服务端未见统一拦截；空 description 跳过导致 0 行仍可能写主表 | 至少 1 条有效行才能保存 | INV-REQ-002；主表+1 分项+0 = 预期缺陷 |
| R4 | dueDate &lt; issueDate | 表单无强制；服务端未见统一拦截 | dueDate ≥ issueDate | INV-DATE-002 |
| R5 | Alpine vs 服务端 | Alpine 对**所有行** qty×price 求和（含空 description）；税用 JS float+toLocaleString。服务端跳过空 description，税用 BigDecimal HALF_UP | 预览应与落库一致 | 三阶段任一不一致记缺陷（不得写「以 DB 为准」过） |
| R6 | 发票号生成 | `INV-%04d` 基于 `count()+1` | 唯一且不回绕 | INV-IDEM-001/002；碰撞/跳号记缺陷。不测 delete，但删除后 count 回退导致重号列为残留风险 |
| R7 | 对照账号 A | 种子无「仅 ACCOUNTING_VIEW」用户 | 权限矩阵可测 VIEW vs EDIT | **权限账号待确认**；未创建则 AUTH-001 阻塞 |
| R8 | 空列表 emptyState | 列表非空时「+ New Invoice」有 `sec:authorize="ACCOUNTING_EDIT"`；**emptyState 入口是否授权待执行确认** | 无 EDIT 时任何新建入口都不可用 | AUTH-001 必须覆盖空列表与非空列表 |
| R9 | CSRF 与 403 混淆 | POST 缺 CSRF 也会 403 | 权限 403 须带合法 CSRF 后仍 403 | 前置约束；证据须区分 |
| R10 | 超长字段 | 实体 customerName length=150、description=255；前端 required **不限制长度** | 超长应报错或安全截断 | INV-LEN-001 |
| R11 | 非法详情 URL | `{id:[0-9a-fA-F-]{36}}`；不存在走 404 页 | 不得 500、不得空白当详情 | INV-UUID-001；`not-a-uuid` 实测状态以执行为准 |
| R12 | DB 物理列名 | Rules 使用 snake_case；Hibernate 全局引号 | SELECT 必须能跑通 | 列名与库不一致时标「DB 列名实测待确认」 |
| R13 | 范围蔓延 | 详情页含 Edit / Delete / Record Payment | 本框架不测这些提交 | 只观察新建后详情与权限可见性 |
| R14 | customerName 空 | As-Is 主要靠 HTML required | 服务端也应拒绝 | INV-REQ-001 双路径 |

**本框架不编造：** 未在 Context/Rules/可见配置中出现的接口路径、权限枚举、表名。对照 A 邮箱、emptyState 在 VIEW-only 下的实测、H2 引号列名、`not-a-uuid` 的精确状态码，执行时补记录。

**禁止项复核：** 不改源码/表结构；不测 edit/delete/payment 功能；不把「代码没校验」写成「不必测」；不输出自动化脚本。

---

### 自检对照（Skill §8）

- [x] 范围边界：新建截止详情，不含 edit/delete/payment  
- [x] 区分 As-Is 与 To-Be  
- [x] 覆盖 `DRAFT` 与 `INV-\d{4}`  
- [x] 覆盖 VIEW+EDIT / 仅 VIEW / 无 VIEW，且 UI + API + DB count  
- [x] 覆盖金额公式与三阶段对照（含手算、除不尽 HALF_UP）  
- [x] 覆盖 `acc_invoices` / `acc_invoice_items`  
- [x] 覆盖 UUID 跳转一致性  
- [x] 覆盖负向：负数、未来日期、无有效行、权限 403  
- [x] 每场景含页面 / HTTP / DB 中至少两类证据  
- [x] 输出结构为 Skill §6 固定章节与八列表头  
- [x] 未写自动化脚本  
- [x] 已加载 testing-rules + data-and-db-rules（未标「未加载 Rules」）
