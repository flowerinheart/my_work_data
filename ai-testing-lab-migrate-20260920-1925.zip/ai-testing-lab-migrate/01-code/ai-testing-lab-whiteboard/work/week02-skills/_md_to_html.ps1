# ASCII-only PowerShell. Markdown files are read as UTF-8.
$ErrorActionPreference = 'Stop'

function Convert-InlineHtml([string]$text) {
    if ($null -eq $text) { return '' }
    $text = $text -replace '&lt;', '<' -replace '&gt;', '>' -replace '&amp;', '&'
    $sb = New-Object System.Text.StringBuilder
    $i = 0
    $n = $text.Length
    while ($i -lt $n) {
        $ch = $text[$i]
        if ($ch -eq [char]96) {
            $j = $i + 1
            while ($j -lt $n -and $text[$j] -ne [char]96) { $j++ }
            if ($j -lt $n) {
                $code = ''
                if ($j -gt $i + 1) { $code = $text.Substring($i + 1, $j - $i - 1) }
                [void]$sb.Append('<code>')
                [void]$sb.Append([System.Net.WebUtility]::HtmlEncode($code))
                [void]$sb.Append('</code>')
                $i = $j + 1
                continue
            }
        }
        if ($i + 1 -lt $n -and $ch -eq '*' -and $text[$i+1] -eq '*') {
            $j = $i + 2
            while ($j + 1 -lt $n -and -not ($text[$j] -eq '*' -and $text[$j+1] -eq '*')) { $j++ }
            if ($j + 1 -lt $n) {
                $inner = ''
                if ($j -gt $i + 2) { $inner = $text.Substring($i + 2, $j - $i - 2) }
                [void]$sb.Append('<strong>')
                [void]$sb.Append((Convert-InlineHtml $inner))
                [void]$sb.Append('</strong>')
                $i = $j + 2
                continue
            }
        }
        switch ($ch) {
            '&' { [void]$sb.Append('&amp;') }
            '<' { [void]$sb.Append('&lt;') }
            '>' { [void]$sb.Append('&gt;') }
            default { [void]$sb.Append($ch) }
        }
        $i++
    }
    return $sb.ToString()
}

function Split-TableRow([string]$line) {
    $t = $line.Trim()
    if ($t.StartsWith('|')) { $t = $t.Substring(1) }
    if ($t.EndsWith('|')) { $t = $t.Substring(0, $t.Length - 1) }
    return @($t.Split('|') | ForEach-Object { $_.Trim() })
}

function Test-SeparatorRow([string]$line) {
    return $line -match '^\s*\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)+\|?\s*$'
}

function Convert-MarkdownToBody([string]$md) {
    $lines = $md -split "`r?`n"
    $html = New-Object System.Text.StringBuilder
    $i = 0
    $inUl = $false
    $inOl = $false
    $para = New-Object System.Text.StringBuilder

    function Close-Lists {
        param($h, [ref]$ul, [ref]$ol)
        if ($ol.Value) { [void]$h.AppendLine('</ol>'); $ol.Value = $false }
        if ($ul.Value) { [void]$h.AppendLine('</ul>'); $ul.Value = $false }
    }
    function Flush-Para {
        param($h, $p)
        if ($p.Length -gt 0) {
            $t = $p.ToString().Trim()
            if ($t.Length -gt 0) {
                [void]$h.Append('<p>')
                [void]$h.Append((Convert-InlineHtml $t))
                [void]$h.AppendLine('</p>')
            }
            [void]$p.Clear()
        }
    }

    while ($i -lt $lines.Count) {
        $line = $lines[$i]

        if ($line -match '^```') {
            Flush-Para $html $para
            Close-Lists $html ([ref]$inUl) ([ref]$inOl)
            $lang = $line.Substring(3).Trim()
            $i++
            $code = New-Object System.Text.StringBuilder
            while ($i -lt $lines.Count -and $lines[$i] -notmatch '^```') {
                [void]$code.AppendLine($lines[$i])
                $i++
            }
            [void]$html.Append('<pre><code>')
            [void]$html.Append([System.Net.WebUtility]::HtmlEncode($code.ToString().TrimEnd()))
            [void]$html.AppendLine('</code></pre>')
            $i++
            continue
        }

        if ($line.Trim() -eq '---') {
            Flush-Para $html $para
            Close-Lists $html ([ref]$inUl) ([ref]$inOl)
            [void]$html.AppendLine('<hr>')
            $i++
            continue
        }

        if ($line -match '^\s*\|' -and ($i + 1) -lt $lines.Count -and (Test-SeparatorRow $lines[$i+1])) {
            Flush-Para $html $para
            Close-Lists $html ([ref]$inUl) ([ref]$inOl)
            $headers = Split-TableRow $line
            $i += 2
            [void]$html.AppendLine('<div class="table-wrap"><table>')
            [void]$html.Append('<thead><tr>')
            foreach ($h in $headers) {
                [void]$html.Append('<th>')
                [void]$html.Append((Convert-InlineHtml $h))
                [void]$html.Append('</th>')
            }
            [void]$html.AppendLine('</tr></thead><tbody>')
            while ($i -lt $lines.Count -and $lines[$i] -match '^\s*\|') {
                $cells = Split-TableRow $lines[$i]
                [void]$html.Append('<tr>')
                for ($c = 0; $c -lt $headers.Count; $c++) {
                    $cell = if ($c -lt $cells.Count) { $cells[$c] } else { '' }
                    [void]$html.Append('<td>')
                    [void]$html.Append((Convert-InlineHtml $cell))
                    [void]$html.Append('</td>')
                }
                [void]$html.AppendLine('</tr>')
                $i++
            }
            [void]$html.AppendLine('</tbody></table></div>')
            continue
        }

        if ($line -match '^(#{1,6})\s+(.*)$') {
            Flush-Para $html $para
            Close-Lists $html ([ref]$inUl) ([ref]$inOl)
            $level = $Matches[1].Length
            $title = $Matches[2]
            [void]$html.Append("<h$level>")
            [void]$html.Append((Convert-InlineHtml $title))
            [void]$html.AppendLine("</h$level>")
            $i++
            continue
        }

        if ($line -match '^>\s?(.*)$') {
            Flush-Para $html $para
            Close-Lists $html ([ref]$inUl) ([ref]$inOl)
            [void]$html.Append('<blockquote><p>')
            [void]$html.Append((Convert-InlineHtml $Matches[1]))
            [void]$html.AppendLine('</p></blockquote>')
            $i++
            continue
        }

        if ($line -match '^\s*[-*]\s+(.*)$') {
            Flush-Para $html $para
            if ($inOl) { [void]$html.AppendLine('</ol>'); $inOl = $false }
            if (-not $inUl) { [void]$html.AppendLine('<ul>'); $inUl = $true }
            $item = $Matches[1]
            if ($item -match '^\[x\]\s+(.*)$') {
                [void]$html.Append('<li>')
                [void]$html.Append('[x] ')
                [void]$html.Append((Convert-InlineHtml $Matches[1]))
            } else {
                [void]$html.Append('<li>')
                [void]$html.Append((Convert-InlineHtml $item))
            }
            [void]$html.AppendLine('</li>')
            $i++
            continue
        }

        if ($line -match '^\s*(\d+)\.\s+(.*)$') {
            Flush-Para $html $para
            if ($inUl) { [void]$html.AppendLine('</ul>'); $inUl = $false }
            if (-not $inOl) { [void]$html.AppendLine('<ol>'); $inOl = $true }
            [void]$html.Append('<li>')
            [void]$html.Append((Convert-InlineHtml $Matches[2]))
            [void]$html.AppendLine('</li>')
            $i++
            continue
        }

        if ($line.Trim() -eq '') {
            Flush-Para $html $para
            Close-Lists $html ([ref]$inUl) ([ref]$inOl)
            $i++
            continue
        }

        if ($para.Length -gt 0) { [void]$para.Append(' ') }
        [void]$para.Append($line.TrimEnd())
        $i++
    }
    Flush-Para $html $para
    Close-Lists $html ([ref]$inUl) ([ref]$inOl)
    return $html.ToString()
}

$css = @'
:root { --ink:#1a2332; --muted:#5b6573; --line:#d9e0ea; --bg:#f6f8fb; --card:#fff; --accent:#1f4e79; --code:#0f172a; }
* { box-sizing: border-box; }
body { margin:0; font: 15px/1.65 "Segoe UI","PingFang SC","Microsoft YaHei",sans-serif; color:var(--ink); background:var(--bg); }
.wrap { max-width: 1180px; margin: 0 auto; padding: 32px 20px 80px; }
header.doc { background: var(--accent); color:#fff; padding: 28px 20px; }
header.doc .wrap { padding: 0; }
header.doc h1 { margin:0 0 8px; font-size: 26px; font-weight: 700; }
header.doc p { margin:0; opacity:.92; font-size:14px; }
h1 { font-size: 26px; }
h2 { margin: 36px 0 12px; padding-bottom: 8px; border-bottom: 2px solid var(--accent); color: var(--accent); font-size: 22px; }
h3 { margin: 24px 0 10px; font-size: 18px; color:#243447; }
p { margin: 0 0 12px; }
blockquote { margin: 0 0 16px; padding: 10px 14px; background:#eef3f8; border-left: 4px solid var(--accent); color:#334; }
hr { border:0; border-top:1px solid var(--line); margin: 24px 0; }
code { font-family: Consolas,monospace; font-size: 0.92em; background:#eef2f6; padding: 1px 5px; border-radius: 3px; }
pre { background: var(--code); color:#e6edf3; padding: 14px 16px; overflow:auto; border-radius: 8px; }
pre code { background: transparent; color: inherit; padding:0; }
.table-wrap { overflow-x: auto; margin: 0 0 18px; background: var(--card); border: 1px solid var(--line); border-radius: 8px; }
table { border-collapse: collapse; width: 100%; min-width: 720px; font-size: 13.5px; }
th, td { border-bottom: 1px solid var(--line); padding: 8px 10px; text-align: left; vertical-align: top; }
thead th { background: #1f4e79; color:#fff; font-weight: 600; white-space: nowrap; }
tbody tr:nth-child(even) { background: #f3f6fa; }
ul, ol { margin: 0 0 14px; padding-left: 1.4em; }
li { margin: 4px 0; }
.meta { margin-top: 28px; color: var(--muted); font-size: 13px; }
'@

function Get-MdTitle([string]$md, [string]$fallback) {
    foreach ($ln in ($md -split "`r?`n")) {
        if ($ln -match '^#\s+(.*)$') { return $Matches[1].Trim() }
    }
    return $fallback
}

function Write-DocHtml([string]$title, [string]$subtitle, [string]$body, [string]$outPath) {
    $encTitle = [System.Net.WebUtility]::HtmlEncode($title)
    $encSub = [System.Net.WebUtility]::HtmlEncode($subtitle)
    $parts = New-Object System.Collections.Generic.List[string]
    [void]$parts.Add('<!DOCTYPE html>')
    [void]$parts.Add('<html lang="zh-CN">')
    [void]$parts.Add('<head>')
    [void]$parts.Add('<meta charset="utf-8">')
    [void]$parts.Add('<meta name="viewport" content="width=device-width, initial-scale=1">')
    [void]$parts.Add("<title>$encTitle</title>")
    [void]$parts.Add('<style>')
    [void]$parts.Add($css)
    [void]$parts.Add('</style>')
    [void]$parts.Add('</head><body>')
    [void]$parts.Add('<header class="doc"><div class="wrap">')
    [void]$parts.Add("<h1>$encTitle</h1>")
    [void]$parts.Add("<p>$encSub</p>")
    [void]$parts.Add('</div></header>')
    [void]$parts.Add('<main class="wrap">')
    [void]$parts.Add($body)
    [void]$parts.Add('<p class="meta">Local HTML document. Open this file in a browser. Wide tables scroll horizontally.</p>')
    [void]$parts.Add('</main></body></html>')
    $doc = [string]::Join("`r`n", $parts.ToArray())
    $utf8 = New-Object System.Text.UTF8Encoding $true
    [System.IO.File]::WriteAllText($outPath, $doc, $utf8)
}

$dir = Split-Path -Parent $MyInvocation.MyCommand.Path
$utf8NoBom = New-Object System.Text.UTF8Encoding $false

$md1Path = Join-Path $dir 'invoice-create-test-framework.md'
$md1 = [System.IO.File]::ReadAllText($md1Path, [System.Text.Encoding]::UTF8)
$body1 = Convert-MarkdownToBody $md1
Write-DocHtml 'invoice-create-test-framework.md' 'Full text converted to HTML' $body1 (Join-Path $dir 'invoice-create-test-framework.html')

$md2Path = Join-Path $dir 'previous-reply-invoice-framework.md'
$md2 = [System.IO.File]::ReadAllText($md2Path, [System.Text.Encoding]::UTF8)
$body2 = Convert-MarkdownToBody $md2
Write-DocHtml 'previous-reply 6.1-6.7' 'Verbatim previous chat answer' $body2 (Join-Path $dir 'previous-reply-invoice-framework.html')

Write-Output 'OK'
