范围已按 Skill 钉死：**只测新建**（列表 → 新建 → 保存 → 详情），**不测** edit / delete / payment，也**不写**自动化脚本。

完整框架已写入  
`C:\Users\hma\code\ai-testing-lab-whiteboard\work\week02-skills\invoice-create-test-framework.md`  
（结构按 Skill §6，场景表为固定八列；已加载 `testing-rules` + `data-and-db-rules`。）

---

## 6.1 测试范围

Accounting / Invoices，链路止于保存后详情核对：`form.id == null` → POST `/accounting/invoices/save` **302** → `/accounting/invoices/{uuid}`。

| 步骤 | 方法 | URL | 权限 |
|------|------|-----|------|
| 列表 | GET | `/accounting/invoices` | `ACCOUNTING_VIEW` |
| 新建 | GET | `/accounting/invoices/new` | `ACCOUNTING_EDIT` |
| 保存 | POST | `/accounting/invoices/save`（表单，非 JSON） | `ACCOUNTING_EDIT` |
| 详情 | GET | `/accounting/invoices/{uuid}` | `ACCOUNTING_VIEW` |

成功：302 + `INV-\d{4}` + `status=DRAFT`。无权限：403 + `errors/403`。详情页 Edit / Delete / Record Payment 只允许看可见性，不得提交。

---

## 6.2 测试前置

- 环境：默认 `http://localhost:8080`；H2 `/h2-console`，`jdbc:h2:file:./data/erpdb`，`sa` / 空密码。POST 必须带**同一会话 CSRF**，缺 CSRF 的 403 不得记成权限失败。
- 正向：`admin@erp.com` / `Admin@1234`（VIEW+EDIT）。
- 对照 B：`mehedi.emp@erp.com` / `Admin@1234`（无 VIEW、无 EDIT）。
- **对照 A（仅 VIEW）待确认**：种子数据没有「只有 ACCOUNTING_VIEW、没有 EDIT」的账号，需在 `/settings` 临时创建后再跑 INV-AUTH-001。
- 客户名用 `AutoTest_yyyyMMdd_HHmmss`；至少 1 条 `description` 非空分项；`id` 为空。
- 每个会 save 的用例先记基线：`acc_invoices` / `acc_invoice_items` 的 `COUNT(*)`，以及 `MAX(invoice_number)`。

金额公式与三阶段对照（不得改写）：

- `qty≤0` 按 0；`lineTotal = unitPrice × quantity`；`subtotal` = 有效行之和
- `taxAmount = subtotal × taxRate ÷ 100`（HALF_UP，2 位）
- `total = max(subtotal + taxAmount − discount, 0)`
- 保存前：手算 = Alpine；保存后：详情 = DB；跨阶段：Alpine = DB；任一不一致记缺陷，禁止写「以 DB 为准」直接 pass。

---

## 6.3 测试步骤（正向主路径）

0. 登录主账号，取 `N0` / `M0` / 最大发票号。
1. GET 列表 200，可见「+ New Invoice」。
2. GET `/new` 200，`id` 空，发票号不可手填，可见 Save Invoice。
3. 填数据集 A：客户 `AutoTest_*`，行 `Widget A / 2 / 100.00`，税率 10，折扣 5；手算 **subtotal=200.00、tax=20.00、total=215.00**；记下 Alpine `#sub-out/#tax-out/#total-out`。
4. POST save，断言 **302** 且 `Location=/accounting/invoices/{uuid}`。
5. 详情：flash `Invoice INV-xxxx saved.`；号匹配 `INV-\d{4}`；状态 Draft；客户/日期/行/金额与表单一致；**不点付款**。
6. 按 uuid SELECT 主表+分项：id 唯一且等于 URL；`status='DRAFT'`；主表 +1、分项 +M；`invoice_id` = uuid；`SUM(line_total)=subtotal`；详情金额 = DB = 手算；Alpine 与 DB 再对一次。

---

## 6.4–6.5 维度与分层

- **正向：** 302、DRAFT、`INV-\d{4}`、uuid 三联一致、空行不入库、flash。
- **权限：** UI（按钮）+ API（绕过前端 403）+ DB 无新增；覆盖 VIEW+EDIT / 仅 VIEW / 无 VIEW。
- **金额：** 公式 + HALF_UP 除不尽 + 三阶段。
- **To-Be 负向：** 负数、未来日期、无有效行；未拦截标「预期缺陷」。
- **UI / HTTP / DB** 分层测入口、状态码、count 与字段；每场景至少两类证据。

---

## 6.6 验证标准框架（场景表）

手算补一组除不尽：qty=1、unitPrice=1.00、taxRate=7.5 → tax **0.075 → 0.08**，total **1.08**。折扣 150、小计 100 时 total 必须为 **0**。

| 场景编号 | 场景名称 | 前置数据 | 操作步骤 | 预期结果 | 检查点 | 失败证据 | 风险类型 |
|----------|----------|----------|----------|----------|--------|----------|----------|
| INV-CREATE-001 | 合法数据新建成功 | VIEW+EDIT；唯一客户名；≥1 有效行；已记 N0/M0 | 列表→新建→填表→记 Alpine→Save→跟 302→按 uuid 查库 | 302+Location uuid；flash 含发票号；`INV-\d{4}`；DRAFT；主表+1 分项+M；三 uuid 一致 | HTTP、详情、两表 SELECT/count | 请求、302、截图、SQL | 正向 / 落库 / UUID |
| INV-CREATE-002 | 空 description 不入库 | 多行槽位只填 M 行有效 | 记 Alpine（是否把空行算进小计）→保存→查分项 | 只入库 M 行；空行不在 DB；Alpine 若计入空行则跨阶段记缺陷 | 分项条数、SUM(line_total) | 表单、Alpine、SELECT | 空行 / 一致性 |
| INV-AUTH-001 | 仅 VIEW 不能新建 | 对照 A（待创建）；已有发票 uuid | UI 看按钮/emptyState；API 用 A 的会话+CSRF 打 `/new` 与 POST save | 无新建/保存入口；403+`errors/403`；列表/已有详情可读；count 不变 | 按钮、403、DB count | 权限、截图、请求、count | 权限 / 越权写 |
| INV-AUTH-002 | 无 VIEW 不能进模块 | 对照 B | UI+API：列表、详情、`/new`、POST save | 四处 403+`errors/403`；不读不写；count 不变 | 页面、HTTP、DB | 四处响应、count | 权限 / 越权读写 |
| INV-AMT-001 | 整数金额三阶段 | 数据集 A | 手算→Alpine→详情→DB | 200/20/215 三处一致 | 四处数值 | 手算底稿、页面、DB | 金额 |
| INV-AMT-002 | HALF_UP 除不尽 | taxRate=7.5，subtotal=1.00 | 同上 | tax_amount=0.08，total=1.08，≤2 位小数 | 详情 Tax、DB tax_amount | 手算、SQL | 精度 |
| INV-AMT-003 | qty≤0 按 0 | qty=0 及绕过 min 的负数 | Alpine→POST→查分项 | 服务端 qty 按 0；Alpine≠DB 记缺陷 | quantity、line_total | 请求、Alpine、DB | 边界 |
| INV-AMT-004 | total 下限 0 | 折扣大于小计+税 | 三阶段看 Total | total=0 不得为负 | Alpine/详情/DB total | 三处数值 | 财务底线 |
| INV-NEG-001 | 负数应拦截 | 绕过 min=0 POST 负税率/折扣/数量/单价 | 直接 POST save | To-Be 拒绝；As-Is 落库则「预期缺陷」 | HTTP、DB 是否新增/是否为负 | 参数、响应、count | 财务风险 |
| INV-DATE-001 | 未来开票日应拦截 | issueDate≥明天；页面+绕过前端 | 提交 | To-Be 不落库；落库=预期缺陷 | HTTP、issue_date、count | 日期、SQL | 合规 |
| INV-DATE-002 | dueDate&lt;issueDate | 到期早于开票；双路径 | 提交 | To-Be 拦截；未拦=预期缺陷 | 两日期、count | 请求、SELECT | 日期 |
| INV-REQ-001 | 客户名为空 | — | UI required + 绕过 POST 空名 | UI 应拦；绕过后 To-Be 不入库 | 页面校验、HTTP、count | 双路径证据 | 必填 |
| INV-REQ-002 | 无有效行 | 只填客户名 | 页面+绕过 POST | To-Be 阻止；主表+1 分项+0=预期缺陷 | 两表 count | 表单、SQL | 完整性 |
| INV-LEN-001 | 超长 151/256 | 禁止写成 required 拦长度 | 页面+POST；查 LENGTH | 记录报错/截断/500/入库 | HTTP、DB 长度 | 字符串、SELECT | 截断 |
| INV-UUID-001 | 非法/不存在 uuid | 不走 save | GET `.../not-a-uuid` 与合法但不存在 uuid | 不得 500、不得当正常详情；期望 404/统一错误页 | HTTP、错误页 | 两 URL、截图 | 详情边界 |
| INV-IDEM-001 | 同会话重复提交 | 同一表单双击或重复 POST | 记请求次数与入库条数 | 如实记多条/跳号/重号；As-Is 可能非幂等 | count、invoice_number | 两次请求、SELECT | 重复提交 |
| INV-IDEM-002 | 两会话各开一张 | 两个 JSESSIONID | 各 save 一次 | 期望 2 条、2 个不同发票号；碰撞记缺陷 | 两 uuid、两号码 | 两会话、DB | 并发 |

---

## 6.7 风险与待确认项

As-Is 缺口（未来日期、负数、无有效行、到期日）一律按 To-Be 测，未拦截记**预期缺陷**。Alpine 会把空 description 行也加进预览，服务端会跳过，三阶段很容易爆差异。发票号用 `count()+1`，并发可能重号。

**待确认：** 对照 A 账号；H2 带全局引号后的实测列名；emptyState 在仅 VIEW 下是否仍露出新建入口；`not-a-uuid` 的精确状态码。

未覆盖 edit/delete/payment，也没有脚本。执行时对照 A 未就绪则 INV-AUTH-001 阻塞，不要用主账号 cookie 去冒充无权限。
