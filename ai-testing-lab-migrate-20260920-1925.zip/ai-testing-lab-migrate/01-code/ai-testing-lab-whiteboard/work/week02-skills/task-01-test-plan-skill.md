# Task 01：设计 ERP 链路测试计划 Skill

> 本任务训练你把“根据需求生成测试计划”封装成 Skill。

## 任务目标

设计一个学习用 Skill：当用户给出 Meridian ERP 的某条业务需求时，AI 能按固定流程生成测试计划。

本任务先以 **发票新建链路** 为主，后续可扩展到订单、付款、会计分录。

## 你要创建的文件

请复制 `skill-template.md`，新建：

```text
work/week02-skills/my-test-plan-skill.md
```

## Skill 必须解决的问题

没有 Skill 时，AI 容易直接写“测试点列表”，漏掉：

- 范围边界：是否只测新建，不测编辑、删除、付款。
- 权限：`ACCOUNTING_VIEW` 与 `ACCOUNTING_EDIT` 的差异。
- 数据证据：页面、HTTP、DB 是否都要核对。
- 业务风险：负数、未来日期、无有效行项目。
- 输出格式：是否有固定字段和失败证据。

你的 Skill 要把这些流程固定下来。

## 输入材料

你可以引用或阅读以下白板区文件：

- `work/week01/test-task-template.md`
- `work/week01/prompt-context-constraint-ac.md`
- `work/week01b-rules/testing-rules.md`
- `work/week01b-rules/data-and-db-rules.md`

## 写作要求

你的 `my-test-plan-skill.md` 必须包含以下章节：

1. Skill 目的
2. 适用范围
3. 触发条件
4. 输入契约
5. 工作流
6. 输出契约
7. 失败处理
8. 自检清单
9. 调用样例

## 关键约束

- Rule 管约束，Skill 管流程；不要把 16 条 Rules 原文整段复制进 Skill。
- Skill 必须说明“先读 Context，再拆风险，再输出测试计划”。
- 输出契约必须稳定，不能每次换表头。
- 输入缺失时必须标记“待确认”，不能编造 URL、权限、表字段。
- 本任务不写自动化脚本。

## 发票链路最小覆盖

你的 Skill 工作流至少要强制覆盖：

| 维度 | 最低要求 |
|------|----------|
| 范围 | 只测发票新建时，明确截止到详情页验证 |
| 权限 | 至少区分有 EDIT、VIEW-only、无 VIEW 三类 |
| 金额 | 引导 AI 使用公式和 DB 核对 |
| 状态 | 保存后验证 `DRAFT` 和发票号 |
| DB | 主表 `acc_invoices` 与分项表 `acc_invoice_items` |
| 负向 | 负数、未来日期、无有效行项目 |
| 证据 | 页面、HTTP 状态、DB 查询、失败截图或记录 |

## 验收标准

- [ ] Skill 能说明“什么时候触发”。
- [ ] Skill 能说明“需要哪些输入”。
- [ ] Skill 有明确的分步工作流。
- [ ] Skill 有固定输出结构。
- [ ] Skill 有失败处理规则。
- [ ] Skill 有自检清单。
- [ ] Skill 没有把本周任务写成自动化脚本。
