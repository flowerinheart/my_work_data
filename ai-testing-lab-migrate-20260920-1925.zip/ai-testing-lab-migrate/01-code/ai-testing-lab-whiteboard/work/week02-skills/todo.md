# Week02 执行 Todo

> 按顺序完成，不要跳到后面的自动化脚本。
> 最后更新：2026-09-11

## Day 1：理解 Skill

- [x] 阅读 `materials/week02-skill-guide.html`
- [x] 用自己的话写出：Skill 和 Rule 的区别（Rule 管底线约束，Skill 管固定流程）
- [x] 用自己的话写出：触发条件、输入输出契约、工作流封装、复用、版本化分别是什么意思

## Day 2：测试计划 Skill

- [x] 阅读 `task-01-test-plan-skill.md`
- [x] 复制 `skill-template.md`
- [x] 创建 `my-test-plan-skill.md`
- [x] 填写目的、范围、触发条件
- [x] 填写输入契约和输出契约
- [x] 填写发票链路测试计划工作流
- [x] 填写自检清单
- [x] **修订**（根据审查反馈）

## Day 3：失败日志分析 Skill

- [x] 阅读 `task-02-failure-log-skill.md`
- [x] 复制 `skill-template.md`
- [x] 创建 `my-failure-log-skill.md`
- [x] 填写失败日志输入契约
- [x] 填写失败层定位流程
- [x] 填写根因判断和最小复现输出格式
- [x] 填写自检清单

## Day 4：调用实验

- [x] 阅读 `task-03-invocation-samples.md`
- [x] 完成调用样例 1：发票测试计划
- [x] 完成调用样例 2：坏 Prompt 抵抗
- [x] 完成调用样例 3：失败日志分析
- [x] 记录每次输出是否稳定
- [x] 写出 Skill 需要修改的地方（见 `task-03-invocation-samples.md` 复盘表）

## Day 5：复盘与提交

- [x] 填写 `self-review.md`
- [x] 检查所有文件是否在 `work/week02-skills/`
- [ ] 到验证区提交：`请验证白板区 work/week02-skills 的学习成果。`

## 当前进度

| 阶段 | 状态 |
|------|------|
| Day 1 概念 | ✅ 完成 |
| Day 2 `my-test-plan-skill.md` | ✅ 完成 |
| Day 3 `my-failure-log-skill.md` | ✅ 完成 |
| Day 4 调用实验 | ✅ 完成 |
| Day 5 提交 | ⏳ 待你在验证区发口令 |
