# Task 03：Skill 调用样例与稳定性验证

> 本任务验证你写的 Skill 是否真的能让 AI 输出稳定，而不是只写了一份说明文。

## 任务目标

用你在 Task 01 和 Task 02 写的两个 Skill，至少做 3 次调用实验，并记录输出质量。

## 调用样例 1：发票测试计划

### 用户请求

```text
请使用 my-test-plan-skill，基于 Meridian ERP 发票新建链路，生成测试计划。
范围只到保存后跳转详情页，不测编辑、删除、付款。
```

### 你要记录

| 检查项 | 是否做到 | 证据或问题 |
|--------|----------|------------|
| 是否先确认范围 | 是 | 模块： Accounting / Invoices（发票新建）。链路： 列表 → 新建表单（form.id 为空）→ 填写 → POST 保存 → 302 跳转详情页 → 详情字段与 DB 核对。截止点： 保存成功后详情页验证完毕（含 flash、UUID、主表/分项落库）。明确不测： edit、delete、payment（含详情页 Record Payment 提交、付款后 PARTIAL/PAID）。详情页上 Edit / Delete / Record Payment 仅允许观察权限可见性，不得走这些提交链路。入口与 URL：列表 GET /accounting/invoices ACCOUNTING_VIEW、新建表单 GET /accounting/invoices/new ACCOUNTING_EDIT、保存 POST /accounting/invoices/save ACCOUNTING_EDIT、详情 GET /accounting/invoices/{uuid} ACCOUNTING_VIEW |
| 是否覆盖权限（`ACCOUNTING_VIEW+EDIT` / 仅 `VIEW` / 无 `VIEW`），且含 UI + API | 是 | 正向主账号 admin@erp.com / Admin@1234 ACCOUNTING_VIEW + ACCOUNTING_EDIT 正向、金额、To-Be 负向、幂等。对照 A（VIEW-only） 待确认：须临时创建 仅 ACCOUNTING_VIEW，无 ACCOUNTING_EDIT 权限 UI + API。对照 B（无 Accounting） 种子账号可用：mehedi.emp@erp.com / Admin@1234（Employee） 无 ACCOUNTING_VIEW、无 ACCOUNTING_EDIT 权限 UI + API |
| 是否覆盖状态 `DRAFT` 与 `INV-\d{4}` | 是 | 测试步骤，验证框架，测试前置里均包含状态和发票号码测试 |
| 是否覆盖金额公式 | 部分未做到 | 6.3 6.4 里写了完整金额公式及检查点，但是6.5 测试层级的DB入库里没提及金额的校验。（DB的测试里包含了金额，在data-and-db-rules里RULE-DB-004、RULE-DB-005写明了有金额验证点） |
| 是否覆盖三阶段对照（保存前 Alpine=手算；保存后详情=DB） | 是 | 测试维度、测试层级、验证标准框架、待确认项 均有三场景覆盖 |
| 是否覆盖 DB 核对（`acc_invoices` / `acc_invoice_items`） | 部分未做到 | 6.4 测试维度说明里少了DB核对。应在6.4的金额和正向链路里补充上6.3 测试步骤里的步骤 6 — DB 核对 |
| 是否覆盖负向（负数、未来日期、无有效行、权限 403） | 是 | 测试维度、测试层级、验证标准框架、待确认项 均有所有负向场景覆盖 |
| UUID 跳转一致性 | 部分未做到 | 6.5 测试层级的UI层面缺少UUID跳转 |
| 是否区分 As-Is 与 To-Be | 部分未做到 | 6.6 验证标准框架的手算基准里未区分to-be。（to-be原文：**负税率、负折扣、负数量、负单价应被拦截）。6.6 验证标准框架的手算基准数据集 C — INV-AMT-003里只有As-is的内容 |
| 输出表头是否稳定 | 是 | **场景表固定表头：** 场景编号 \| 场景名称 \| 前置数据 \| 操作步骤 \| 预期结果 \| 检查点 \| 失败证据 \| 风险类型 |
| 是否有待确认项 | 部分编造 | 风险与待确认项的R8~R13均为超出context和rule范围外，AI自己凭空生成的内容 |

## 调用样例 2：坏 Prompt 抵抗

### 用户请求

```text
请使用 my-test-plan-skill，帮我简单写一下发票保存成功就行，能跳转详情页就算通过。
```

### 你要观察

这个请求故意把标准压窄。你的 Skill 应该阻止 AI 只写“跳转成功”。

| 检查项 | 是否做到 | 证据或问题 |
|--------|----------|------------|
| 是否没有被“跳转即过”带偏 | 是 | 测试范围内所有步骤、HTTP+页面+详情跳转 的测试点、限（VIEW+EDIT / 仅 VIEW / 无 VIEW，UI+API+DB count）、金额公式、To-Be 负向（负数、未来日期、无有效行），均输出无内容遗漏 |
| 是否仍要求 DB 证据 | 是 | 每个板块均有DB核对 |
| 是否仍要求权限负向 | 是 | 每个板块均有权限负向 |
| 是否仍要求金额和状态 | 是 | 每个板块均有金额和状态的所有测试点 |
| 是否指出用户标准不足 | 是 | 「能跳转详情页就算通过」——指出不足：不足，不得作为唯一 pass。须同时成立：POST 302 + Location=/accounting/invoices/{uuid} + 详情打开的是刚建那张票 + status=DRAFT + invoiceNumber 匹配 INV-\d{4} + 主表/分项落库 + 金额三阶段对照。「简单写一下保存成功就行」——指出不足：不得压成单条 happy path。仍须覆盖权限（VIEW+EDIT / 仅 VIEW / 无 VIEW，UI+API+DB count）、金额公式、To-Be 负向（负数、未来日期、无有效行）。「表单随意填写」——指出不足：允许用任意合法业务值，但 customerName 必须可追踪（RULE-DB-001），且须留下手算底稿；随意填 不等于 不核对金额/DB。范围——指出不足：需说明范围是仅新建（form.id == null）到详情验证；不测 edit / delete / payment |

## 调用样例 3：失败日志分析

### 用户请求

```text
请使用 my-failure-log-skill，分析以下失败：
账号只有 ACCOUNTING_VIEW，没有 ACCOUNTING_EDIT。
我直接 POST /accounting/invoices/save，响应却跳转到了 /accounting/invoices/{uuid}。
DB 中 acc_invoices 新增 1 条，acc_invoice_items 新增 2 条。
```

### 你要记录

| 检查项 | 是否做到 | 证据或问题 |
|--------|----------|------------|
| 是否还原业务链路 | 是 | 6.2 业务链路还原：标准新建链路：登录 → 列表 → 新建（form.id == null）→ 提交保存 → 详情。本次实际做到的步骤：使用仅 ACCOUNTING_VIEW 的账号（用户陈述）。未走/未依赖 UI「+ New Invoice」；直接 POST /accounting/invoices/save。失败发生在保存这一步：请求被当成功保存处理，随后进入详情 URL /accounting/invoices/{uuid}。详情是否完整打开、flash 文案如何，未提供页面证据，链路在「保存已生效并跳转」处即可判定失败。 |
| 是否定位为权限层问题 | 是 | 仅 VIEW 无 EDIT 仍 POST save 成功并落库，与应有 ACCOUNTING_EDIT 拦截矛盾；§6.3 权限层为主因；HTTP/服务端/DB 为连带证据；页面层缺截图标证据不足，不等于页面逻辑正确 |
| 是否指出期望应为 403 | 是 | 均指出 |
| 是否检查 DB 不应新增 | 是 | 均指出DB新增检查为bug |
| 是否输出最小复现步骤 | 是 | 步骤复现正确 |
| 是否区分缺陷与待确认项 | 是 | 待确认项完整 |

## 本任务验收标准

- [x] 至少完成 3 次调用样例。
- [x] 每次调用都记录“是否做到”和“证据或问题”。
- [x] 能指出 Skill 输出哪里稳定、哪里不稳定。
- [x] 如果输出不稳定，能写出 Skill 应如何修改。

## 输出稳定性复盘

完成调用后，填写：

| 问题 | 你的结论 |
|------|----------|
| 哪个 Skill 输出最稳定？ | my-test-plan-skill |
| 哪个 Skill 漏项最多？ | my-failure-log-skill（输入更短时更依赖推断；若指测试计划产物漏项，则是 6.4/6.5 与 6.3 未对齐） |
| 哪个触发条件写得不够清楚？ | failure-log 可加「POST save 越权 / 权限失败」类触发 |
| 哪个输入契约需要补充？ | test-plan 可选 @ Rules 减少漏 DB 金额；failure-log 输入带一句期望结果（§9 已写） |
| 哪个输出字段应固定？ | test-plan 八列场景表 + §6.1～6.7；failure-log §6.1～6.7 + 失败层表 |
| 下一版 Skill 要改什么？ | test-plan：6.5 DB/UI 显式写金额与 uuid；6.7 禁止无来源 R8～R13。failure-log：缺操作步骤时 §6.2 首句标链路部分待确认 |
