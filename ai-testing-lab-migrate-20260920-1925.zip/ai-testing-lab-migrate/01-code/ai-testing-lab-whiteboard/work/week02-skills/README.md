# Week02 Skills 学习任务

> 目标：掌握 M3「把重复流程封装成 Skill」。
> 本目录是白板区任务说明，不包含标准答案。

## 本周学习目标

完成本周后，你应能说明：

1. Rule 管约束，Skill 管流程。
2. Skill 需要写清触发条件、输入输出契约、工作流、失败处理和自检标准。
3. 同一类任务重复执行时，Skill 能让 AI 输出结构稳定。
4. 发票、订单、付款、会计分录这类 ERP 链路可以共用一套测试计划生成流程。

## 本周任务包

| 任务 | 文件 | 你要完成什么 |
|------|------|--------------|
| Task 01 | `task-01-test-plan-skill.md` | 设计一个“根据 Meridian ERP 需求生成测试计划”的 Skill |
| Task 02 | `task-02-failure-log-skill.md` | 设计一个“分析交易失败日志”的 Skill |
| Task 03 | `task-03-invocation-samples.md` | 用你写的 Skill 做至少 3 次调用样例 |
| Task 04 | `self-review.md` | 对本周产物做自检 |
| 模板 | `skill-template.md` | 写 Skill 时复制使用 |

## 建议学习顺序

1. 先阅读 `materials/week02-skill-guide.html`，理解 Skill 是什么。
2. 复制 `skill-template.md`，完成 Task 01 的测试计划 Skill。
3. 用同一模板完成 Task 02 的失败日志分析 Skill。
4. 用 Task 03 提供的三个调用场景验证输出是否稳定。
5. 最后填写 `self-review.md`。

## 交付物

你最终至少需要提交：

- `work/week02-skills/my-test-plan-skill.md`
- `work/week02-skills/my-failure-log-skill.md`
- `work/week02-skills/task-03-invocation-samples.md`
- `work/week02-skills/self-review.md`

## 本周不做什么

- 不写自动化测试脚本。
- 不补 UI Playwright 规则。
- 不修改 Meridian ERP 源码。
- 不追求写成真正可安装的 Cursor Skill；本周先训练 Skill 设计能力。

## 去验证区提交口令

完成后到验证区提交：

```text
请验证白板区 work/week02-skills 的学习成果。
```
