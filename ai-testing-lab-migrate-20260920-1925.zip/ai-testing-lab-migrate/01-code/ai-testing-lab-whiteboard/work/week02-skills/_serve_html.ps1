$ErrorActionPreference = 'Stop'
$dir = 'C:\Users\hma\code\ai-testing-lab-whiteboard\work\week02-skills'
$prefix = 'http://127.0.0.1:8765/'
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add($prefix)
$listener.Start()
Write-Output "LISTENING $prefix"
while ($listener.IsListening) {
    $ctx = $listener.GetContext()
    $reqPath = $ctx.Request.Url.LocalPath.TrimStart('/')
    if ([string]::IsNullOrWhiteSpace($reqPath)) { $reqPath = 'invoice-framework-html-index.html' }
    $reqPath = $reqPath -replace '/', '\'
    $full = [System.IO.Path]::GetFullPath((Join-Path $dir $reqPath))
    $root = [System.IO.Path]::GetFullPath($dir)
    $allowed = @(
        'invoice-framework-html-index.html',
        'invoice-create-test-framework.html',
        'previous-reply-invoice-framework.html'
    )
    $name = [System.IO.Path]::GetFileName($full)
    $resp = $ctx.Response
    if (-not $full.StartsWith($root) -or ($allowed -notcontains $name) -or -not (Test-Path -LiteralPath $full)) {
        $resp.StatusCode = 404
        $bytes = [System.Text.Encoding]::UTF8.GetBytes('Not found')
        $resp.OutputStream.Write($bytes, 0, $bytes.Length)
        $resp.Close()
        continue
    }
    $bytes = [System.IO.File]::ReadAllBytes($full)
    $resp.StatusCode = 200
    $resp.ContentType = 'text/html; charset=utf-8'
    $resp.ContentLength64 = $bytes.Length
    $resp.OutputStream.Write($bytes, 0, $bytes.Length)
    $resp.Close()
}
