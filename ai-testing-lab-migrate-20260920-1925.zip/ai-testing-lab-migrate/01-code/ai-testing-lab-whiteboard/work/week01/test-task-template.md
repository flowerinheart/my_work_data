# 测试任务模板：Meridian ERP 发票创建链路

> **2026-09-19 传输层补丁：** 面试与自动化主叙事改为「POST JSON → HTTP 200 + 成功 JSON → 用 `data.id` / `data.invoiceNumber` 调查询接口」。
> 不要把成功写成 302 / Location。全文见 `work/week01b-rules/http-transport-interview-addendum.md`。
> 金额公式、权限枚举、两张表、To-Be 负向 **不变**。Meridian 页面仍可能 302，那是被测实现，适配层收成 JSON 语义即可。

## 1. 任务名称

设计开发票测试步骤

## 2. 业务链路范围

1. 进入 Accounting/Invoices 列表页，点击 New Invoice（权限校验通过后进入新建页）
2. 填写开票页面信息，点击 Save Invoice（权限校验通过后提交保存）
3. 后台生成发票号码、计算金额，`status` 初始值为 **DRAFT**，发票主表与分项表数据入库
4. **写后读：** POST JSON 保存成功（HTTP 200 + `code` 成功）后，用返回的 `data.id` 调查询接口，核对发票字段（客户、日期、行项目、金额、状态）

**范围截止：** 仅测试新建发票，到写操作返回 JSON 并用该 JSON 调查询接口为止；不测编辑、删除、录付款。

## 3. Prompt

**角色：** 财务方向 QA 质量工程师

**动作：** 基于下方 Context 和 Constraint，设计财务系统「发票新建链路」的测试步骤和验证标准框架

**输出物：** 发票新建链路的测试步骤 + 验证标准框架（含测试点、前置数据、逐步操作、预期结果、失败证据；不写自动化脚本代码）

## 4. Context

**系统与模块：** Accounting / Invoices（发票新建）

**入口与 URL：**

| 步骤 | 方法 | URL | 权限 |
|------|------|-----|------|
| 列表 | GET | `/accounting/invoices` | `ACCOUNTING_VIEW` |
| 新建表单 | GET | `/accounting/invoices/new` | `ACCOUNTING_EDIT` |
| 保存 | POST | `/accounting/invoices/save` | `ACCOUNTING_EDIT` |
| 详情 | GET | `/accounting/invoices/{uuid}` | `ACCOUNTING_VIEW` |

**权限说明（本项目）：**

- 权限枚举：`PermissionType`（不是 `InvoiceStatus`）
- `ACCOUNTING_VIEW`：可访问发票列表、详情
- `ACCOUNTING_EDIT`：可新建、保存发票；列表页「+ New Invoice」按钮也依赖此权限
- 无权限时：Spring Security 返回 **403**，页面模板为 `errors/403`（不是 list 页）

**权限测试分层（UI + API，测试设计须同时覆盖）：**

| 层级 | 测什么 | 无 `ACCOUNTING_EDIT`（对照 A） | 无 `ACCOUNTING_VIEW`（对照 B） |
|------|--------|-------------------------------|-------------------------------|
| **UI** | 页面入口与按钮可见性 | 列表页无可用「+ New Invoice」；新建页无可用 Save Invoice（隐藏或不可用） | 列表、详情、新建页均不得正常展示发票业务内容 |
| **API** | 绕过前端直接请求 | GET `/accounting/invoices/new`、POST `/accounting/invoices/save` → **403** + `errors/403`；两表无新增 | GET 列表、详情、新建及 POST save → **403**；不得读取或写入发票数据 |

> 仅有 HTTP 403 预期不够；权限场景的检查点须同时写 **页面按钮/入口** 与 **接口状态 + DB 前后对比**。

**关键表单字段：**

- 主表 `acc_invoices`：invoiceNumber、customerName、issueDate、dueDate、status、subtotal、taxRate、taxAmount、discount、total、notes
- 分项表 `acc_invoice_items`（与主表一对多，非主表列）：description、quantity、unitPrice、lineTotal
- 行项目规则：description 为空的行跳过、不入库

**服务端计算规则（As-Is，已实现）：**

1. `POST /accounting/invoices/save` 且 `form.id == null` 时：系统自动生成 `invoiceNumber = INV-{4位序号}`，`status` 初始值为 **DRAFT**
2. 金额计算：
   - `quantity ≤ 0` 时按 **0** 处理
   - `lineTotal = unitPrice × quantity`
   - `subtotal` = 该发票所有有效行 lineTotal 之和
   - `taxAmount = subtotal × taxRate ÷ 100`（保留 2 位小数，`RoundingMode.HALF_UP`）
   - `total = max(subtotal + taxAmount - discount, 0)`
3. 写入主表：customerName、issueDate、dueDate、notes、taxRate、discount、subtotal、taxAmount、total
4. 写入分项表：有效行的 description、quantity、unitPrice、lineTotal

**前端页面规则（As-Is，已实现）：**

- 前端 HTML `required`：目前主要是 **customerName**
- 前端 input `min="0"`：quantity、unitPrice、taxRate、discount（仅浏览器层）
- 保存成功（面试/自动化口径）：HTTP **200**，JSON `code` 成功，`data` 含 `id`、`invoiceNumber`、`status=DRAFT`；再用 `data.id` 或 `data.invoiceNumber` 调查询接口
- 详情展示：发票号、客户、日期、行项目、Subtotal/Tax/Discount/Total、DRAFT 状态

**金额验证与裁决标准（测试设计须遵守，AI 不得擅自改写）：**

| 阶段 | 对照关系 | 不一致时 |
|------|----------|----------|
| **保存前**（POST save 之前，尚无 DB 落库） | form 底部 **Alpine 预览**（Subtotal / Tax / Total）= 按 Context 公式 **手算期望值** | 记缺陷 |
| **保存后** | **详情页展示**的金额字段 = DB `acc_invoices` 对应落库值（subtotal、taxAmount、discount、total 等） | 记缺陷 |
| **跨阶段** | 保存前记录的 Alpine 与保存后 DB 落库值 | 若不一致，记缺陷（不得跳过页面核对、单方面写「以 DB 为准」） |

金额验证步骤须分别列出：**手算过程**、保存前 **Alpine 记录**、保存后 **详情页值**、**DB SELECT 字段**及失败证据。

**系统已实现校验缺口（As-Is，读代码确认）：**

- 服务端未见对「未来 issueDate」的统一拦截
- 服务端未见对负 taxRate、负 discount 的统一拦截
- 服务端未见对「无有效行项目仅填 customerName」的统一拦截

> 以上缺口不影响 To-Be 测试设计；执行时若未拦截，按「预期缺陷」记录。

## 5. Constraint

**范围边界：** 只测新建（`form.id == null`），不测编辑、删除、录付款

**依赖与前提：**

- 测试账号：具备 `ACCOUNTING_VIEW` + `ACCOUNTING_EDIT`（可用：admin@erp.com / Admin@1234）
- 权限对照账号 A：具备 `ACCOUNTING_VIEW`，但没有 `ACCOUNTING_EDIT`
  - **UI 预期：** 列表页无可用「+ New Invoice」；新建页无可用 Save Invoice
  - **API 预期：** 可访问 `/accounting/invoices` 和已存在发票详情页
  - **API 预期：** 访问 `/accounting/invoices/new` 返回 403
  - **API 预期：** 直接 POST `/accounting/invoices/save` 返回 403，且不得新增发票主表或分项表数据
- 权限对照账号 B：没有 `ACCOUNTING_VIEW`，也没有 `ACCOUNTING_EDIT`
  - **UI 预期：** 列表、详情、新建页均不得正常展示发票业务内容
  - **API 预期：** 访问 `/accounting/invoices` 返回 403
  - **API 预期：** 访问 `/accounting/invoices/new` 返回 403
  - **API 预期：** 访问 `/accounting/invoices/{uuid}` 返回 403
  - **API 预期：** 直接 POST `/accounting/invoices/save` 返回 403，且不得新增发票主表或分项表数据
- 测试环境：可访问 Meridian ERP Web 应用
- 数据准备：合法客户名至少 1 个，有效分项数据至少 1 条（description 非空）

**业务规则 / 期望行为（To-Be，财务测试基准）：**

> 以下按财务业务常识设计测试，不因当前代码未实现而省略。若系统未拦截，记录为缺陷。

1. **未来 issueDate 应被拦截**（前端或服务端均可，但必须阻止错误数据落库）
2. **负税率、负折扣、负数量、负单价应被拦截**（不能仅依赖浏览器 `min="0"`，需验证绕过前端后的行为）
3. **必填项未完整时应阻止保存**（至少 customerName + 至少 1 条有效行项目）
4. **权限不足时应拒绝访问**（403），不得执行后续业务逻辑

**禁止项：**

- 不要修改源码或数据库结构
- 不要测试 edit / delete / payment 链路
- 不要把「代码没校验」当成「不需要测」
- 不要输出自动化脚本代码（本任务仅要步骤 + 验证框架）

## 6. Acceptance Criteria

- [ ] AC-1：输出物包含完整测试步骤（列表 → 新建 → 填表 → 保存 → 详情验证）
- [ ] AC-2：每个关键步骤有明确验证点与失败证据（页面元素 / HTTP 状态 / DB 字段）
- [ ] AC-3：覆盖正向路径（合法数据新建成功）
- [ ] AC-4：覆盖权限负向（无 EDIT 时 UI 无新建/保存入口；绕过前端时 `/new`、POST save 返回 403；无 VIEW 时列表/详情亦 403）
- [ ] AC-5：覆盖业务规则负向（负税率、负折扣、未来 issueDate——按 To-Be 期望写断言；若系统未拦截则标注「预期缺陷」）
- [ ] AC-6：金额验证引用 Context 公式与「金额验证与裁决标准」：保存前 Alpine=手算；保存后详情=DB；须含手算过程与失败证据

## 7. 预期 AI 交付物

一份结构化文档，包含：

1. **测试范围与前提**（账号、权限、数据准备）
2. **测试步骤**（逐步操作说明）
3. **验证标准框架**（每步：预期结果、检查点、失败证据）
4. **测试维度说明**（正向 / 权限 / 边界 / 业务规则负向）
5. **风险与待确认项**（含 As-Is 与 To-Be 不一致处，标注为潜在缺陷）

### 7.1 AI 交付物标准输出表结构

AI 必须按下面字段输出，不得只写流水账：

| 场景编号 | 场景名称 | 前置数据 | 操作步骤 | 预期结果 | 检查点 | 失败证据 | 风险类型 |
|----------|----------|----------|----------|----------|--------|----------|----------|
| INV-CREATE-001 | 合法数据新建发票成功 | 具备 `ACCOUNTING_VIEW + ACCOUNTING_EDIT`；金数据来自已冒烟库（先回滚再重放） | 列表 → 新建 → 按金数据填字段 → POST JSON 保存 → **用返回 JSON 的 id 调查询接口** | HTTP **200** 且 `code` 成功；`data.id` / `data.invoiceNumber` 可查询；`status=DRAFT`；号匹配 `INV-\d{4}`；主表和分项落库；查询 id = DB 主键 | HTTP 200 + JSON；查询 JSON；`acc_invoices`、`acc_invoice_items` | 请求 JSON、响应 JSON、DB 查询结果 | 正向链路 / 数据落库 |
| INV-AUTH-001 | 有 VIEW 无 EDIT 不能新建 | 账号只有 `ACCOUNTING_VIEW`，没有 `ACCOUNTING_EDIT` | **UI：** 列表无「+ New Invoice」、新建页无可用 Save。**API：** 直接 GET `/accounting/invoices/new` 或 POST `/accounting/invoices/save` | UI 无新建/保存入口；接口 **403** + `errors/403`；不得新增发票数据 | 按钮可见性、HTTP 403、无新增 invoiceNumber、无新增 item | 账号权限、页面截图、请求/响应、DB 前后对比 | 权限 / 越权写入 |
| INV-AUTH-002 | 无 VIEW 无 EDIT 不能访问发票模块 | 账号没有 `ACCOUNTING_VIEW`，也没有 `ACCOUNTING_EDIT` | **UI：** 列表/详情/新建均不得正常展示业务内容。**API：** GET 列表、详情、新建或直接 POST 保存 | 四处均为 **403** + `errors/403`；不得读取或写入发票数据 | 页面表现、HTTP 403、页面模板、DB 无新增 | 账号权限、请求、响应、DB 前后对比 | 权限 / 越权读取 / 越权写入 |
| INV-AMT-001 | 金额计算正确 | 合法客户；有效行项目；明确税率和折扣 | 保存前记录 Alpine；Save；保存后核对详情与 DB | 保存前 Alpine=手算；保存后详情=DB；均符合 Context 公式 | Alpine 记录、详情页、DB 字段、手算过程 | 手算底稿、页面值、DB 值、差异记录 | 金额精度 / 数据一致性 |
| INV-NEG-001 | 负数类输入应被拦截 | 绕过浏览器限制，构造负 taxRate / discount / quantity / unitPrice | 直接提交表单 | To-Be：应拒绝保存；若未拒绝，记录为预期缺陷 | HTTP 状态、错误提示、DB 是否落库 | 请求参数、响应、DB 前后对比、缺陷描述 | 边界值 / 财务风险 |
| INV-DATE-001 | 未来开票日应被拦截 | 构造未来 issueDate | 提交保存 | To-Be：应拒绝保存；若未拒绝，记录为预期缺陷 | HTTP 状态、错误提示、DB 是否落库 | 请求参数、响应、DB 前后对比、缺陷描述 | 业务规则 / 财务合规 |
