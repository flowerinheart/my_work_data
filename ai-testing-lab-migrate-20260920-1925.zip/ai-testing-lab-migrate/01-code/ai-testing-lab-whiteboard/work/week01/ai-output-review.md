# 一次 AI 输出审查记录

> **M1 阶段成果** · 发票新建链路  
> **审查对象：** 将 `test-task-template.md` 作为 Prompt+Context+Constraint+AC 喂给 AI 后，对 **AI 初稿输出** 做 QA 审查（非审模板本身）  
> **审查方式：** 对照真实 AI 初稿（`invoice-create-test-framework.html`）+ template §6 AC 与 §7.1 表结构

---

## 1. 审查元信息

| 项 | 内容 |
|----|------|
| 使用的模板 | `work/week01/test-task-template.md` |
| 给 AI 的任务（Prompt 摘要） | 财务 QA；基于 Context/Constraint 设计发票新建测试步骤与验证框架；不写自动化脚本 |
| 审查日期 | 2026-09-01 |
| 审查人 | 自审 |
| 审查结论 | **需修订后可用**（结构尚可，缺 DB 证据、部分假设错误、负向不完整） |

---

## 2. AI 初稿输出摘要（模拟典型初稿）

> 以下为 **无 M2 Rules**、仅喂 `test-task-template.md` 时，真实 AI 会话产出的初稿要点（完整版见 `invoice-create-test-framework.html`）。

```
【测试范围与前提】
范围：列表 → New Invoice → 填表 → Save Invoice → 详情页字段与 DB 核对。截止保存后详情，不含 edit / delete / payment。

环境：可访问的 Meridian ERP Web。

账号|PermissionType|用途
admin@erp.com / Admin@1234|ACCOUNTING_VIEW + ACCOUNTING_EDIT|正向、金额、To-Be 负向
对照 A|仅 ACCOUNTING_VIEW|列表/详情可读；/new 与 POST /save 须 403
对照 B|无 VIEW、无 EDIT	|列表、新建、详情、POST save 均 403

数据准备：合法 customerName ≥ 1；有效行（description 非空）≥ 1。负向场景另造负值、未来日期、空行、无有效行。
执行前基线：记录 acc_invoices、acc_invoice_items 行数（及最大 invoiceNumber），用于「不得新增」对照。


【步骤】
列表：主账号登录 → GET /accounting/invoices → 页面出现「+ New Invoice」。
新建：点击进入 GET /accounting/invoices/new（须 200，非 403）。
填表：填 customerName、issueDate、dueDate、≥1 条有效行、taxRate、discount；保存前记下 Alpine 预览的 Subtotal / Tax / Total。
保存：POST /accounting/invoices/save（表单，非 JSON API）。
详情：302 至 /accounting/invoices/{uuid}；核对号、客户、日期、行、金额、DRAFT；再 SELECT 主表/分项，且 URL 中 uuid 等于主表主键。
负向与权限不走通这条 happy path，见 §7.1。

【验证标准框架】
前置说明：金额一律按 Context 公式手算；以 DB 为最终裁决。Alpine 与详情不一致时记差异，不以页面预览判 pass。

手算基准（INV-AMT-001）：行 Widget A qty=2 unitPrice=100.00 → lineTotal=200.00；taxRate=10 discount=5.00 → subtotal=200.00 taxAmount=20.00 total=215.00。
除不尽（INV-AMT-002）：qty=1 unitPrice=1.00 taxRate=7.5 discount=0 → taxAmount=0.075→HALF_UP 0.08 total=1.08。

§7.1 场景表（八列结构，摘要）：
- INV-CREATE-001：正向新建；步骤到 Save；预期写 302+DRAFT+落库；检查点含 HTTP/详情/DB，但未单独强调跳转 URL uuid 与 invoiceNumber 格式 INV-\d{4}
- INV-CREATE-002：description 空行跳过不入库
- INV-AUTH-001：VIEW 无 EDIT；步骤混写列表观察按钮 + GET /new + POST save + GET 详情；预期 403+errors/403+DB 不变
- INV-AUTH-002：无 VIEW 无 EDIT；列表/new/详情/POST save 均 403
- INV-AMT-001：保存前 Alpine、保存后详情、再查 DB；三处 200/20/5/215；以 DB 为准
- INV-AMT-002：HALF_UP taxAmount=0.08
- INV-AMT-003：qty≤0 按 0；total=max(...,0)
- INV-NEG-001：绕过 min=0 构造负 taxRate/discount/qty/unitPrice；To-Be 拦截，As-Is 落库标预期缺陷
- INV-DATE-001：未来 issueDate；To-Be 拦截
- INV-REQ-001/002：customerName 空、无有效行；绕过前端 POST

【测试维度说明】
正向 INV-CREATE-001/002：302、DRAFT、INV-\d{4}、uuid=主键、空行跳过
权限 INV-AUTH-001/002：403+errors/403；A 可 VIEW 详情；B 全拒；DB 不增
金额 INV-AMT-001～003：公式、HALF_UP、Alpine/详情/DB、qty≤0、total 下限 0
业务规则负向 INV-NEG/DATE/REQ：绕过前端；未拦截标预期缺陷

【风险与待确认项（As-Is vs To-Be）】
未来 issueDate：As-Is 未见统一拦截 → To-Be 须阻止 → 未拦记预期缺陷
负 taxRate/discount/qty/unitPrice：前端 min=0；服务端未见统一拦截 → 绕过 POST；落库负值记缺陷
无有效行仅 customerName：As-Is 未见统一拦截 → 主表新增无分项记缺陷
Alpine vs 服务端：预览在浏览器 → 以 DB 为准 → 三处不一致单独记
total=max(...,0)：大折扣须得 0 非负数

禁止：改代码/改表、测 edit/delete/payment、把「代码没校验」写成「不必测」、输出自动化脚本。
```

---

## 3. 审查维度与发现

### 3.1 假设与事实错误（AI 擅自编造或搞错）

【测试范围与前提】

| # | AI 初稿表述 | 问题类型 | 对照 Context/代码 | 审查意见 |
|---|-------------|----------|-------------------|----------|
| A1 | 
「账号：仅 ACCOUNTING_VIEW； 用途：列表/详情可读；/new 与 POST /save 须 403」【账号：无 VIEW、无 EDIT；用途：列表、新建、详情、POST save 均 403】    | 
**权限说明（本项目）：**`ACCOUNTING_EDIT`：可新建、保存发票；列表页「+ New Invoice」按钮也依赖此权限 | 
应为【仅 ACCOUNTING_VIEW：列表/详情可读；详情页new invoice按钮及表单页save按钮屏蔽；/new 与 POST /save 须 403】【无 VIEW、无 EDIT：列表、详情POST 均 403；详情页new invoice按钮及表单页save按钮屏蔽；/new 与 POST /save 须 403 】，权限测试必须覆盖：前端展示+绕过前端后端请求403 |

【验证标准框架】

| A2 | 
【前置说明中：金额一律按 Context 公式手算；以 DB 为最终裁决。Alpine 与详情不一致时记差异，不以页面预览判 pass】【INV-AMT-001：操作步骤：保存前记 Alpine；保存后看详情；再查 DB。预期结果：三处均为 200.00 / 20.00 / 5.00 / 215.00；以 DB 为准】|    
AI擅自推论了 裁决标准和差异记录 | 
Context 里未写三处金额以谁为准、不一致如何记缺陷，属 Context 遗漏；AI 擅自推论「以 DB 为最终裁决」 | 
需在 Context 补充：保存前 Alpine=手算；保存后详情=DB；任一对不一致记缺陷（不宜在 Context 未约定前写「以 DB 为准」） |

| A3 | 
【INV-AUTH-001：
操作步骤：1) GET /accounting/invoices 2) 观察是否无「+ New Invoice」 3) GET /accounting/invoices/new 4) 直接 POST /accounting/invoices/save（合法表单） 5) GET 已有详情 /accounting/invoices/{uuid}。
预期结果：列表 200 且无新建入口；/new 与 POST save 均为 403 + errors/403；详情 200 可读；两表行数不变、无新 invoiceNumber】| 
**前端按钮与接口请求表述混乱** | 
 前端context要求：
 `ACCOUNTING_EDIT`：可新建、保存发票；列表页「+ New Invoice」按钮也依赖此权限
 后端context要求：
 - 权限对照账号 A：具备 `ACCOUNTING_VIEW`，但没有 `ACCOUNTING_EDIT`
  - 预期：可访问 `/accounting/invoices` 和已存在发票详情页
  - 预期：访问 `/accounting/invoices/new` 返回 403
  - 预期：直接 POST `/accounting/invoices/save` 返回 403，且不得新增发票主表或分项表数据
- 权限对照账号 B：没有 `ACCOUNTING_VIEW`，也没有 `ACCOUNTING_EDIT`
  - 预期：访问 `/accounting/invoices` 返回 403
  - 预期：访问 `/accounting/invoices/new` 返回 403
  - 预期：访问 `/accounting/invoices/{uuid}` 返回 403
  - 预期：直接 POST `/accounting/invoices/save` 返回 403，且不得新增发票主表或分项表数据
  注明：context内容本身存在不明确指出前端测试点的情况，需修订 | 
前端按钮与接口请求表述混乱。前端应为按钮+页面加载，后端应该绕过前端直接用无权限账号请求 接口403状态码+DB不入库核对。|

| A4 | 
[INV-CREATE-001]:整体缺失保存成功后跳转详情页的核对(跳转URL链接+链接中的UUID+详情页数据展示核对)。检查点中缺失发票号生成格式INV-\d{4} | **遗漏 As-Is 规则：1、服务端计算规则，第一条中的发票号。2、前端页面规则： 保存成功后跳转及详情页展示** | As-Is 规则：服务端计算规则：1. `POST /accounting/invoices/save` 且 `form.id == null` 时：系统自动生成 `invoiceNumber = INV-{4位序号}`，`status` 初始值为 **DRAFT**  前端页面规则： 保存成功：302 跳转 `/accounting/invoices/{uuid}`
- 详情页展示：发票号、客户、日期、行项目、Subtotal/Tax/Discount/Total、DRAFT 状态 | 须增加发票号校验，及跳转详情页 |

| A5 | 未写 save 成功为 **302** | **HTTP 假设错误** | POST save 成功为 302 跳转详情，非 200 JSON | 预期结果须写 302 + Location 含 uuid |
| A6 | 未区分 PermissionType 与 InvoiceStatus | **概念混淆风险** | 权限是 ACCOUNTING_VIEW/EDIT | 步骤须写 PermissionType，不写发票 status 当权限 |



### 3.2 遗漏（相对 template AC）

| AC | 要求 | AI 初稿是否满足 | 遗漏说明 |
|----|------|-----------------|----------|
|AC-2 | 每个关键步骤有明确验证点与失败证据（页面元素 / HTTP 状态 / DB 字段） | 部分 | 【测试范围与前提】里，无权限账号漏写排查页面按钮|

| AC-1 | 输出物包含完整测试步骤（列表 → 新建 → 填表 → 保存 → 详情验证） | 部分 | 只有列表 → 新建 → 填表 → 保存，缺失详情验证。被AC-3：覆盖正向路径（合法数据新建成功）误导，只测到了新建成功，而忽视了第一条的全链路要求 |


### 3.3 不可验证内容（空话）

暂未发现


### 3.4 范围与交付物

| 项 | 审查结果 |
|----|----------|
| 是否越界 edit/delete/payment | 初稿未越界 ✅ |
| 是否输出自动化脚本 | 未输出 ✅ |
| 是否符合 §7.1 表结构 | 是，结构符合 |

---

## 4. 对照 §7.1 场景表的覆盖度

| 场景编号 | 模板要求 | AI 初稿 |
|----------|----------|---------|
| INV-CREATE-001 | 正向 + DB 落库 | 缺少跳转详情页及详情页展示 |
| INV-AUTH-001 | VIEW 无 EDIT | 有，但前后端分别表述不够清晰，系context本身内容缺失 |
| INV-AUTH-002 | 无 VIEW 无 EDIT | 完整 |
| INV-AMT-001 | 公式 + 手算 + DB | 错以DB入库为基准，且缺失公式 + 手算 + DB对比 |
| INV-NEG-001 | 负数 + 绕过前端 | 完整 |
| INV-DATE-001 | 未来日期 |完整 |

**覆盖率：** 约 3/6 场景达标，3/6 缺失或不合格。

---

## 5. 修订要求（交给 AI 或自己改的第二版清单）

1. **权限账号表（A1）**  
   - 对照 A（仅 VIEW）：列表/详情可读；列表无「+ New Invoice」、新建页 Save 按钮不可用；绕过前端 GET `/new` 与 POST `/save` 须 **403** + `errors/403`，两表行数不变。  
   - 对照 B（无 VIEW 无 EDIT）：列表、详情、新建、POST save 均 **403**；前端按钮同样屏蔽；不得读出发票内容、不得落库。

2. **权限步骤拆分（A3）**  
   - **前端**：有/无 EDIT 时「+ New Invoice」、Save Invoice 可见性与可点击性。  
   - **后端**：无权限账号直接请求接口 → HTTP 403 + DB 前后 count / 无新 `invoiceNumber`；有 VIEW 无 EDIT 时详情 GET 仍 200。

3. **金额裁决标准（A2）**  
   - 不在 AI 输出中擅自定义「以 DB 为最终裁决」；应在 Context 或修订说明中写明：  
     - 保存前：Alpine 预览与手算一致；  
     - 保存后：详情展示与 DB 入库一致；  
     - 三处（Alpine / 详情 / DB）须分别列出检查点，差异记缺陷。

4. **INV-CREATE-001 补全（A4、A5）**  
   - 预期须写 POST save 成功 → **302**，`Location=/accounting/invoices/{uuid}`。  
   - 详情页核对：`invoiceNumber` 匹配 `INV-\d{4}` 且系统生成；`status=DRAFT`；URL uuid = DB 主键；分项外键一致。

5. **概念用语（A6）**  
   - 权限一律写 `PermissionType`（`ACCOUNTING_VIEW` / `ACCOUNTING_EDIT`），不得与 `InvoiceStatus`（DRAFT 等）混用。

6. **AC-1 / AC-2 对齐**  
   - §7.1 正向场景步骤须覆盖「列表 → 新建 → 填表 → 保存 → **详情验证**」全链路，不能停在「新建成功」。  
   - 每个关键步骤写明失败证据：页面元素 / HTTP 状态 / DB 字段；无权限场景须含**页面按钮**检查点。

7. **第二版可选增强（对照 §6 结论）**  
   - 补充：保存前后数据快照、主表/分项一致性（`sum(line_total)=subtotal`）、UUID 跳转一致性、幂等/并发（RULE-TEST-012）、非法 UUID（RULE-TEST-011）——若 Context 未要求可标「范围外」，但须在修订说明中注明。

---

## 6. 审查结论

| 项 | 结论 |
|----|------|
| 能否直接用于执行测试 | **不能** — 权限判定前后端逻辑不够清晰、金额校验手算+页面+DB核对须修正、缺少/save前后数据快照用于页面和DB比对、缺少数据一致性测试、缺少落表主键唯一性测试、缺少UUID专门测试、缺少幂等和并发等 |
| 模板本身是否有效 | **有效** — 问题在 AI 未遵守 Context/AC；补 M2 Rules 后可减少同类遗漏 |
| 建议下一步 | 用修订清单要求 AI 出第二版 |

---

## 7. 与 M2 Rules 的衔接（可选备注）

若第二版 Prompt 同时附带 `work/week01b-rules/testing-rules.md` + `data-and-db-rules.md`，预期可改善初稿中的同类遗漏：

| 初稿问题 | 对应 Rule | 预期改善 |
|----------|-----------|----------|
| 权限只写接口、漏按钮（A1/A3） | RULE-TEST-006（UI 可见性）、RULE-TEST-007（403/302 + DB） | 强制 VIEW-only / 无权限两套 UI + HTTP 表 |
| 金额只验详情或擅自「DB 裁决」（A2） | RULE-TEST-001（公式）、RULE-TEST-004（Alpine/详情/DB 三处） | 手算 + 三处对照表，差异记录方式明确 |
| 缺 HALF_UP、qty≤0（INV-AMT-002/003） | RULE-TEST-003 | 除不尽用例 + DB `tax_amount` 2 位小数 |
| 缺 invoiceNumber / DRAFT / 302（A4/A5） | RULE-TEST-005、RULE-TEST-007、RULE-TEST-016 | `INV-\d{4}`、302 跳转、URL uuid = DB id |
| To-Be 负向未标缺陷 | RULE-TEST-002、010 | 绕过前端 + 未拦截写「预期缺陷」 |
| 缺主明细一致、字段落库 | RULE-TEST-013、014、RULE-DB-004 | `sum(line_total)`、非金额字段页面/DB 对比 |
| 403 未查库 | RULE-DB-003 | 权限负向后 `acc_invoices` / `acc_invoice_items` count 不变 |

**实验建议：** 用同一 `test-task-template.md` 分别跑「无 Rules」与「带 Rules」两轮，把 §2 初稿摘要替换为真实 AI 输出，在本节追加「加 Rules 前后 diff」一栏（场景覆盖数、403+DB、三处对照是否齐全）。

**可在真跑 AI 后在此追加一栏：「加 Rules 前后输出对比」。**

---

## 8. 自检（M1 验收）

- [x] 能指出 AI 输出中的假设、遗漏、不可验证内容  
- [x] 对照了 prompt / context / constraint / AC 的区别（见假设表与 AC 表）  
- [x] 审查对象是可复用的任务模板之 **AI 交付物**，不是源码  
- [x] （可选）已用真实 AI 会话替换第 2 节（完整交付物：`invoice-create-test-framework.html`）
