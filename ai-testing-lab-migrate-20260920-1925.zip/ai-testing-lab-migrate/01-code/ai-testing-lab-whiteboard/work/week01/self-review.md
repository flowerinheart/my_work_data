# 第 1 周自检：test-task-template.md

> 说明：复盘本模板能防止 AI 犯哪些错误，以及 As-Is / To-Be 不一致处如何处理。

---

## 1. 总览

| 检查项 | 是否做到 | 备注 |
|--------|----------|------|
| 四块齐全（Prompt / Context / Constraint / AC） | ☑ | template §3～§6 均已覆盖 |
| Context 与 Constraint 区分 As-Is / To-Be | ☑ | Context 写已实现与缺口；Constraint 写 To-Be |
| 业务链路有明确截止点 | ☑ | §2 四步 + 「不测编辑、删除、录付款」 |
| AC 可验证、无重复编号 | ☑ | AC-1～AC-6，编号无重复 |
| 预期 AI 交付物与 Prompt 输出物一致 | ☑ | §3 输出物与 §7 五段结构一致 |

---

## 2. 分块自检

### Prompt

| 若没有 | AI 可能犯的错误 | 我的模板怎么防 |
|--------|-----------------|----------------|
| 明确角色 | 以开发身份改代码，或输出 PRD | §3 限定「财务方向 QA 质量工程师」 |
| 明确动作 | 只写结论、缺少测试维度与风险 | §3 要求基于 Context + Constraint 设计步骤与验证框架 |
| 明确输出物 | 输出自动化脚本、单元测试或再写一份 template | §3 明确：测试步骤 + 验证标准框架，不写脚本代码 |

### Context

| 若没有 | AI 可能犯的错误 | 我的模板怎么防 |
|--------|-----------------|----------------|
| URL + 权限表 | 测错接口、把表单 POST 当 JSON API | §4 列出 4 个 URL + PermissionType 权限表 |
| 403 行为 | 无权限时期望 list 页 | §4 写明 403 + `errors/403` |
| 金额公式 As-Is | 期望值算错、误判 pass/fail | §4 写清 quantity≤0、subtotal/tax/total、HALF_UP |
| 空行跳过规则 | 以为 5 行空白都会入库 | §4 写明 description 为空则跳过 |
| As-Is 缺口说明 | 把代码缺失当成「设计如此」 | §4「系统已实现校验缺口」三条 + 预期缺陷说明 |

### Constraint

| 若没有 | AI 可能犯的错误 | 我的模板怎么防 |
|--------|-----------------|----------------|
| 范围边界 | 顺带测 edit / delete / payment | §5 限定 `form.id == null`，仅新建 |
| To-Be 业务规则 | 代码没校验就不写负向用例 | §5 To-Be 四条：未来日期、负数、必填、403 |
| 依赖与前提 | 步骤无法复现 | §5 写账号、环境、数据准备（含 admin@erp.com） |
| 禁止项 | 输出脚本或改源码/库 | §5 禁止改代码、不测其他链路、不把缺口当不测理由 |

### Acceptance Criteria

| 若没有 | AI 可能犯的错误 | 我的模板怎么防 |
|--------|-----------------|----------------|
| 完整链路 AC | 只写保存一步 | AC-1 要求列表→新建→填表→保存→详情 |
| 可验证 AC | 写「测试通过」无检查点 | AC-2 要求页面元素 / HTTP / DB 证据 |
| 正向 AC | 缺少 happy path | AC-3 覆盖合法数据新建成功 |
| 权限负向 AC | 绕过鉴权或测错无权限页 | AC-4 要求无 EDIT 时出现 403 |
| To-Be 负向 AC | 负税率/未来日期未测 | AC-5 要求按 To-Be 断言，未拦截标「预期缺陷」 |
| 金额 AC | 混淆页面预览与落库值 | AC-6 要求引用公式并区分 Alpine vs 服务端 |

---

## 3. As-Is / To-Be 不一致项（潜在缺陷清单）

| # | 场景 | To-Be 期望 | As-Is（代码） | 模板中是否已写 |
|---|------|------------|---------------|----------------|
| 1 | 未来 issueDate | 应拦截，阻止落库 | 服务端未见统一拦截 | ☑ Context 缺口 + Constraint To-Be #1 + AC-5 |
| 2 | 负 taxRate | 应拒绝保存 | 前端 min=0，服务端未必拦截 | ☑ Context 缺口 + Constraint To-Be #2 + AC-5 |
| 3 | 负 discount | 应拒绝保存 | 前端 min=0，服务端未必拦截 | ☑ 同上 |
| 4 | 负 quantity / unitPrice | 应拒绝保存 | 前端 min=0；服务端 qty≤0 按 0 处理，未必拒保存 | ☑ Constraint To-Be #2 + AC-5 |
| 5 | 无有效行项目仅填 customerName | 应阻止保存 | 前端 mainly required customerName | ☑ Context 缺口 + Constraint To-Be #3 + AC-5 |
| 6 | 权限不足访问新建/保存 | 403，不执行业务 | Spring Security → errors/403 | ☑ Context + Constraint To-Be #4 + AC-4 |

---

## 4. 典型场景自检（完整示例）

### 场景 A：负税率

- **若没有 To-Be：** AI 看到浏览器 min=0 或服务端未拦截，就写「符合预期 pass」
- **我的模板怎么防：**
  - Context As-Is 缺口：服务端未见对负 taxRate 的统一拦截
  - Constraint To-Be #2：负税率应被拦截，且需验证绕过前端后的行为
  - AC-5：未拦截时标注「预期缺陷」
  - AC-6：若误入库，用公式核对 taxAmount 是否被错误计算

### 场景 B：无 EDIT 权限访问 /new

- **若没有权限说明：** AI 在 list 页找「无权限提示」，测错对象
- **我的模板怎么防：**
  - Context 权限表 + 403 / errors/403
  - Constraint 依赖与前提：提供仅有 VIEW 的对照账号
  - AC-4：明确要求出现 403

### 场景 C：金额验证

- **若没有 As-Is 公式：** AI 用页面 Alpine 预览值当最终断言，与服务端 HALF_UP 结果不一致
- **我的模板怎么防：**
  - Context 写清完整计算公式与 quantity≤0 规则
  - AC-6 明确要求区分 Alpine 预览与服务端落库值

---

## 5. 已知可改进点（非阻塞）

| 项 | 说明 |
|----|------|
| 权限对照账号 | template 已拆成「有 VIEW 无 EDIT」和「无 VIEW 无 EDIT」两类；执行时需从系统角色中选择或临时构造对应账号 |
| 绕过前端负向 | To-Be 要求绕过浏览器 min=0，AI 交付物应说明如何构造（如改 HTML 或用工具直接 POST 表单） |
| AI 输出表结构 | template 已补充标准输出字段：场景编号、场景名称、前置数据、操作步骤、预期结果、检查点、失败证据、风险类型 |
| 第 1 周边界 | 本模板设计的是「喂 AI 的任务说明书」，不是完整测试计划（第 2 周范围） |

---

## 6. 提交前最后检查

- [x] `prompt-context-constraint-ac.md` 四块说明与 `test-task-template.md` 一致，无矛盾
- [x] 未把 InvoiceStatus 和 PermissionType 混用
- [x] Prompt 的「输出物」与 §7 预期 AI 交付物一致
- [x] 三个文件均位于 `work/week01/`
- [ ] 去 evaluator 提交：`请验证白板区 work/week01 的学习成果。`
