# Meridian ERP 交易链路测试规则

> 练习范围：**发票新建链路为主**（invoice）
> 每条规则必须可执行、可检查；禁止「尽量」「完善」「高质量」等空泛词。
> Rule ID 统一格式：`RULE-TEST-XXX`（连字符，三位编号）

---

## 规则清单

| 方向 | Rule ID | 主题 |
|------|---------|------|
| 金额精度 | RULE-TEST-001～004 | 公式 / To-Be 负值 / HALF_UP / 三处对照 |
| 发票状态 | RULE-TEST-005 | DRAFT + invoiceNumber |
| 权限 | RULE-TEST-006～007 | 页面可见性 + HTTP 状态 |
| 异常入参 | RULE-TEST-008～011 | 空值 / 超长 / 负数 / 日期 / 非法 UUID |
| 重复提交 | RULE-TEST-012 | 幂等 + 双会话 |
| 数据一致性 | RULE-TEST-013～016 | 金额 / 字段 / 写后读 id |

---

## 第 1 组：金额精度

### RULE-TEST-001

| 字段 | 内容 |
|------|------|
| **Rule ID** | RULE-TEST-001 |
| **规则内容** | 凡 invoice 金额测试步骤，必须按下列公式构造期望值并核对 DB 落库：`lineTotal = unitPrice × quantity`（quantity ≤ 0 按 0）；`subtotal` = 所有有效行 lineTotal 之和；`taxAmount = subtotal × taxRate ÷ 100`（HALF_UP，2 位小数）；`total = max(subtotal + taxAmount − discount, 0)`。 |
| **适用范围** | invoice |
| **为什么需要** | 防止 AI 公式写错、漏验 max(…,0) 或 quantity≤0 规则 |
| **违反规则的例子** | 步骤写 `total = subtotal − taxAmount − discount`；或未核对 DB 中 total/subtotal/taxAmount |
| **验收方式** | 文档含公式引用 + 至少 1 组手算 + DB 字段对比；公式或字段缺任一项 → 违反 |

### RULE-TEST-002

| 字段 | 内容 |
|------|------|
| **Rule ID** | RULE-TEST-002 |
| **规则内容** | 凡 invoice 负向数据测试，必须覆盖：① description 空行不入库；②【To-Be】quantity、unitPrice、taxRate、discount 为负数时须拦截（含绕过前端 min=0 的 POST）；③【To-Be】无有效行项目仅填 customerName 时须阻止保存。若 As-Is 未拦截，标注「预期缺陷」而非判 pass。 |
| **适用范围** | invoice |
| **为什么需要** | 防止只测前端 min=0、漏测空行入库与 To-Be 财务负向 |
| **违反规则的例子** | 只写「输入负数点保存」未写绕过前端；或 DB 存负数仍写「符合预期」 |
| **验收方式** | 文档含空行/负数/无分项三类中至少两类 + 绕过前端说明 + 未拦截时的缺陷标注方式 |

### RULE-TEST-003

| 字段 | 内容 |
|------|------|
| **Rule ID** | RULE-TEST-003 |
| **规则内容** | 凡 invoice 金额精度测试，必须包含除不尽场景（如 subtotal=100、taxRate=7.5），手算 HALF_UP 后的 taxAmount，并分别核对详情页与 DB `acc_invoices.tax_amount`；lineTotal/subtotal/taxAmount/total 在 DB 中均不得超过 2 位小数。 |
| **适用范围** | invoice |
| **为什么需要** | 防止只测整数、不测四舍五入与 DB 精度 |
| **违反规则的例子** | 步骤写「tax=7.5% 通过」但无手算过程、无 DB tax_amount 查询 |
| **验收方式** | 文档含除不尽场景 + 手算过程 + 页面/DB 对比表；缺任一项 → 违反 |

### RULE-TEST-004

| 字段 | 内容 |
|------|------|
| **Rule ID** | RULE-TEST-004 |
| **规则内容** | 凡 invoice 新建 save 的金额验证，必须三处对照：① 保存前 form 底部 Alpine 预览（Subtotal/Tax/Total）；② 保存后详情页展示；③ DB `acc_invoices` 对应字段。以 DB 为最终裁决，不一致须记录差异。 |
| **适用范围** | invoice |
| **为什么需要** | 防止只验页面预览或只验详情，漏掉 Alpine 与服务端差异 |
| **违反规则的例子** | 只写「详情页 total 正确」，未写 form 预览对比或未查 DB |
| **验收方式** | 步骤含三处对照表或等价检查点；少于三处 → 违反 |

---

## 第 2 组：发票状态

### RULE-TEST-005

| 字段 | 内容 |
|------|------|
| **Rule ID** | RULE-TEST-005 |
| **规则内容** | 凡 **invoice 新建**（`form.id == null`）保存后，必须断言：`status = DRAFT`；`invoiceNumber` 匹配 `INV-\d{4}` 且系统生成（新建表单不可手填）。付款后 status 变 PARTIAL/PAID 为【范围外】，本练习可不写步骤。 |
| **适用范围** | invoice（仅新建） |
| **为什么需要** | 防止漏验初始状态与发票号格式 |
| **违反规则的例子** | 只验 customerName，未写 status/invoiceNumber 检查点 |
| **验收方式** | 新建步骤含详情或 DB 对 status、invoiceNumber 的明确断言 |

---

## 第 3 组：权限

### RULE-TEST-006

| 字段 | 内容 |
|------|------|
| **Rule ID** | RULE-TEST-006 |
| **规则内容** | 凡 invoice 权限 UI 测试，必须对照 PermissionType：有 `ACCOUNTING_EDIT` 时列表页可见「+ New Invoice」；无 `ACCOUNTING_EDIT` 时该按钮不可见或不可用。有 `ACCOUNTING_VIEW` 可访问列表与详情；无 VIEW 时不得正常展示发票内容。 |
| **适用范围** | invoice |
| **为什么需要** | 防止只测接口不测按钮可见性，或混淆 VIEW/EDIT |
| **违反规则的例子** | 未写对照账号；或写「无 EDIT 仍可见 New Invoice 按钮」却判 pass |
| **验收方式** | 文档含至少 VIEW-only 与 EDIT 两种账号的 UI 检查点 |

### RULE-TEST-007

| 字段 | 内容 |
|------|------|
| **Rule ID** | RULE-TEST-007 |
| **规则内容** | 凡 invoice 权限接口测试，必须写清 HTTP + 正文期望：无 `ACCOUNTING_EDIT` 的写操作 → **403**（或业务码失败），且 DB 无新增；有 EDIT 的写操作成功 → **HTTP 200** 且 JSON `code` 表示成功，`data` 含 `id` / `invoiceNumber`，再用该 `id` 调查询接口，详情与写入一致。无 VIEW 的查询/写入均失败。禁止把成功写成 Location/302。面试口径全文见 `http-transport-interview-addendum.md`。 |
| **适用范围** | invoice |
| **为什么需要** | 防止把 HTTP 200 当成业务成功（code 仍可能失败）；防止权限负向仍写请求成功 |
| **违反规则的例子** | 「save 成功看跳转 URL」；或无 EDIT 写入未查 DB 是否新增；或只 `assert resp.ok` |
| **验收方式** | 权限表每行含 HTTP 状态 +（成功侧）JSON code/data + DB 前后条数；缺任一项 → 违反 |

---

## 第 4 组：异常入参

### RULE-TEST-008

| 字段 | 内容 |
|------|------|
| **Rule ID** | RULE-TEST-008 |
| **规则内容** | 凡 invoice 空值测试：【As-Is】customerName 为空时浏览器 required 应拦截；须测绕过前端 POST 空 customerName 的实际行为。【To-Be】description 全空、无有效行项目时须阻止保存；未拦截标预期缺陷。 |
| **适用范围** | invoice |
| **为什么需要** | 防止误以为所有字段都有 HTML required（As-Is  mainly customerName） |
| **违反规则的例子** | 写「issueDate/taxRate 空时 required 拦截」但未读代码验证 |
| **验收方式** | 含 customerName 空值 + 无有效分项至少各 1 条；含绕过前端说明 |

### RULE-TEST-009

| 字段 | 内容 |
|------|------|
| **Rule ID** | RULE-TEST-009 |
| **规则内容** | 凡 invoice 字段长度边界测试：【To-Be】customerName ≤150、description ≤255；须构造超长字符串（151/256 字符）测页面与绕过前端 POST 的行为（报错/截断/500/入库），记录 As-Is 实际结果。不得写「HTML5 required 拦截超长」（required 不限制长度）。 |
| **适用范围** | invoice |
| **为什么需要** | 防止混淆 required 与 maxlength，漏测 DB 截断风险 |
| **违反规则的例子** | 「151 字符触发 required 拦截」 |
| **验收方式** | 含超长用例 + 实际响应/DB 记录；未写超长长度数值 → 违反 |

### RULE-TEST-010

| 字段 | 内容 |
|------|------|
| **Rule ID** | RULE-TEST-010 |
| **规则内容** | 凡 invoice 日期测试：【To-Be】未来 issueDate 应拦截；dueDate 应 ≥ issueDate。须含页面与绕过前端 POST 两种路径；As-Is 未拦截时标预期缺陷。 |
| **适用范围** | invoice |
| **为什么需要** | 防止漏测财务日期合规与到期日逻辑 |
| **违反规则的例子** | 只填合法日期 happy path，无未来日期/到期早于开票日用例 |
| **验收方式** | 至少 2 条日期负向 + 绕过前端；缺 To-Be 期望 → 违反 |

### RULE-TEST-011

| 字段 | 内容 |
|------|------|
| **Rule ID** | RULE-TEST-011 |
| **规则内容** | 凡 invoice 详情访问边界测试，必须包含 **非法 UUID** 用例：① `GET /accounting/invoices/not-a-uuid`（非 UUID 格式）→ 期望 404 或统一错误页，不得 500，不得展示正常发票；② `GET /accounting/invoices/{合法格式但不存在的 uuid}` → 期望 404 或 ResourceNotFound 错误页，不得展示空白详情当日志异常。 |
| **适用范围** | invoice |
| **为什么需要** | 防止只测合法详情 happy path，非法路径导致未处理异常 |
| **违反规则的例子** | 只测保存后合法跳转，未测 `not-a-uuid` 或不存在 id |
| **验收方式** | 文档含上述两类 URL + 期望 HTTP/页面 + 实际结果；缺非法 UUID 用例 → 违反 |

---

## 第 5 组：重复提交或并发

### RULE-TEST-012

| 字段 | 内容 |
|------|------|
| **Rule ID** | RULE-TEST-012 |
| **规则内容** | 凡 invoice **新建 save** 重复/并发测试，必须区分：① **同一会话**同一表单快速双击 Save 或重复 POST → 记录 DB 新增条数、invoiceNumber 是否重复或跳号（As-Is 可能产生多条，须如实记录）；② **两个独立会话**（两浏览器/两 JSESSIONID）各提交一次相同业务数据 → 期望 **2 条**发票、**2 个不同** invoiceNumber（不是合并为 1 条）。 |
| **适用范围** | invoice（仅新建 save） |
| **为什么需要** | 防止混淆幂等测试与多用户各开一张票 |
| **违反规则的例子** | 「两用户同时开票只入库 1 条」；或重复 POST 未查 DB 条数 |
| **验收方式** | 步骤明确区分「同请求重复」与「两会话各提交」，并含 DB count/invoiceNumber 断言 |

---

## 第 6 组：数据一致性

### RULE-TEST-013

| 字段 | 内容 |
|------|------|
| **Rule ID** | RULE-TEST-013 |
| **规则内容** | 凡 invoice 保存后数据一致性测试，必须核对：① `sum(acc_invoice_items.line_total)` = `acc_invoices.subtotal`；② total 符合 RULE-TEST-001 公式；③ description 为空的行在 DB 中不存在。 |
| **适用范围** | invoice |
| **为什么需要** | 防止只验主表不验分项聚合与空行 |
| **违反规则的例子** | 只 SELECT 主表，未 JOIN/汇总分项 |
| **验收方式** | 含主表 + 分项 SQL 或等价核对；缺分项 sum → 违反 |

### RULE-TEST-014

| 字段 | 内容 |
|------|------|
| **Rule ID** | RULE-TEST-014 |
| **规则内容** | 凡 invoice 新建 save 成功步骤，必须核对用户填写字段在详情页与 DB 一致：customerName、issueDate、dueDate、notes、taxRate、discount 及有效行项目的 description/quantity/unitPrice。 |
| **适用范围** | invoice |
| **为什么需要** | 防止只验金额不验基础字段落库 |
| **违反规则的例子** | 只断言 total，未比对 customerName 或行项目 |
| **验收方式** | 步骤含至少 3 个非金额字段的页面/DB 对比 |

### RULE-TEST-015

| 字段 | 内容 |
|------|------|
| **Rule ID** | RULE-TEST-015 |
| **规则内容** | 凡 invoice 保存成功后的 flash 提示，应可断言：页面出现含 `invoiceNumber` 的成功消息（如「Invoice INV-xxxx saved.」），且与 DB `invoice_number` 一致。 |
| **适用范围** | invoice |
| **为什么需要** | 防止只验跳转不验用户可见的成功反馈 |
| **违反规则的例子** | 只写「保存成功」未写成功消息文案或发票号 |
| **验收方式** | 步骤含 flash/页面成功文案 + 与 DB invoice_number 对比 |

### RULE-TEST-016

| 字段 | 内容 |
|------|------|
| **Rule ID** | RULE-TEST-016 |
| **规则内容** | 凡 invoice 新建写操作成功，必须核对 **写后读一致性**：① 写操作 JSON `data.id`；② 查询接口（入参必须等于①，或用 `data.invoiceNumber`）返回的 `id`；③ DB `acc_invoices.id`；④ 分项 `acc_invoice_items.invoice_id`。四处相同。禁止手填旧发票号去查。 |
| **适用范围** | invoice |
| **为什么需要** | 防止「写成功了」但查到的不是刚创建的那张票、主明细外键错 |
| **违反规则的例子** | 只写「保存成功」；或用手填 INV 号查询；或不查 DB 主键 |
| **验收方式** | 步骤含：从写响应取 id → 作为查询入参 → DB 主键/外键一致；缺任一处 → 违反 |

---

## 自检

- [x] 至少 6 条，六字段齐全（共 16 条，覆盖 6 方向）
- [x] 覆盖：金额精度、状态、权限、异常入参、数据一致性、重复提交
- [x] 每条可判定违反 / 未违反
- [x] Rule 写约束，公式细节与 M1 Context 一致且不重复整段 Context
- [x] RULE-TEST-011（非法 UUID）、RULE-TEST-016（写后读 id 一致）已填写
