# 测试数据与数据库核对规则

> 练习范围：**发票新建链路** · 表 `acc_invoices` + `acc_invoice_items`
> Rule ID 统一：`RULE-DB-XXX`（与 `testing-rules.md` 的 RULE-TEST 区分）

---

## 规则清单

| 方向 | Rule ID | 是否已写 |
|------|---------|----------|
| 测试数据唯一性 | RULE-DB-001 | ☑ |
| 测试前置数据 | RULE-DB-002 | ☑ |
| 测试后数据核对 | RULE-DB-003 | ☑ |
| 主表 / 明细表一致性 | RULE-DB-004 | ☑ |
| 金额与状态字段核对 | RULE-DB-005 | ☑ |

---

## RULE-DB-001（测试数据唯一性）

| 字段 | 内容 |
|------|------|
| **Rule ID** | RULE-DB-001 |
| **规则内容** | 凡 invoice 新建测试，业务字段须来自测试库**已冒烟通过**的单据（金数据），禁止脚本现场造客户名：① 按种子发票号 SELECT 主表+分项；② 用例前恢复到该快照（回滚/restore）；③ 重放只带客户、税率、行项目；旧 `id` / `invoice_number` 不沿用，由写接口返回新号；④ 写成功后新 `id` 全局唯一、新 `invoice_number` 匹配 `INV-\d{4}` 且不重复；⑤ 分项共享新 `invoice_id`。 |
| **适用范围** | invoice |
| **为什么需要** | 防止用时间戳假客户名当主路径数据（财务主数据/期间/税码面试讲不清）；仍要验主键与发票号唯一 |
| **违反规则的例子** | 主路径用 `AutoTest_时间戳` 当客户名；或沿用金数据主键去 POST；或未查新 `invoice_number` 是否重复 |
| **验收方式** | 文档写明金数据来源 + 回滚 + 写响应 `data.id` 再查询；缺唯一性核对 → 违反 |

---

## RULE-DB-002（测试前置数据）

| 字段 | 内容 |
|------|------|
| **Rule ID** | RULE-DB-002 |
| **规则内容** | 凡 invoice 新建 save 用例，执行前须写明前置数据：① 账号：正向用 `ACCOUNTING_EDIT`（含 VIEW）；负向用 VIEW-only 或无 Accounting 权限对照账号；② 表单：`customerName` 非空；至少 1 条有效分项（description 非空，建议 qty>0、unitPrice>0）；③ `form.id` 为空（新建）；④ 环境：DB 可连接（H2 控制台或 datasource 可查）；⑤ save 前记录 `SELECT count(*) FROM acc_invoices` 及 `acc_invoice_items` 条数作为基线。 |
| **适用范围** | invoice |
| **为什么需要** | 防止 happy path 前置不全、负向无对照账号、无测前基线导致无法判断 DB 是否新增 |
| **违反规则的例子** | 步骤未写登录账号权限；或未写 form.id 为空；或未取测前 count |
| **验收方式** | 每个 save 用例含「前置数据表」（账号/权限/customerName/有效分项数/form.id/测前 count）；缺任一项 → 违反 |

---

## RULE-DB-003（测试后数据核对）

| 字段 | 内容 |
|------|------|
| **Rule ID** | RULE-DB-003 |
| **规则内容** | 凡 invoice save 用例（正向或负向），执行后须做 DB 核对：① **正向**：用写响应 JSON 的 `data.id` 查 `acc_invoices`，字段与查询 JSON 一致；测后 count：主表 +1，分项表 +M；② **负向**：测后主表、分项表 count 与测前相同；To-Be 未拦则标预期缺陷；③ 权限负向写操作后必须显式写「DB 无新增」。 |
| **适用范围** | invoice |
| **为什么需要** | 防止只验页面不查库；防止负向用例未验证「是否误写入」 |
| **违反规则的例子** | save 成功只写「详情页正确」无 SELECT；或无权限 save 后未对比 count |
| **验收方式** | 每用例含测后核对小节（SELECT 或 count 对比）；正向缺 uuid 查主表、负向缺 count 不变 → 违反 |

---

## RULE-DB-004（主表 / 明细表一致性）

| 字段 | 内容 |
|------|------|
| **Rule ID** | RULE-DB-004 |
| **规则内容** | 凡 invoice 新建 save 成功且存在有效分项，须核对主明细关系：① 每条 `acc_invoice_items.invoice_id` = `acc_invoices.id`（URL uuid）；② `sum(acc_invoice_items.line_total)` = `acc_invoices.subtotal`；③ 表单 N 行中仅 M 行 description 非空 → 分项表恰增 M 条，空行不入库；④ 保存后浏览器地址栏 uuid = 主表 `id`（与 RULE-TEST-016 一致，本 Rule 强调 DB 层外键与聚合 SQL）。 |
| **适用范围** | invoice |
| **为什么需要** | 防止只查主表不查分项；防止空行误入库、外键错连 |
| **违反规则的例子** | 未跑 `sum(line_total)` 与 subtotal 对比；或未验证 5 行填 2 行时 items 仅 2 条 |
| **验收方式** | 文档含 JOIN/聚合 SQL 或等价核对；缺 invoice_id 外键或 sum 对比 → 违反 |

---

## RULE-DB-005（金额与状态字段核对）

| 字段 | 内容 |
|------|------|
| **Rule ID** | RULE-DB-005 |
| **规则内容** | 凡 invoice 新建 save 成功且需验证落库，**必须执行 DB 字段清单 SELECT**（不重复 testing-rules 计算公式，公式以 RULE-TEST-001/003/013 为准）。须查询 `acc_invoices` 列：`status`、`invoice_number`、`subtotal`、`tax_rate`、`tax_amount`、`discount`、`total`；断言 `status='DRAFT'`、`invoice_number` 匹配 `INV-\d{4}`。金额列记录 DB 实际值并与 RULE-TEST-001 手算结果对比，不在本 Rule 重写公式。 |
| **适用范围** | invoice（仅新建 save 成功） |
| **为什么需要** | testing-rules 管「怎么算」；本 Rule 管「必须查哪些 DB 列、不能只看页面」 |
| **违反规则的例子** | 步骤写「total 正确」但无 `SELECT … FROM acc_invoices WHERE id=?`；或只查 customer_name 不查 status、invoice_number |
| **验收方式** | 文档含完整 SELECT 字段列表 + SQL 输出/截图；缺 status 或 invoice_number 核对 → 违反 |

---

## 自检

- [x] 至少 5 条，六字段齐全
- [x] 覆盖：唯一性、前置、测后、主明细、金额/状态 DB 核对
- [x] 与 testing-rules 分工明确（本文件不写完整金额公式）
- [x] 未使用 UUID 递增/Max(id)+1 等错误表述
