# Week01b Rules Work

这里放第 1 周下半周 M2 Rules 的练习成果。

请创建并完成：

- `testing-rules.md`
- `ui-testability-rules.md`
- `data-and-db-rules.md`
- `rule-effectiveness-review.md`

任务卡：

`C:\Users\hma\code\ai-testing-lab-whiteboard\materials\week01b-rules-task-card.md`

完成后去验证区提交：

`请验证白板区 work/week01b-rules 的学习成果。`
