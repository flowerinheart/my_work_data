# 传输层补丁（小改，不是重写第 1～2 周）

> HTML 版（浏览器打开）：[http-transport-interview-addendum.html](http-transport-interview-addendum.html)
>
> 2026-09-19 · 面试主叙事改为 **HTTP 200 + JSON 成功体 → 用返回字段调查询接口**。
> 金额、权限、DRAFT、两张表、403 + DB、RULE-TEST-012 **整段保留**。
> 不要把 Meridian 控制器改口成「已经返回 JSON」——那是假 Context，验证区会打回。

---

## 判据：为什么只小改

| 层 | 改不改 | 原因 |
|---|---|---|
| Prompt 角色/动作/输出物 | 不改 | 仍是财务 QA 出测试框架 |
| Context 公式、PermissionType、两表、As-Is 缺口 | 不改 | 业务事实没变 |
| Constraint 范围/To-Be/禁止项 | 不改 | 仍只测新建 |
| AC 正向/权限/金额/负向 | 不改结构 | 只改「成功长什么样」那一句 |
| RULE-TEST-001～006、008～015、012 | 基本不改 | 012 本来就是幂等/并发，第 7 天主攻 |
| RULE-TEST-007、016 | **改传输句** | 007 把成功从 302 改成 200+JSON；016 从「跳转 UUID」改成「写后读 id 一致」 |
| RULE-DB-001 | **改数据来源句** | 金数据回放，不再时间戳造客户名 |
| Skill 工作流/八列表头 | 不改 | 只改正向步骤里的 HTTP 期望 |

大改（整份 template 推倒）的条件才会是：发票业务本身变了（不再 DRAFT、不再两张表）。现在没有。

---

## 1. Prompt（正确版本，与原 template §3 几乎相同）

```text
角色：财务方向 QA 质量工程师

动作：基于 Context 和 Constraint（区分 As-Is / To-Be），
设计发票新建链路的测试步骤和验证标准框架。
HTTP 传输按「写操作 200 + JSON 成功体 → 查询接口用上一步 JSON 当入参」描述。
不要把成功写成 Location / 302 跳转。

输出物：测试步骤 + 验证标准框架（含测试点、前置数据、逐步操作、预期结果、失败证据）。
不写自动化脚本代码。
```

只多了一句传输约束。角色、输出物不动。

---

## 2. Context 里「保存成功」那一行（替换句）

**删：** `保存成功：302 跳转 /accounting/invoices/{uuid}`

**改成（面试 / 自动化主叙事）：**

```text
写操作成功：
  POST /api/invoices   Content-Type: application/json
  HTTP 200
  body 例：
  {
    "code": 0,
    "message": "OK",
    "data": {
      "id": "<业务主键>",
      "invoiceNumber": "INV-0002",
      "status": "DRAFT"
    }
  }
禁止：只看 HTTP 200、不看 code；禁止用 ok 覆盖业务失败。

查询（必须用上一步 JSON，禁止手填旧单号）：
  GET /api/invoices/{data.id}
  或 POST /api/invoices/query   {"id": data.id}  /  {"invoiceNumber": data.invoiceNumber}

核对：查询 JSON 的 id、invoiceNumber、status、金额 = 写操作返回值 = DB。
```

**脚注（Meridian 被测系统 As-Is，面试可以一句带过、不要当主故事）：**

Meridian 控制器仍是表单 POST `/accounting/invoices/save`，浏览器侧会 302。
自动化里用适配层把它收成上面这套 JSON 语义（取出 id 再 GET 详情），**测试断言写 JSON 契约，不写 Location。**

---

## 3. RULE-TEST-007（改后全文）

| 字段 | 内容 |
|------|------|
| Rule ID | RULE-TEST-007 |
| 规则内容 | 凡 invoice 权限接口测试，必须写清 HTTP + JSON 期望：① 无 `ACCOUNTING_EDIT` 的写操作 → **HTTP 403**（或业务码失败），且 DB 无新增；② 有 EDIT 的写操作成功 → **HTTP 200** 且 JSON `code` 表示成功，`data` 含 `id` / `invoiceNumber`；再用该 `id` 调查询接口，详情 JSON 与写操作返回一致。无 VIEW 的查询/写入均失败。禁止把成功写成 302/Location。 |
| 适用范围 | invoice |
| 为什么需要 | 防止把「HTTP 200」当成业务成功（code 失败仍可能 200）；防止权限负向仍写请求成功 |
| 违反规则的例子 | 「save 成功看 Location」；或无 EDIT 写入未查 DB 是否新增；或只 assert resp.ok |
| 验收方式 | 权限表每行含：HTTP 状态 + JSON code/data（成功侧）+ DB 前后条数 |

Meridian 适配：若原始响应是 403 页，断言仍是 403 + count 不变，这条不放宽。

---

## 4. RULE-TEST-016（改后全文）

| 字段 | 内容 |
|------|------|
| Rule ID | RULE-TEST-016 |
| 规则内容 | 凡 invoice 新建写操作成功，必须核对 **写后读一致性**（不再核对「跳转 URL」）：① 写操作 JSON `data.id`；② 查询接口（入参=①）返回的 `id`；③ DB `acc_invoices.id`；④ 分项 `acc_invoice_items.invoice_id`。四处相同。发票号以写操作 JSON `data.invoiceNumber` 为准，查询结果必须能对上。 |
| 适用范围 | invoice |
| 为什么需要 | 防止「写成功了」但查到的不是刚创建的那张票、主明细外键错 |
| 违反规则的例子 | 手填一个旧 INV 号去查；或只看 HTTP 200 不取 data.id |
| 验收方式 | 步骤含：从写响应取出 id → 作为查询入参 → DB 主键/外键三处一致 |

---

## 5. RULE-DB-001（数据来源句替换）

**删：** 用 `AutoTest_时间戳` 当 customerName 造数。

**改成：**

```text
凡 invoice 新建测试，业务字段须来自测试库里已经冒烟通过的单据（金数据）：
① 按发票号或种子 id SELECT 主表+分项；
② 用例前恢复到该快照（回滚事务 / restore）；
③ 重放时带金数据的客户、税率、行项目；id / invoiceNumber 不沿用，由服务端发新号；
④ 金额期望值用金数据已核对过的数，不现场手编。
禁止用脚本拼一个「看起来像」的客户名当主路径数据。
```

唯一性仍要验：新 `id` 全局唯一、新 `invoice_number` 不重复。只是来源从「造」改成「回放」。

---

## 6. 测试计划 Skill · 只改这两处

**§6.3 测试步骤（正向主路径）**

```text
列表 → 新建 → 填表 → POST JSON 保存（断言 HTTP 200 + code 成功 + data.id）
→ 用 data.id（或 data.invoiceNumber）调查询接口 → 详情 JSON / DB 核对
```

**§6.4 正向链路**

```text
200 + JSON 成功体 + DRAFT + INV-\d{4} + 写后读 id 与 DB 主键一致
```

自检清单把「是否覆盖 UUID 跳转一致性」改成「是否覆盖写后读 id 一致性」。
调用样例把「保存后跳转详情页」改成「保存后用返回 JSON 调查询接口」。

其余 §1～§5、八列表头、不能编造 URL/表名 **不动**。

---

## 7. 失败日志 Skill · 只改这两处

输入契约「响应状态」：

```text
HTTP：200 / 403 / 404 / 500
若 200：必须同时给 JSON code、data.id（有则写）
```

对照期望：

```text
写成功：200 + code 成功 + 能用 data.id 查到同一张票
无 EDIT：失败（403 或业务码）且 DB 不增
不要用「跳转到了 /invoices/{uuid}」当成功证据
```

样例失败改成：

```text
账号只有 VIEW。POST /api/invoices 返回 HTTP 200，
JSON code=0 且 data.id 能查到新票，DB 主表+1。
期望：写失败且两表不增。
```

---

## 8. 给 AI 的固定约束句（以后每天生成代码都贴）

```text
写操作：POST JSON，断言 HTTP 200 且 body.code 表示成功，取出 data.id / data.invoiceNumber。
查询：入参必须来自上一步 JSON，禁止手填发票号。
权限失败：403 或业务码失败 + DB count 不变。
不要断言 Location，不要 max_redirects=0，不要把 form POST 当本阶段主契约。
金数据：从已冒烟库取字段，先回滚再重放；不要 unique_customer_name。
```
