# Whiteboard Work Directory

把你的练习成果放在这里。

建议结构：

- `week01/`
- `week02/`
- `week04/`
- `week06/`

每完成一周，就把对应目录交给 evaluator 区验证。
