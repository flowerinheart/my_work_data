# Week04（合并原第 4+5 周）：API 自动化为主 + 关键 UI E2E 为辅

> **执行日历已换。** 不要按本目录旧「7 天 + TestNG」清单做。
> 按天做什么：`C:\Users\hma\code\ai-testing-learning-lab\docs\playwright-api-knowledge-and-8h-plan.html`
> 技术栈锁定：**Python + Playwright + Pytest**（不要再搭 TestNG / RestAssured）。
> 代码写在 `playwright-api-lab/meridian-autotest/`，第 8 天结束前复制到本目录 `code/` 再交验证区。

## 与九周计划的关系

- 原 **第 5 周 M5（API/表单自动化）** + 原 **第 4 周 M6（UI E2E）** → **合并为本目录**。
- 原独立「第 5 周」在总表里标记为 **已合并至第 4 周**，不再单独交付。

## 本周学习目标

完成后你应能：

1. 在发票链路上跑通接口自动化（200+JSON 写后读、403、DB、金数据回放、幂等/并发口述）。
2. 金数据回放（已冒烟单据 → 回滚 → 重放），不要 `uniqueCustomerName` 造数。
3. 有 **1～2 条** 关键 UI E2E（例如：登录后进发票列表 → 打开刚用 API 创建的发票详情），**前置数据用 API 完成**，UI 只验证「页面能展示、跳转正确」。
4. 能向面试官讲清：**分层策略**（API 扛回归，UI 扛关键路径）、**失败证据**（请求/响应/DB）、**与 Week01 Rules 的对应关系**。

## 本周不做什么

- 不系统学 Playwright 全栈（页面对象、多浏览器、复杂定位体系）——面试前时间不够。
- 不做商城全链路 E2E、不做性能、不做测试平台。
- 不要求补 Week01b 里完整的 `ui-testability-rules.md`（仅在本周 E2E 里用最少定位策略）。

## 任务包

| 任务 | 文件 | 交付物 |
|------|------|--------|
| Task 01 | `task-01-api-foundation.md` | 技术选型说明 + 登录与会话复用方案 |
| Task 02 | `task-02-invoice-api-suite.md` | 发票新建 API/表单用例集（可运行） |
| Task 03 | `task-03-api-data-factory.md` | 造数与清理说明 + 代码/脚本 |
| Task 04 | `task-04-minimal-ui-e2e.md` | 1～2 条 E2E + API 前置 |
| 复盘 | `self-review.md` | 自检 + 面试话术要点 |
| 执行 | `todo.md` | 7 天清单 |

建议代码目录（自建）：

```text
work/week04-api-automation/
  code/                    # 或放在 meridian-erp 旁独立 test 工程
  reports/                 # 运行结果、截图、trace
  test-data-management.md
```

## 建议学习顺序

按 8 天课表第 4～8 天走，不要按旧 7 天编号：

1. Task 01：Pytest + Playwright `APIRequestContext`；表单登录 + Cookie 会话。
2. Task 02：INV 正向 200+JSON 写后读 + 权限 403 + 金额/DB。
3. 第 7 天：金数据回放 + RULE-TEST-012 幂等/并发（跑 Demo，不造数工厂）。
4. Task 04：第 8 天才写 1 条 hybrid。
5. 每天 `notes/day0X.md` 面试收口；第 8 天拼 3 分钟总述。

## 去验证区提交

```text
请验证白板区 work/week04-api-automation 的学习成果。
```
