# Week04 执行 Todo（已并入 8 天课表）

对照：`ai-testing-learning-lab/docs/playwright-api-knowledge-and-8h-plan.html`
技术栈：**Python + Playwright + Pytest**。
传输层：**POST JSON → 200 + code → 用 data.id 查询**。不要断言 Location/302。
传输补丁：`work/week01b-rules/http-transport-interview-addendum.md`

## 课表第 4 天（今天）＝ 旧 Day 1

- [ ] 本地 Meridian 可访问
- [ ] `meridian-autotest/` 骨架 + admin 登录 fixture
- [ ] GET 列表 200；`notes/day04.md` 面试收口

## 课表第 5 天 ＝ 旧 Day 2 + 金额

- [ ] INV-CREATE-001：POST JSON → 200 + `data.id` → GET/query
- [ ] DRAFT、`INV-\d{4}`、一组 HALF_UP
- [ ] 读 `day05/json-write-then-read-explained.html`

## 课表第 6 天 ＝ 旧 Day 3

- [ ] VIEW-only / 无 VIEW → 写失败，count 不变
- [ ] To-Be 负向至少 1 条
- [ ] DB 主表 + 分项

## 课表第 7 天 ＝ 幂等 / 并发 + 金数据（不造数）

- [ ] 跑 `playwright-api-lab/day07/golden_replay_demo.py`
- [ ] 读幂等 HTML；对照 `InvoiceService.nextInvoiceNumber()`
- [ ] `notes/day07.md` 面试收口
- [ ] 不要 `unique_customer_name()`，不要付款扩展

## 课表第 8 天 ＝ hybrid + markers + 交付

- [ ] 1 条 hybrid：API 写入取 JSON 发票号 → Cookie 注入 → UI 核对
- [ ] `@pytest.mark.invoice`；README；3 分钟总述
- [ ] 复制到本目录 `code/`，提交验证区
