# Task 03：测试数据（已改口径）

> **课表第 7 天不再做造数工厂。** 不要实现 `uniqueCustomerName()`。
> 口径：从测试库取**已冒烟通过**的发票当金数据 → 回滚 → 按业务字段重放 save。
> 完整步骤：`playwright-api-lab/day07/golden_replay_demo.py`。
> 当天主攻 **RULE-TEST-012 幂等 / 并发**。

下面旧交付清单作废，仅留档对照。


## 你要交付

1. **造数模块**（命名自定），至少包含：
   - `loginAsAccountingEditor()` / `loginAsViewOnly()`（无账号则文档写「待构造角色」）
   - `uniqueCustomerName()` — 对齐 RULE-DB-001
   - `baselineCounts()` — 对齐 RULE-DB-002
   - `createInvoiceViaApi(formData)` — 返回 uuid、`invoiceNumber`
2. **`test-data-management.md`**：
   - 数据是否删除、为何保留 H2 累积数据
   - 如何用 uuid / customerName 定位本次运行
   - 负向用例如何证明「未新增」

## 与 UI E2E 的衔接（面试加分）

写清一条链路：

```text
API: login → POST save → 得到 uuid
UI:  browser 带同一 Cookie → 打开 /accounting/invoices/{uuid} → 断言页面字段
```

## 验收标准

- [ ] 至少 2 条 API 用例调用造数模块，无复制粘贴表单字段。
- [ ] 文档说明「不用 UI 填表也能准备详情页测试数据」。
