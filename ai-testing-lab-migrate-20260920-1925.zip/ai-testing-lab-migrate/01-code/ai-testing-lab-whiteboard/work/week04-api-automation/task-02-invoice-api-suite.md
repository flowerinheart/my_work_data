# Task 02：发票新建 API/表单自动化用例集

## 目标

把 Week01 模板 + Week01b Rules 落成 **可执行** 的自动化用例（接口/表单层），作为面试作品主菜。

## 最低用例清单（必须实现）

| 编号 | 场景 | 断言要点 |
|------|------|----------|
| INV-CREATE-001 | 合法新建 | 200 + JSON `code` 成功 + `data.id` 可查询；`DRAFT`；`INV-\d{4}`；主表+分项；金额公式（至少 1 组手算） |
| INV-AUTH-001 | 仅 VIEW POST save | 403；DB count 不变 |
| INV-AUTH-002 | 无 VIEW 访问列表或 save | 403 |
| INV-AMT-001 | 金额 | subtotal/tax/total 与公式一致（DB 或详情接口可读处） |

## 建议实现（时间允许）

- INV-NEG-001：绕过前端负 `taxRate` POST，记录是否落库 + 预期缺陷标注
- RULE-TEST-016：URL uuid = DB `acc_invoices.id`

## 工程要求

- 用例 **无顺序依赖**（每条自己登录或独立会话）。
- 失败输出：**请求 JSON、HTTP 状态、响应 JSON、DB 查询结果**（对齐 Week02 failure-log Skill）。
- 引用 Rule ID 写在用例注释或报告里（不必 16 条全自动化）。

## 验收标准

- [ ] `pytest tests/api`（或等价）一键跑通最低清单。
- [ ] 与 `work/week01/test-task-template.md` 无矛盾（PermissionType、200+JSON 写后读）。
- [ ] 有简短 `api-test-report.md` 或 Surefire 链接说明通过率。
