# Task 01：API 自动化基础与会话注入

## 目标

在 Meridian ERP 上建立 **可重复运行的 HTTP 自动化底座**，并写清如何用 API/登录 **注入会话**（供后续用例与 UI E2E 复用）。

## 背景（面试要讲清）

- Meridian 发票保存是 **表单 POST**，不是 REST JSON。
- 鉴权多为 **Spring Security + Cookie 会话**。本项目里「注入会话」指：先表单登录拿到 Session Cookie，再在后续 Playwright `APIRequestContext` 请求里自动带上（hybrid 时用 `storage_state` / `add_cookies`）。
- 技术栈锁定 **Python + Playwright + Pytest**，不要再搭 TestNG / RestAssured。
- 你可从 `InvoiceController`、权限枚举读 URL 与 302/403 行为，减少瞎猜。

## 你要交付

1. `docs/tech-stack.md`（或写在 README 一节）：框架选型、目录结构、如何启动被测环境。
2. `docs/session-injection.md`：
   - 登录 URL、表单字段、成功判定
   - Cookie 如何保存到变量 / 文件
   - 如何在 Pytest session fixture 里注入到后续请求
   - Playwright 如何复用同一登录态（预告课表第 8 天 hybrid）
3. 至少 1 个 **冒烟测试**：登录后 GET 发票列表 200。

## 验收标准

- [ ] 不硬编码假 URL；与 Week01 Context 一致。
- [ ] 会话失效时有明确失败信息（重新登录或失败提示）。
- [ ] 说明 **API 自动化 vs UI** 分工一句话写清。
