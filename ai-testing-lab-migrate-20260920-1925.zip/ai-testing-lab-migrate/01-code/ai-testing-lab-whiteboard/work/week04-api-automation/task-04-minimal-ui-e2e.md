# Task 04：关键 UI E2E（最少条数）

## 目标

满足 JD 里「会 UI 自动化」的 **最低可演示量**：**1 条必做，1 条选做**；**禁止**从零写「登录→下单→发票→付款」全长链路。

## 必做 E2E-INV-001：API 造数 + 详情页核对

1. API 创建一张 DRAFT 发票，从 JSON `data.id` / `data.invoiceNumber` 取值。
2. Playwright 使用 **与 API 相同的登录态**（`storageState` / 注入 Cookie）。
3. 打开 `/accounting/invoices/{uuid}`。
4. 断言：客户名、`DRAFT`、发票号格式、行项目可见（选 1～2 项即可）。

**禁止：** 依赖 `sleep(5000)`；用 `waitForURL` / `getByRole` 等稳定等待。

## 选做 E2E-INV-002：列表入口可见性

- 有 `ACCOUNTING_EDIT`：列表存在「+ New Invoice」。
- 仅 `VIEW`：按钮不可见或不可用（与 RULE-TEST-006 对齐）。

## 不要求

- 页面对象模型全套、多浏览器、CI 并行、视觉回归。
- 补全 `ui-testability-rules.md` 四条（可面试时口述「稳定定位思路」）。

## 验收标准

- [ ] 失败保留 screenshot 或 trace 路径写在 README。
- [ ] 文档写明：**为何这条 UI 值得写、其余用 API 覆盖**。
