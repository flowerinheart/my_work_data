# AI Testing Lab Whiteboard Zone

这是你的“白板练习区”。

这个区只用于从零开始练习九周 AI 测试学习计划。这里不放标准答案、不放原始测试代码、不放验证脚本。

## 你在这里做什么

- 从第 1 周开始按任务卡练习。
- 自己产出测试模板、测试计划、API 测试设计、用例管理模型和自动化运行方案。
- 练习成果放到 `work/` 目录。
- 完成后，把 `work/` 里的成果交给 evaluator 区验证。

## 目录

- `AGENT-WHITEBOARD.md`：白板 Agent 规则。
- `materials/week-plan-task-card.md`：九周计划白板任务卡。
- `materials/meridian-erp-starter-requirements.md`：Meridian ERP 项目练习背景。
- `project/meridian-erp-starter/`：去掉测试答案后的 Meridian ERP 主程序源码。
- `work/`：你的练习产物目录。

## 使用限制

不要在这个区打开 evaluator/oracle/rubrics 文件。
不要把验证区答案复制进这个区。
不要让白板 Agent 读取旧聊天记录。
