param(
    [string]$BaseUrl = "http://localhost:8080",
    [string]$Username = "admin@erp.com",
    [string]$Password = "Admin@1234"
)

$ErrorActionPreference = "Stop"

function Get-CsrfToken {
    param([string]$Html)
    return [regex]::Match($Html, 'name="_csrf"[^>]*value="([^"]+)"').Groups[1].Value
}

function Assert-True {
    param([bool]$Condition, [string]$Message)
    if (-not $Condition) {
        throw $Message
    }
}

Write-Host "Checking public storefront..."
$shopSession = New-Object Microsoft.PowerShell.Commands.WebRequestSession
$catalog = Invoke-WebRequest -UseBasicParsing -WebSession $shopSession "$BaseUrl/shop"
Assert-True ($catalog.StatusCode -eq 200) "Storefront did not return HTTP 200."

$productId = [regex]::Match($catalog.Content, 'name="productId"[^>]*value="([0-9a-fA-F-]{36})"').Groups[1].Value
Assert-True ($productId.Length -eq 36) "Could not find a seeded product."

$csrf = Get-CsrfToken $catalog.Content
Invoke-WebRequest -UseBasicParsing -WebSession $shopSession -Method Post `
    -Uri "$BaseUrl/shop/cart/add" `
    -Body @{ _csrf = $csrf; productId = $productId; qty = "2" } `
    -MaximumRedirection 0 -ErrorAction SilentlyContinue | Out-Null

$checkout = Invoke-WebRequest -UseBasicParsing -WebSession $shopSession "$BaseUrl/shop/checkout"
Assert-True ($checkout.StatusCode -eq 200) "Checkout page did not return HTTP 200."

$csrf = Get-CsrfToken $checkout.Content
$shippingId = [regex]::Match($checkout.Content, 'name="shippingMethodId"[\s\S]*?value="([0-9a-fA-F-]{36})"').Groups[1].Value
$customerEmail = "ai-smoke-$([DateTimeOffset]::UtcNow.ToUnixTimeSeconds())@example.com"
$body = @{
    _csrf = $csrf
    customerName = "AI Smoke Customer"
    customerEmail = $customerEmail
    shippingAddress = "123 Smoke Test Street"
    paymentMethod = "COD"
}
if ($shippingId) {
    $body.shippingMethodId = $shippingId
}

$placed = Invoke-WebRequest -UseBasicParsing -WebSession $shopSession -Method Post `
    -Uri "$BaseUrl/shop/checkout" `
    -Body $body -MaximumRedirection 0 -ErrorAction SilentlyContinue
Assert-True ($placed.StatusCode -eq 302 -and $placed.Headers.Location -match "/shop/confirmation/") "Checkout did not redirect to confirmation."

$confirmationUrl = if ($placed.Headers.Location -match "^http") { $placed.Headers.Location } else { "$BaseUrl$($placed.Headers.Location)" }
$confirmation = Invoke-WebRequest -UseBasicParsing -WebSession $shopSession $confirmationUrl
Assert-True ($confirmation.StatusCode -eq 200) "Order confirmation did not return HTTP 200."
Write-Host "Created storefront order: $confirmationUrl"

Write-Host "Logging in as admin..."
$adminSession = New-Object Microsoft.PowerShell.Commands.WebRequestSession
$loginPage = Invoke-WebRequest -UseBasicParsing -WebSession $adminSession "$BaseUrl/login"
$csrf = Get-CsrfToken $loginPage.Content
Invoke-WebRequest -UseBasicParsing -WebSession $adminSession -Method Post `
    -Uri "$BaseUrl/login" `
    -Body @{ username = $Username; password = $Password; _csrf = $csrf } `
    -MaximumRedirection 0 -ErrorAction SilentlyContinue | Out-Null

$paths = @(
    "/dashboard",
    "/crm/leads",
    "/hrm/employees",
    "/inventory/products",
    "/ecommerce/orders",
    "/accounting/invoices",
    "/accounting/payments",
    "/accounting/journal",
    "/procurement/vendors",
    "/projects",
    "/support/tickets",
    "/reports",
    "/settings/users"
)

foreach ($path in $paths) {
    $response = Invoke-WebRequest -UseBasicParsing -WebSession $adminSession "$BaseUrl$path"
    Assert-True ($response.StatusCode -eq 200) "$path did not return HTTP 200."
    Write-Host "OK $path"
}

$orders = Invoke-WebRequest -UseBasicParsing -WebSession $adminSession "$BaseUrl/ecommerce/orders?q=$customerEmail"
Assert-True ($orders.Content.Contains($customerEmail)) "Created order was not found in admin orders."

$paymentForm = Invoke-WebRequest -UseBasicParsing -WebSession $adminSession "$BaseUrl/accounting/payments/new"
$csrf = Get-CsrfToken $paymentForm.Content
$invoiceId = [regex]::Match($paymentForm.Content, '<option value="([0-9a-fA-F-]{36})"').Groups[1].Value
Assert-True ($invoiceId.Length -eq 36) "Could not find a seeded invoice."

$reference = "AI-SMOKE-PAY-$([DateTimeOffset]::UtcNow.ToUnixTimeSeconds())"
Invoke-WebRequest -UseBasicParsing -WebSession $adminSession -Method Post `
    -Uri "$BaseUrl/accounting/payments/save" `
    -Body @{
        id = ""
        invoiceId = $invoiceId
        amount = "1.23"
        method = "CASH"
        date = (Get-Date -Format "yyyy-MM-dd")
        reference = $reference
        _csrf = $csrf
    } -MaximumRedirection 0 -ErrorAction SilentlyContinue | Out-Null

$payments = Invoke-WebRequest -UseBasicParsing -WebSession $adminSession "$BaseUrl/accounting/payments?q=$reference"
Assert-True ($payments.Content.Contains($reference)) "Created payment was not found in accounting payments."

Write-Host "Smoke verification passed."
