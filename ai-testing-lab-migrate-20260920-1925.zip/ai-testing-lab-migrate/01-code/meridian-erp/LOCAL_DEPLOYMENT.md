# Local Deployment Notes

## Runtime

- Application URL: `http://localhost:8080`
- Admin console: `http://localhost:8080/dashboard`
- Public storefront: `http://localhost:8080/shop`
- H2 console: `http://localhost:8080/h2-console`
- JDBC URL: `jdbc:h2:file:./data/erpdb`
- User: `sa`
- Password: empty

## Demo Accounts

All demo accounts use password `Admin@1234`.

- `admin@erp.com` - Super Administrator
- `tanvir.admin@erp.com` - Administrator
- `nusrat.hr@erp.com` - HR Manager
- `rakib.sales@erp.com` - Sales Manager
- `farzana.acc@erp.com` - Accountant
- `imran.inv@erp.com` - Inventory Manager
- `sadia.support@erp.com` - Support Agent
- `mehedi.emp@erp.com` - Employee

## Build

The machine did not have `git`, `java`, or `mvn` on `PATH`, and Docker Hub image pulls failed because Docker Desktop had no HTTPS proxy configured. The project source was downloaded from GitHub as a ZIP, then built with `Dockerfile.local`, which starts from the locally available `eclipse-temurin:11` image and installs JDK 21 plus Maven from Ubuntu package repositories.

```powershell
docker build -f Dockerfile.local -t meridian-erp:local .
```

## Run

```powershell
docker run -d --name meridian-erp -p 8080:8080 -v "${PWD}\data:/app/data" meridian-erp:local
```

If the container already exists:

```powershell
docker rm -f meridian-erp
docker run -d --name meridian-erp -p 8080:8080 -v "${PWD}\data:/app/data" meridian-erp:local
```

## Verification

Run:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\verify-local.ps1
```

Verified behavior:

- Spring Boot starts on port `8080` with Java 21.
- H2 file database is created under `data/erpdb`.
- Demo seed data is loaded for CRM, HRM, Inventory, Accounting, Support, Projects, Procurement, E-Commerce, Notifications, and Security.
- Admin login succeeds with `admin@erp.com / Admin@1234`.
- Main modules return HTTP 200: dashboard, CRM leads, HRM employees, Inventory products, E-Commerce orders, Accounting invoices/payments/journal, Procurement vendors, Projects, Support tickets, Reports, and Settings users.
- Public storefront supports real data interaction: catalog -> cart -> checkout -> order confirmation.
- Admin order search finds the newly created storefront order.
- Accounting supports real data interaction: creating a payment against a seeded invoice and finding it in the payment list.
