# Meridian ERP Local Deployment Todo

- [x] Download project source from `msiShariful/meridian-erp`.
- [x] Inspect runtime instructions, Maven configuration, and application properties.
- [x] Build the Spring Boot application locally.
- [x] Start the application on localhost.
- [x] Verify login and basic page access.
- [x] Verify at least one real data interaction path.
- [x] Record verified commands, credentials, and any limitations.
