# Test Plan Skill Template

## 触发场景

当用户提供需求、接口变更、Bug 描述或代码 diff，并要求生成测试方案时使用。

## 输入

- 需求描述或变更说明
- 相关代码路径
- 接口文档或数据结构
- 已有测试文件
- 风险约束，例如性能、安全、兼容性

## 工作步骤

1. 读取需求和相关代码，列出可验证行为。
2. 识别风险：业务逻辑、权限、数据一致性、并发、性能、兼容性。
3. 拆分测试层级：单元测试、API 测试、UI 测试、性能测试。
4. 为每个层级生成测试用例。
5. 标记优先级：P0 smoke、P1 regression、P2 extended。
6. 给出测试数据和清理策略。
7. 给出自动化运行方式和报告字段。
8. 明确信息不足项，不编造缺失上下文。

## 输出格式

```markdown
# Test Plan

## Scope

## Risks

## Test Cases

| ID | Layer | Priority | Scenario | Steps | Expected Result |
| --- | --- | --- | --- | --- | --- |

## Automation Plan

## Test Data

## Report Fields

## Missing Information
```

## 失败处理

- 如果缺少接口定义，先输出需要补充的字段。
- 如果代码路径不明确，先请求定位模块。
- 如果已有测试不可运行，先报告阻塞原因。
- 如果需求不可测试，改写成可验证行为列表。
