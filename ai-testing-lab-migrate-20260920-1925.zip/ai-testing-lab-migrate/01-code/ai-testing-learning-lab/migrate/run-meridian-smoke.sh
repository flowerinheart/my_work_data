#!/usr/bin/env bash
# Start Meridian ERP and assert login page is reachable.
set -euo pipefail

CODE_ROOT="${CODE_ROOT:-${HOME}/code}"
ERP="${CODE_ROOT}/meridian-erp"
PORT="${PORT:-8080}"
URL="http://127.0.0.1:${PORT}"
TIMEOUT_SEC="${TIMEOUT_SEC:-900}"
MVN_SETTINGS="${MVN_SETTINGS:-${CODE_ROOT}/ai-testing-learning-lab/migrate/docker/maven-settings-aliyun.xml}"

if [[ ! -f "${ERP}/pom.xml" ]]; then
  echo "meridian-erp pom.xml missing at ${ERP}" >&2
  exit 1
fi
if ! command -v mvn >/dev/null 2>&1; then
  echo "mvn missing" >&2
  exit 1
fi

LOG="${ERP}/migrate-smoke.log"
PID_FILE="${ERP}/migrate-smoke.pid"

if [[ -f "${PID_FILE}" ]] && kill -0 "$(cat "${PID_FILE}")" 2>/dev/null; then
  echo "Already running pid=$(cat "${PID_FILE}")"
else
  echo "Starting Meridian via Maven (Aliyun mirror) ..."
  cd "${ERP}"
  MVN_ARGS=(-DskipTests)
  if [[ -f "${MVN_SETTINGS}" ]]; then
    MVN_ARGS+=(-s "${MVN_SETTINGS}")
  fi
  nohup mvn "${MVN_ARGS[@]}" spring-boot:run > "${LOG}" 2>&1 &
  echo $! > "${PID_FILE}"
fi

echo "Waiting for ${URL} (timeout ${TIMEOUT_SEC}s) ..."
ok=0
for ((i=0; i<TIMEOUT_SEC; i+=3)); do
  code="$(curl -s -o /dev/null -w "%{http_code}" "${URL}/login" || true)"
  if [[ "${code}" == "200" || "${code}" == "302" ]]; then
    echo "LOGIN_PAGE_OK http_code=${code} after ${i}s"
    ok=1
    break
  fi
  if ! kill -0 "$(cat "${PID_FILE}")" 2>/dev/null; then
    echo "Maven process died. Tail of log:" >&2
    tail -n 80 "${LOG}" >&2 || true
    exit 1
  fi
  sleep 3
done

if [[ "${ok}" -ne 1 ]]; then
  echo "Timeout waiting for login page" >&2
  tail -n 80 "${LOG}" >&2 || true
  exit 1
fi

# Form login smoke: GET login + POST with seed admin (CSRF from page).
curl -s -c /tmp/meridian-cookies -D /tmp/meridian-login.hdr -o /tmp/meridian-login.html "${URL}/login"
csrf="$(python3 - <<'PY'
import re, pathlib
html = pathlib.Path("/tmp/meridian-login.html").read_text(encoding="utf-8", errors="ignore")
m = re.search(r'name="_csrf"[^>]*value="([^"]+)"', html) or re.search(r'value="([^"]+)"[^>]*name="_csrf"', html)
print(m.group(1) if m else "")
PY
)"

login_code="skip"
if [[ -n "${csrf}" ]]; then
  login_code="$(curl -s -o /tmp/meridian-login-post.html -w "%{http_code}" \
    -b /tmp/meridian-cookies -c /tmp/meridian-cookies \
    -X POST "${URL}/login" \
    -H "Content-Type: application/x-www-form-urlencoded" \
    --data-urlencode "username=admin@erp.com" \
    --data-urlencode "password=Admin@1234" \
    --data-urlencode "_csrf=${csrf}")"
  echo "LOGIN_POST http_code=${login_code}"
  if [[ "${login_code}" != "302" && "${login_code}" != "200" ]]; then
    echo "Login POST unexpected" >&2
    exit 1
  fi
else
  echo "WARN no CSRF token parsed; page GET still passed"
fi

dash="$(curl -s -o /dev/null -w "%{http_code}" -b /tmp/meridian-cookies "${URL}/dashboard" || true)"
echo "DASHBOARD http_code=${dash}"

echo "SITE_SMOKE_OK url=${URL} login_get=ok login_post=${login_code} dashboard=${dash}"
exit 0
