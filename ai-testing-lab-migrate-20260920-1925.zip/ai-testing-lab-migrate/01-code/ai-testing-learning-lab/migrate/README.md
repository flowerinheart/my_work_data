# 换机迁移（本机 Windows → 新机 **Mac**）

Docker **不能**跑真正的 macOS 系统镜像。Mac 上的 Docker Desktop 跑的也是 **Linux 容器**。本目录用空白 `ubuntu:24.04`（大陆镜像源）在本地把「解包 + 网站起来」跑通，脚本按 Mac 路径 `/Users/<user>/code` 编写。

| 文件 | 用途 | 哪台机器 |
|------|------|----------|
| `pack-migrate.ps1` | Windows 打包 zip | 源机 |
| `restore-migrate.sh` | 解压恢复目录 | **Mac / Linux 容器** |
| `setup-env.sh` | Python venv、JDK/Maven、Skills | Mac / 容器 |
| `run-meridian-smoke.sh` | 启动 ERP 并 curl 登录页 | Mac / 容器 |
| `docker/Dockerfile` | 空白 Ubuntu | 文档/可选 build |
| `docker/test-mirror-speed.sh` | 测大陆 Docker 源速度 | 任意 |
| `docker/run-mac-restore-test.ps1` | 本机一键：测速 → pull → cp zip → 解包 → 网站冒烟 | **源机 Docker** |
| `AGENT-MIGRATE-GUIDE.md` | 给新机 Agent | Mac Cursor |

## 本机验收（必须全绿）

```powershell
cd C:\Users\hma\code\ai-testing-learning-lab\migrate
powershell -ExecutionPolicy Bypass -File .\docker\run-mac-restore-test.ps1
```

成功标志：容器内 `RESTORE_OK` + `SITE_SMOKE_OK`，宿主机 `http://127.0.0.1:18080/login` 返回 200。

## Mac 真机

```bash
unzip 后:
export HOME="$HOME"
export DEST_CODE_ROOT="$HOME/code"
bash restore-migrate.sh ~/Downloads/ai-testing-lab-migrate-XXXX.zip
export CODE_ROOT="$HOME/code"
bash "$CODE_ROOT/ai-testing-learning-lab/migrate/setup-env.sh"
bash "$CODE_ROOT/ai-testing-learning-lab/migrate/run-meridian-smoke.sh"
```
