#!/usr/bin/env bash
# Restore migrate zip onto macOS or Linux (Mac Docker uses Linux containers).
set -euo pipefail

ZIP_PATH="${1:-${ZIP_PATH:-}}"
DEST_CODE_ROOT="${DEST_CODE_ROOT:-${HOME}/code}"
SOURCE_USER="${SOURCE_USER:-hma}"
DEST_USER="${DEST_USER:-$(id -un)}"
SKIP_CURSOR="${SKIP_CURSOR:-0}"
SKIP_REWRITE="${SKIP_REWRITE:-0}"

if [[ -z "${ZIP_PATH}" ]]; then
  echo "usage: $0 /path/to/ai-testing-lab-migrate-YYYYMMDD.zip" >&2
  exit 1
fi
if [[ ! -f "${ZIP_PATH}" ]]; then
  echo "ZIP not found: ${ZIP_PATH}" >&2
  exit 1
fi

WORK="$(mktemp -d "${TMPDIR:-/tmp}/ai-lab-restore.XXXXXX")"
cleanup() { rm -rf "${WORK}"; }
trap cleanup EXIT

echo "Extract to ${WORK}"
# Windows pack uses tar -a zip; macOS/Linux tar and unzip both work.
if tar -tf "${ZIP_PATH}" >/dev/null 2>&1; then
  tar -xf "${ZIP_PATH}" -C "${WORK}"
else
  unzip -q "${ZIP_PATH}" -d "${WORK}"
fi

BUNDLE="${WORK}/ai-testing-lab-migrate"
if [[ ! -d "${BUNDLE}/01-code" ]]; then
  hit="$(find "${WORK}" -maxdepth 2 -type d -name "01-code" | head -n 1 || true)"
  if [[ -n "${hit}" ]]; then
    BUNDLE="$(dirname "${hit}")"
  fi
fi
if [[ ! -d "${BUNDLE}/01-code" ]]; then
  echo "Unexpected zip layout. Expected 01-code under ${BUNDLE}" >&2
  find "${WORK}" -maxdepth 3 -print >&2
  exit 1
fi

mkdir -p "${DEST_CODE_ROOT}"
echo "Restore code -> ${DEST_CODE_ROOT}"
cp -a "${BUNDLE}/01-code/." "${DEST_CODE_ROOT}/"

if [[ -d "${BUNDLE}/migrate-kit" ]]; then
  mkdir -p "${DEST_CODE_ROOT}/ai-testing-learning-lab/migrate"
  cp -a "${BUNDLE}/migrate-kit/." "${DEST_CODE_ROOT}/ai-testing-learning-lab/migrate/"
fi

if [[ "${SKIP_CURSOR}" != "1" ]]; then
  if [[ -d "${BUNDLE}/02-cursor/skills-cursor" ]]; then
    mkdir -p "${HOME}/.cursor/skills-cursor"
    cp -a "${BUNDLE}/02-cursor/skills-cursor/." "${HOME}/.cursor/skills-cursor/"
    echo "Restored skills -> ${HOME}/.cursor/skills-cursor"
  fi

  TX_ROOT="${BUNDLE}/02-cursor/agent-transcripts"
  if [[ -d "${TX_ROOT}" ]]; then
    for src in "${TX_ROOT}"/*; do
      [[ -d "${src}" ]] || continue
      old_slug="$(basename "${src}")"
      new_slug="${old_slug//c-Users-${SOURCE_USER}-/c-Users-${DEST_USER}-}"
      # macOS Cursor slug for /Users/foo/code is often Users-foo-code
      new_slug="${new_slug//c-Users-/Users-}"
      dest_tx="${HOME}/.cursor/projects/${new_slug}/agent-transcripts"
      mkdir -p "${dest_tx}"
      cp -a "${src}/." "${dest_tx}/"
      echo "Transcripts ${old_slug} -> ${new_slug}"
    done
  fi

  MAC_SETTINGS="${HOME}/Library/Application Support/Cursor/User/settings.json"
  LINUX_SETTINGS="${HOME}/.config/Cursor/User/settings.json"
  SRC_SETTINGS="${BUNDLE}/02-cursor/User/settings.json"
  if [[ -f "${SRC_SETTINGS}" ]]; then
    if [[ "$(uname -s)" == "Darwin" ]]; then
      dst="${MAC_SETTINGS}"
    else
      dst="${LINUX_SETTINGS}"
    fi
    mkdir -p "$(dirname "${dst}")"
    if [[ -f "${dst}" ]]; then
      cp "${dst}" "${dst}.bak-$(date +%Y%m%d-%H%M%S)"
    fi
    cp "${SRC_SETTINGS}" "${dst}"
    echo "Restored settings.json -> ${dst}"
  fi
fi

if [[ "${SKIP_REWRITE}" != "1" ]]; then
  OLD_WIN="C:\\Users\\${SOURCE_USER}\\code"
  OLD_WIN_SLASH="C:/Users/${SOURCE_USER}/code"
  echo "Rewrite ${OLD_WIN} -> ${DEST_CODE_ROOT}"
  export DEST_CODE_ROOT OLD_WIN OLD_WIN_SLASH
  python3 - <<PY
import os
root = os.environ.get("DEST_CODE_ROOT", r"${DEST_CODE_ROOT}")
old_win = r"${OLD_WIN}"
old_slash = r"${OLD_WIN_SLASH}"
new = r"${DEST_CODE_ROOT}"
skip = {".venv", "venv", "target", "node_modules", "__pycache__"}
exts = {".md", ".html", ".ps1", ".py", ".txt", ".json", ".sh"}
for dirpath, dirnames, filenames in os.walk(root):
    dirnames[:] = [d for d in dirnames if d not in skip]
    for name in filenames:
        _, ext = os.path.splitext(name)
        if ext.lower() not in exts:
            continue
        path = os.path.join(dirpath, name)
        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                raw = f.read()
        except OSError:
            continue
        nxt = raw.replace(old_win, new).replace(old_slash, new)
        if nxt != raw:
            with open(path, "w", encoding="utf-8") as f:
                f.write(nxt)
PY
fi

MARKER="${DEST_CODE_ROOT}/ai-testing-learning-lab/migrate/RESTORED.txt"
mkdir -p "$(dirname "${MARKER}")"
{
  echo "restored=$(date -Iseconds)"
  echo "zip=${ZIP_PATH}"
  echo "destCodeRoot=${DEST_CODE_ROOT}"
  echo "destUser=${DEST_USER}"
  echo "uname=$(uname -s)"
} > "${MARKER}"

echo "RESTORE_OK dest=${DEST_CODE_ROOT}"
echo "Next: DEST_CODE_ROOT=${DEST_CODE_ROOT} bash ${DEST_CODE_ROOT}/ai-testing-learning-lab/migrate/setup-env.sh"
