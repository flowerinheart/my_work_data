#!/usr/bin/env bash
# Install Python venv / Playwright / check tree on macOS or Linux (Docker).
set -euo pipefail

CODE_ROOT="${CODE_ROOT:-${HOME}/code}"
SKIP_PLAYWRIGHT="${SKIP_PLAYWRIGHT:-0}"
SKIP_APT="${SKIP_APT:-0}"
INSTALL_DEPS="${INSTALL_DEPS:-1}"

echo "=== 1. Directory tree ==="
required=(
  "AI_TESTING_AGENT_ZONES.md"
  "ai-testing-learning-lab/docs/accounted-study-plan.html"
  "ai-testing-learning-lab/migrate/AGENT-MIGRATE-GUIDE.md"
  "ai-testing-lab-whiteboard/AGENT-WHITEBOARD.md"
  "ai-testing-lab-whiteboard/work/week02-skills/my-test-plan-skill.md"
  "ai-testing-lab-whiteboard/project/meridian-erp-starter/pom.xml"
  "ai-testing-lab-evaluator/AGENT-EVALUATOR.md"
  "playwright-api-lab/requirements.txt"
  "playwright-api-lab/meridian-autotest/conftest.py"
  "meridian-erp/pom.xml"
)
missing=0
for rel in "${required[@]}"; do
  if [[ -e "${CODE_ROOT}/${rel}" ]]; then
    echo "  OK  ${rel}"
  else
    echo "  MISS ${rel}"
    missing=1
  fi
done
if [[ "${missing}" -ne 0 ]]; then
  echo "Tree incomplete. CODE_ROOT=${CODE_ROOT}" >&2
fi

echo ""
echo "=== 2. OS packages (python / jdk / maven) ==="
UNAME="$(uname -s)"
if [[ "${INSTALL_DEPS}" == "1" && "${SKIP_APT}" != "1" ]]; then
  if [[ "${UNAME}" == "Darwin" ]]; then
    if ! command -v brew >/dev/null 2>&1; then
      echo "Homebrew missing. Install from https://brew.sh then: brew install python@3.12 openjdk@21 maven" >&2
    else
      brew list python@3.12 >/dev/null 2>&1 || brew install python@3.12
      brew list openjdk@21 >/dev/null 2>&1 || brew install openjdk@21
      brew list maven >/dev/null 2>&1 || brew install maven
      export PATH="$(brew --prefix python@3.12)/bin:$(brew --prefix openjdk@21)/bin:${PATH}"
    fi
  else
    if command -v apt-get >/dev/null 2>&1; then
      export DEBIAN_FRONTEND=noninteractive
      if [[ -f /etc/apt/sources.list.d/ubuntu.sources ]]; then
        sed -i 's|http://archive.ubuntu.com/ubuntu|https://mirrors.tuna.tsinghua.edu.cn/ubuntu|g' /etc/apt/sources.list.d/ubuntu.sources
        sed -i 's|http://security.ubuntu.com/ubuntu|https://mirrors.tuna.tsinghua.edu.cn/ubuntu|g' /etc/apt/sources.list.d/ubuntu.sources
      elif [[ -f /etc/apt/sources.list ]]; then
        sed -i 's|http://archive.ubuntu.com/ubuntu|https://mirrors.tuna.tsinghua.edu.cn/ubuntu|g' /etc/apt/sources.list
        sed -i 's|http://security.ubuntu.com/ubuntu|https://mirrors.tuna.tsinghua.edu.cn/ubuntu|g' /etc/apt/sources.list
      fi
      apt-get update -y
      apt-get install -y --no-install-recommends \
        python3 python3-venv python3-pip \
        openjdk-21-jdk maven \
        curl ca-certificates unzip tar findutils
    fi
  fi
fi

if ! command -v python3 >/dev/null 2>&1; then
  echo "python3 missing" >&2
  exit 1
fi
python3 --version

echo ""
echo "=== 3. Python venv + Playwright package ==="
LAB="${CODE_ROOT}/playwright-api-lab"
VENV="${LAB}/.venv"
REQ="${LAB}/requirements.txt"
if [[ ! -x "${VENV}/bin/python" ]]; then
  python3 -m venv "${VENV}"
fi
"${VENV}/bin/python" -m pip install --upgrade pip
# pip mainland mirror
"${VENV}/bin/python" -m pip install -r "${REQ}" -i https://pypi.tuna.tsinghua.edu.cn/simple --trusted-host pypi.tuna.tsinghua.edu.cn
if [[ "${SKIP_PLAYWRIGHT}" != "1" ]]; then
  "${VENV}/bin/python" -m playwright install chromium || true
fi

echo ""
echo "=== 4. Skills ==="
if [[ -d "${HOME}/.cursor/skills-cursor" ]]; then
  n="$(find "${HOME}/.cursor/skills-cursor" -mindepth 1 -maxdepth 1 -type d | wc -l | tr -d ' ')"
  echo "  OK  ${HOME}/.cursor/skills-cursor (${n} skill folders)"
else
  echo "  WARN skills folder missing (optional in Docker)"
fi

echo ""
echo "=== 5. JDK / Maven ==="
if command -v java >/dev/null 2>&1; then java -version 2>&1 | head -n 1; else echo "java MISSING"; missing=1; fi
if command -v mvn >/dev/null 2>&1; then mvn -version 2>&1 | head -n 1; else echo "mvn MISSING"; missing=1; fi

TREE_FILE="${CODE_ROOT}/ai-testing-learning-lab/migrate/RESTORED-TREE.txt"
{
  echo "codeRoot=${CODE_ROOT}"
  echo "user=$(id -un)"
  echo "uname=${UNAME}"
  echo "checked=$(date -Iseconds)"
  echo "dirs:"
  ls -1 "${CODE_ROOT}"
} > "${TREE_FILE}"

echo ""
echo "=== DONE setup-env.sh ==="
if [[ "${missing}" -ne 0 ]]; then
  exit 1
fi
exit 0
