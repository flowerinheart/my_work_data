﻿#Requires -Version 5.1
<#
.SYNOPSIS
  Unzip the migrate bundle and restore directory layout on a new Windows PC.

.EXAMPLE
  powershell -ExecutionPolicy Bypass -File .\restore-migrate.ps1 -ZipPath "$env:USERPROFILE\Desktop\ai-testing-lab-migrate-20260920-1915.zip"
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$ZipPath,
    [string]$DestCodeRoot = "$env:USERPROFILE\code",
    [string]$SourceUser = "hma",
    [string]$DestUser = $env:USERNAME,
    [switch]$SkipCursor,
    [switch]$SkipRewritePaths
)

$ErrorActionPreference = "Stop"
if (-not (Test-Path -LiteralPath $ZipPath)) {
    throw "Zip not found: $ZipPath"
}

$Work = Join-Path $env:TEMP ("ai-testing-lab-restore-" + (Get-Date -Format "yyyyMMdd-HHmmss"))
New-Item -ItemType Directory -Force -Path $Work | Out-Null
Write-Host "Extract to $Work"

$zipFull = (Resolve-Path -LiteralPath $ZipPath).Path
Push-Location $Work
try {
    tar.exe -xf $zipFull
    if ($LASTEXITCODE -ne 0) { throw "tar extract failed: $LASTEXITCODE" }
}
finally {
    Pop-Location
}

$Bundle = Join-Path $Work "ai-testing-lab-migrate"
if (-not (Test-Path $Bundle)) {
    $hit = Get-ChildItem $Work -Directory | Select-Object -First 1
    if ($hit) { $Bundle = $hit.FullName }
}
if (-not (Test-Path (Join-Path $Bundle "01-code"))) {
    throw "Unexpected zip layout. Expected 01-code under $Bundle"
}

function Invoke-RobocopySafe {
    param([string]$Source, [string]$Dest)
    if (-not (Test-Path -LiteralPath $Source)) {
        Write-Warning "SKIP missing: $Source"
        return
    }
    New-Item -ItemType Directory -Force -Path $Dest | Out-Null
    & robocopy $Source $Dest /E /COPY:DAT /R:1 /W:1 /MT:8 /NFL /NDL /NJH /NP | Out-Host
    if ($LASTEXITCODE -ge 8) { throw "robocopy failed ($LASTEXITCODE): $Source" }
}

Write-Host "Restore code -> $DestCodeRoot"
New-Item -ItemType Directory -Force -Path $DestCodeRoot | Out-Null
Invoke-RobocopySafe -Source (Join-Path $Bundle "01-code") -Dest $DestCodeRoot

# migrate kit also lives inside learning-lab after copy; keep a top-level copy of restore scripts from zip root
$kit = Join-Path $Bundle "migrate-kit"
if (Test-Path $kit) {
    $migrateDest = Join-Path $DestCodeRoot "ai-testing-learning-lab\migrate"
    Invoke-RobocopySafe -Source $kit -Dest $migrateDest
}

if (-not $SkipCursor) {
    $srcSkills = Join-Path $Bundle "02-cursor\skills-cursor"
    $dstSkills = Join-Path $env:USERPROFILE ".cursor\skills-cursor"
    Write-Host "Restore skills -> $dstSkills"
    Invoke-RobocopySafe -Source $srcSkills -Dest $dstSkills

    $txSrcRoot = Join-Path $Bundle "02-cursor\agent-transcripts"
    if (Test-Path $txSrcRoot) {
        Get-ChildItem -LiteralPath $txSrcRoot -Directory | ForEach-Object {
            $oldSlug = $_.Name
            $newSlug = $oldSlug -replace [regex]::Escape("c-Users-$SourceUser-"), "c-Users-$DestUser-"
            $dst = Join-Path $env:USERPROFILE ".cursor\projects\$newSlug\agent-transcripts"
            Write-Host "Transcripts $oldSlug -> $newSlug"
            Invoke-RobocopySafe -Source $_.FullName -Dest $dst
        }
    }

    $srcSettings = Join-Path $Bundle "02-cursor\User\settings.json"
    $dstSettings = Join-Path $env:APPDATA "Cursor\User\settings.json"
    if (Test-Path $srcSettings) {
        New-Item -ItemType Directory -Force -Path (Split-Path $dstSettings) | Out-Null
        if (Test-Path $dstSettings) {
            Copy-Item $dstSettings "$dstSettings.bak-$(Get-Date -Format 'yyyyMMdd-HHmmss')" -Force
        }
        Copy-Item $srcSettings $dstSettings -Force
        Write-Host "Restored settings.json (backup created if existed)"
    }

    $srcSnip = Join-Path $Bundle "02-cursor\User\snippets"
    if (Test-Path $srcSnip) {
        Invoke-RobocopySafe -Source $srcSnip -Dest (Join-Path $env:APPDATA "Cursor\User\snippets")
    }
}

if (-not $SkipRewritePaths -and ($SourceUser -ne $DestUser -or $DestCodeRoot -ne "C:\Users\$SourceUser\code")) {
    Write-Host "Rewrite C:\Users\$SourceUser\code -> $DestCodeRoot in text files..."
    $old = "C:\Users\$SourceUser\code"
    $oldSlash = $old -replace "\\", "/"
    $new = $DestCodeRoot
    $newSlash = $new -replace "\\", "/"
    $ext = @("*.md", "*.html", "*.ps1", "*.py", "*.txt", "*.json")
    foreach ($e in $ext) {
        Get-ChildItem -LiteralPath $DestCodeRoot -Recurse -File -Filter $e -ErrorAction SilentlyContinue |
            Where-Object { $_.FullName -notmatch '\\target\\|\\\.venv\\|\\node_modules\\' } |
            ForEach-Object {
                try {
                    $raw = [System.IO.File]::ReadAllText($_.FullName)
                } catch { return }
                if ($raw -notlike "*$old*" -and $raw -notlike "*$oldSlash*") { return }
                $next = $raw.Replace($old, $new).Replace($oldSlash, $newSlash)
                if ($next -ne $raw) {
                    [System.IO.File]::WriteAllText($_.FullName, $next)
                }
            }
    }
}

$marker = Join-Path $DestCodeRoot "ai-testing-learning-lab\migrate\RESTORED.txt"
@"
restored=$(Get-Date -Format o)
zip=$zipFull
destCodeRoot=$DestCodeRoot
destUser=$DestUser
Next: powershell -ExecutionPolicy Bypass -File `"$DestCodeRoot\ai-testing-learning-lab\migrate\setup-env.ps1`"
"@ | Set-Content -LiteralPath $marker -Encoding UTF8

Write-Host ""
Write-Host "RESTORE_OK dest=$DestCodeRoot"
Write-Host "Next: run setup-env.ps1 (Python venv + Playwright + tree check)"
Write-Host "  powershell -ExecutionPolicy Bypass -File `"$DestCodeRoot\ai-testing-learning-lab\migrate\setup-env.ps1`""

Remove-Item -LiteralPath $Work -Recurse -Force -ErrorAction SilentlyContinue
