#!/usr/bin/env bash
# Probe mainland Docker Hub proxies. Prints time_total and http_code. Does not pull.
set -euo pipefail

MIRRORS=(
  "https://docker.m.daocloud.io"
  "https://docker.1ms.run"
  "https://dockerproxy.net"
)

echo "speed-test docker registry /v2/ (lower time_total is better)"
best=""
best_t="9999"
for base in "${MIRRORS[@]}"; do
  # anonymous /v2/ often 401 with a short body — still measures RTT
  out="$(curl -sS -o /dev/null -w "%{http_code} %{time_total} %{speed_download}" \
    --connect-timeout 8 --max-time 15 \
    -H "Accept: application/vnd.docker.distribution.manifest.v2+json" \
    "${base}/v2/" || echo "000 9999 0")"
  echo "  ${base}  ${out}"
  t="$(echo "${out}" | awk '{print $2}')"
  code="$(echo "${out}" | awk '{print $1}')"
  if awk -v t="${t}" -v b="${best_t}" 'BEGIN {exit !(t+0 < b+0 && t+0 < 8)}'; then
    if [[ "${code}" != "000" ]]; then
      best="${base}"
      best_t="${t}"
    fi
  fi
done

if [[ -z "${best}" ]]; then
  echo "NO_FAST_MIRROR" >&2
  exit 1
fi
echo "BEST_MIRROR=${best} time=${best_t}"
# strip scheme for docker pull prefix: docker.m.daocloud.io
echo "${best#https://}" > /tmp/ai-lab-best-docker-mirror.txt
echo "${best#https://}"
