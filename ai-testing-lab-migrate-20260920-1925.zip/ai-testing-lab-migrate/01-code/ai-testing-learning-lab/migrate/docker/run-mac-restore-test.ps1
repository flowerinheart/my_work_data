#Requires -Version 5.1
<#
.SYNOPSIS
  Windows host: speed-test CN Docker mirrors, pull ubuntu:24.04, copy migrate zip, restore, smoke Meridian.

  Docker cannot run a real macOS image. This uses a blank Ubuntu image — the same class of
  Linux container Mac Docker Desktop runs.
#>
[CmdletBinding()]
param(
    [string]$ZipPath = "",
    [string]$MigrateDir = "C:\Users\hma\code\ai-testing-learning-lab\migrate",
    [string]$CodeRoot = "C:\Users\hma\code",
    [string]$ContainerName = "ai-lab-mac-restore",
    [double]$MaxMirrorSeconds = 8
)

$ErrorActionPreference = "Stop"

function Assert-Docker {
    docker info 2>$null | Out-Null
    if ($LASTEXITCODE -ne 0) {
        throw "Docker engine is not running. Start Docker Desktop first."
    }
}

function Get-BestMirror {
    $mirrors = @(
        "https://docker.m.daocloud.io",
        "https://docker.1ms.run",
        "https://dockerproxy.net"
    )
    $best = $null
    $bestT = 9999.0
    Write-Host "=== Mirror speed test (HEAD /v2/) ==="
    foreach ($base in $mirrors) {
        try {
            $sw = [Diagnostics.Stopwatch]::StartNew()
            $code = 0
            try {
                $resp = Invoke-WebRequest -Uri "$base/v2/" -Method Get -TimeoutSec 15 -UseBasicParsing
                $code = [int]$resp.StatusCode
            } catch {
                if ($_.Exception.Response) {
                    $code = [int]$_.Exception.Response.StatusCode
                } else {
                    throw
                }
            }
            $sw.Stop()
            $sec = $sw.Elapsed.TotalSeconds
            Write-Host ("  {0,-36} http={1}  {2:n2}s" -f $base, $code, $sec)
            # 401 from /v2/ is normal for anonymous Docker Hub proxies
            if ($sec -lt $bestT -and $sec -le $MaxMirrorSeconds -and $code -ge 200) {
                $bestT = $sec
                $best = $base
            }
        } catch {
            Write-Host ("  {0,-36} FAIL {1}" -f $base, $_.Exception.Message)
        }
    }
    if (-not $best) { throw "No mainland Docker mirror answered within ${MaxMirrorSeconds}s" }
    $hostOnly = $best.TrimEnd("/") -replace "^https://", ""
    Write-Host "BEST_MIRROR=$hostOnly (${bestT:n2}s)"
    return $hostOnly
}

function Ensure-Zip {
    param([string]$Path)
    if ($Path -and (Test-Path $Path)) { return (Resolve-Path $Path).Path }
    $found = Get-ChildItem "$env:USERPROFILE\Desktop\ai-testing-lab-migrate-*.zip" -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if ($found) { return $found.FullName }
    Write-Host "No zip on Desktop; packing now..."
    & powershell -ExecutionPolicy Bypass -File (Join-Path $MigrateDir "pack-migrate.ps1")
    $found = Get-ChildItem "$env:USERPROFILE\Desktop\ai-testing-lab-migrate-*.zip" |
        Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if (-not $found) { throw "pack-migrate.ps1 did not produce a zip" }
    return $found.FullName
}

Assert-Docker
$mirror = Get-BestMirror
$image = "${mirror}/library/ubuntu:24.04"
Write-Host "=== docker pull $image ==="
docker pull $image
if ($LASTEXITCODE -ne 0) { throw "docker pull failed: $image" }

$zip = Ensure-Zip -Path $ZipPath
Write-Host "ZIP=$zip"

docker rm -f $ContainerName 2>$null | Out-Null
Write-Host "=== run blank container $ContainerName ==="
docker run -d --name $ContainerName --memory=4g -p 18080:8080 `
    -e HOME=/Users/hma `
    -e CODE_ROOT=/Users/hma/code `
    -e DEST_CODE_ROOT=/Users/hma/code `
    -e SKIP_PLAYWRIGHT=1 `
    $image sleep infinity | Out-Host

docker exec $ContainerName bash -lc "mkdir -p /Users/hma /work"
docker cp $zip "${ContainerName}:/work/migrate.zip"
# also copy current migrate scripts (in case zip was packed before sh files existed)
docker cp $MigrateDir "${ContainerName}:/work/migrate-host"

Write-Host "=== unpack + setup + site smoke inside container ==="
$inner = @'
set -euo pipefail
export HOME=/Users/hma
export CODE_ROOT=/Users/hma/code
export DEST_CODE_ROOT=/Users/hma/code
export SKIP_PLAYWRIGHT=1
export DEBIAN_FRONTEND=noninteractive

# CRLF -> LF for scripts copied from Windows
find /work/migrate-host -name "*.sh" -exec sed -i "s/\r$//" {} \;
chmod +x /work/migrate-host/*.sh /work/migrate-host/docker/*.sh || true

# restore needs python3 for path rewrite; install curl/python first (tiny)
if [[ -f /etc/apt/sources.list.d/ubuntu.sources ]]; then
  sed -i "s|http://archive.ubuntu.com/ubuntu|https://mirrors.tuna.tsinghua.edu.cn/ubuntu|g" /etc/apt/sources.list.d/ubuntu.sources
  sed -i "s|http://security.ubuntu.com/ubuntu|https://mirrors.tuna.tsinghua.edu.cn/ubuntu|g" /etc/apt/sources.list.d/ubuntu.sources
fi
apt-get update -y
apt-get install -y --no-install-recommends python3 curl ca-certificates tar unzip findutils

bash /work/migrate-host/restore-migrate.sh /work/migrate.zip
# prefer restored scripts, still strip CRLF
find "$CODE_ROOT/ai-testing-learning-lab/migrate" -name "*.sh" -exec sed -i "s/\r$//" {} \;
chmod +x "$CODE_ROOT/ai-testing-learning-lab/migrate/"*.sh

bash "$CODE_ROOT/ai-testing-learning-lab/migrate/setup-env.sh"
bash "$CODE_ROOT/ai-testing-learning-lab/migrate/run-meridian-smoke.sh"
'@

# write inner script via docker exec
$innerPath = Join-Path $env:TEMP "ai-lab-inner.sh"
[System.IO.File]::WriteAllText($innerPath, ($inner -replace "`r`n", "`n"), (New-Object System.Text.UTF8Encoding $false))
docker cp $innerPath "${ContainerName}:/work/inner.sh"
docker exec $ContainerName bash /work/inner.sh
if ($LASTEXITCODE -ne 0) { throw "inner restore/smoke failed" }

Write-Host "=== host curl published port 18080 ==="
$code = (Invoke-WebRequest -Uri "http://127.0.0.1:18080/login" -UseBasicParsing -TimeoutSec 30).StatusCode
Write-Host "HOST_LOGIN_HTTP=$code"
if ($code -ne 200) { throw "host login page not 200" }

Write-Host ""
Write-Host "ALL_OK image=$image zip=$zip container=$ContainerName"
Write-Host "Login: http://127.0.0.1:18080/login   admin@erp.com / Admin@1234"
