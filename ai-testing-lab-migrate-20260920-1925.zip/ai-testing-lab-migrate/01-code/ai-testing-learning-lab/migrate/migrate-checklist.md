# 换机清单：另一台电脑该拷什么

默认源路径（本机）：`C:\Users\hma\code`  
默认目标路径（新机 Mac）：`/Users/<user>/code`  
源机打包仍在 Windows：`C:\Users\hma\code`

跑 `pack-migrate.ps1` 会按本表打包。打勾表示「已经进 zip」；未勾的要**手工**或**新机重装**。

---

## A. 必须进 zip（脚本默认拷）

### A1. 代码仓库（整仓，排除 `.git` / `.venv` / `target`）

| 源路径 | 进 zip 后 | 作用 |
|--------|-----------|------|
| `C:\Users\hma\code\ai-testing-learning-lab` | `01-code\ai-testing-learning-lab` | 九周计划、HTML 课表、本 migrate 脚本 |
| `C:\Users\hma\code\ai-testing-lab-whiteboard` | `01-code\ai-testing-lab-whiteboard` | 白板练习 + **去掉测试答案的** `project\meridian-erp-starter` 网页源码 |
| `C:\Users\hma\code\meridian-erp` | `01-code\meridian-erp` | **完整被测网页项目**（跑 `localhost:8080`） |
| `C:\Users\hma\code\playwright-api-lab` | `01-code\playwright-api-lab` | Playwright 日练 + `meridian-autotest` |
| `C:\Users\hma\code\ai-testing-lab-evaluator` | `01-code\ai-testing-lab-evaluator` | 验证区 oracle/rubrics（白板聊天里不要打开） |
| `C:\Users\hma\code\AI_TESTING_AGENT_ZONES.md` | `01-code\AI_TESTING_AGENT_ZONES.md` | 分区路由 |

学习仓里的 `interview-sprint-complete-pack` **默认不拷**（与上面仓库重复）。若要阅读快照，打包时加 `-IncludeSnapshotPack`。

### A2. Cursor 本地文件（聊天记录 / Skills / 编辑器设置）

| 源路径 | 进 zip 后 | 说明 |
|--------|-----------|------|
| `%USERPROFILE%\.cursor\skills-cursor` | `02-cursor\skills-cursor` | Cursor 自带 Skills |
| `%USERPROFILE%\.cursor\projects\c-Users-hma-code\agent-transcripts` | `02-cursor\agent-transcripts\c-Users-hma-code` | 本工作区聊天 JSONL |
| `%USERPROFILE%\.cursor\projects\c-Users-hma-code-playwright-api-lab\agent-transcripts` | 同上对应 slug | Playwright 仓聊天 |
| `%USERPROFILE%\.cursor\projects\c-Users-hma-code-ai-testing-lab-evaluator\agent-transcripts` | 同上对应 slug | 验证区聊天（若有） |
| `%APPDATA%\Cursor\User\settings.json` | `02-cursor\User\settings.json` | 编辑器设置 |
| `%APPDATA%\Cursor\User\snippets` | `02-cursor\User\snippets` | 代码片段（有则拷） |
| 本目录 `user-rules-to-paste.md` | `02-cursor\user-rules-to-paste.md` | User Rules 备份稿 |

---

## B. zip 拷不走、新机必须另做

- [ ] 安装 [Cursor](https://cursor.com)，**登录同一账号**（Memories / 部分 Rules 在云端）
- [ ] 打开 Settings → Rules，把 `user-rules-to-paste.md` 贴进 User Rules
- [ ] Python **3.12**（本机：`C:\Users\hma\AppData\Local\Programs\Python\Python312`）
- [ ] 跑 `setup-env.ps1`：建 `.venv`、`pip install -r requirements.txt`、`playwright install chromium`
- [ ] **JDK 21 + Maven**（本机当前 PATH 里也没有 `java`/`mvn`，新机一样要装才能启 Meridian）
  - `winget install Microsoft.OpenJDK.21`
  - `winget install Apache.Maven`
- [ ] 新开终端确认：`python --version`、`java -version`、`mvn -version`
- [ ] 用 Cursor 打开 `%USERPROFILE%\code`（或至少打开 whiteboard / playwright-api-lab / evaluator **三个文件夹不要混在同一个「求标准答案」聊天里**）
- [ ] 新机 Agent 先读 `migrate\AGENT-MIGRATE-GUIDE.md`

---

## C. 故意不拷（省体积 / 无意义 / 会坏）

| 项 | 原因 |
|----|------|
| `.venv` / `venv` | 换机重建 |
| `target/` | Maven 编译产物 |
| `.git/` | 体积大；需要历史再单独 `git clone` 或拷 `.git` |
| `__pycache__` / `.pytest_cache` / `node_modules` | 可再生 |
| `%APPDATA%\Cursor\User\History` | 编辑器本地历史，极大 |
| `%APPDATA%\Cursor\User\workspaceStorage` | sqlite 工作区状态，路径绑定旧机 |
| `.cursor\projects\*\mcps` | MCP 工具描述会再生 |
| 数字 ID / Temp 的 Cursor project 目录 | 一次性窗口，不是学习仓 |
| `accounted` / `resume` / `english` 等其它 `code` 子目录 | 与本 lab 无关 |

---

## D. 拷了也不等于「记忆恢复」——漏项说明

| 你以为在 zip 里 | 实际 |
|------------------|------|
| Cursor Memories（对话里「记住」的条目） | **账号云端**。同账号登录后可能出现；否则只能靠 transcripts + 本指南 |
| User Rules 在 Cursor 云设置里的那份 | 用 `user-rules-to-paste.md` 再贴一次 |
| Composer UI 里的聊天气泡 | 本地主要是 `agent-transcripts\*.jsonl`，**不会**在新机自动变成可点开的同一条 Chat |
| MCP（GitHub 等）登录态 | 新机重新授权 |
| Meridian 跑过的 H2（`meridian-erp\data`） | 若源机有 `data\` 会打进 zip；没有则首次 `mvn spring-boot:run` 再种子 |
| `interview-sprint-complete-pack` | 默认不打；原仓库已含全部学习文件 |

---

## E. 新机恢复后应出现的目录（核对用）

```text
%USERPROFILE%\code\
  AI_TESTING_AGENT_ZONES.md
  ai-testing-learning-lab\          # 含 migrate\ 与 docs\
  ai-testing-lab-whiteboard\        # work\ + materials\ + project\meridian-erp-starter\
  ai-testing-lab-evaluator\         # oracle\ rubrics\
  playwright-api-lab\               # day01.. + meridian-autotest\ + 恢复后的 .venv\
  meridian-erp\                     # 完整 Spring Boot 源码

%USERPROFILE%\.cursor\
  skills-cursor\
  projects\c-Users-<新用户名>-code\agent-transcripts\

%APPDATA%\Cursor\User\settings.json
```

`setup-env.ps1` 结束会再打印一遍并检查关键文件是否存在。

---

## F. 源机打包前自检

- [ ] 白板 `work\week01`、`week01b-rules`、`week02-skills` 已保存
- [ ] 关闭正在写的 Excel/HTML 占用
- [ ] zip 拷到 U 盘 / 网盘后再在新机校验哈希（脚本会写 `MANIFEST.txt` 与文件计数）
