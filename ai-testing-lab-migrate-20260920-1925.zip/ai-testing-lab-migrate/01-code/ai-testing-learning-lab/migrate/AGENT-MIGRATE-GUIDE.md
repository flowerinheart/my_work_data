# 给另一台机器上 Agent 的默认使用指南

你正在用户的 **AI Testing Lab** 换机环境里工作。先读本文，再动手。用户中文提问就用中文答。

**不要**用 AMD/HPC/Triton 人设来带这个 lab（那是另一套 User Rule，只在用户明确做 ROCm/内核时才用）。  
**不要**回答股票/行情/交易（复吸预防）。  
**不要**主动 git commit / push。

---

## 1. 机器上有什么（默认路径）

把 `<USER>` 换成新机用户名。源机是 Windows `hma`。新机是 **Mac**，代码根目录默认 `/Users/<USER>/code`。

| 路径 | 名字 | 你怎么用 |
|------|------|----------|
| `C:\Users\<USER>\code\ai-testing-learning-lab` | 九周总课表 | 只读计划、HTML、本 migrate 文档 |
| `C:\Users\<USER>\code\ai-testing-lab-whiteboard` | **白板练习区** | 从零练习；**禁止**读 evaluator |
| `C:\Users\<USER>\code\ai-testing-lab-evaluator` | **验证区** | 只在用户要「验证」时打开 |
| `C:\Users\<USER>\code\playwright-api-lab` | Playwright 接口课 | 日练 `day0X/` + `meridian-autotest/` |
| `C:\Users\<USER>\code\meridian-erp` | 完整被测 ERP | 本地 `http://localhost:8080` |
| `C:\Users\<USER>\code\ai-testing-lab-whiteboard\project\meridian-erp-starter` | 白板用 SUT（去测试答案） | 白板 Agent 读源码用这个 |
| `C:\Users\<USER>\code\AI_TESTING_AGENT_ZONES.md` | 分区说明 | 切换白板/验证前再读一遍 |

分区硬规则：

- 白板聊天：读 `ai-testing-lab-whiteboard\AGENT-WHITEBOARD.md`。不给标准答案，不读 `evaluator\oracle`、`rubrics`。
- 验证聊天：**新开 Chat**，读 `ai-testing-lab-evaluator\AGENT-EVALUATOR.md`。口令例：`请验证白板区 work/week02-skills 的学习成果。`
- Playwright 课：读 `playwright-api-lab\AGENT.md`。不要把九周「标准答案测试套件」一次写完；学生要自己敲 TODO。

---

## 2. 学习进度（换机时的事实，不要倒退）

课表：`ai-testing-learning-lab\docs\accounted-study-plan.html`  
口径：**跳过第 3 周单元测试**；第 4 周是 M6（Playwright UI + 本仓库里的 API 课表被并进 8 天 sprint）。

| 周 | 状态 | 关键产物 |
|----|------|----------|
| Week01 | 已完成并验证过 | `whiteboard\work\week01\test-task-template.md`、`ai-output-review.md` |
| Week01b Rules | 已完成并验证过 | `testing-rules.md`、`data-and-db-rules.md`；`ui-testability-rules.md` 仍可能是骨架 |
| Week02 Skills | 已完成，可再验证 | `my-test-plan-skill.md`、`my-failure-log-skill.md`、`task-03-invocation-samples.md`、`self-review.md` |
| Week03 单测 | **跳过** | 不要拉用户回去写 JUnit |
| Week04 | 进行中/下一阶段 | Playwright：见 `materials\week04-playwright-ui-automation-guide.html` 与 `playwright-api-lab` |

发票新建主线（与 Week01～02 一致）：

`列表 → 新建表单 → POST /accounting/invoices/save → 302 → /accounting/invoices/{uuid} 详情`

不测：edit / delete / **Record Payment 提交**。详情页按钮只允许观察权限可见性。

金额三阶段：保存前 Alpine = 手算；保存后详情金额 = DB。权限：`ACCOUNTING_VIEW` / `ACCOUNTING_EDIT`，UI + API，期望无 EDIT 时 save 为 **403** 且 **DB 不增行**（产品现状曾出现越权写入，记缺陷而不是改标准）。

---

## 3. 被测系统怎么跑

```powershell
cd C:\Users\<USER>\code\meridian-erp
mvn spring-boot:run
```

浏览器：`http://localhost:8080`  
种子密码一律 `Admin@1234`。常用：

- `admin@erp.com` — VIEW+EDIT
- `mehedi.emp@erp.com` — 无 Accounting（权限对照 B）
- VIEW-only 对照账号往往要**临时建**，不要编造

自动化：

```powershell
cd C:\Users\<USER>\code\playwright-api-lab
.\.venv\Scripts\python.exe -m pytest meridian-autotest\tests\api\test_login.py --tb=short
```

`meridian-autotest\config\settings.py`：`BASE_URL=http://localhost:8080`。ERP 没起来时不要改断言来「让测试绿」。

Playwright UI 门禁（Week04）：禁止主路径 `waitForTimeout`；优先 role/name/href；失败要 screenshot/trace；不要测 payment 提交。

---

## 4. 换机后环境若没装好

让用户跑：

```powershell
powershell -ExecutionPolicy Bypass -File C:\Users\<USER>\code\ai-testing-learning-lab\migrate\setup-env.ps1
```

缺 JDK/Maven 时：**不要**假装 Meridian 已在跑。先让用户 `winget install Microsoft.OpenJDK.21` 和 `Apache.Maven`。

Skills 应在 `%USERPROFILE%\.cursor\skills-cursor\`。User Rules 让用户自己把 `migrate\user-rules-to-paste.md` 贴进 Cursor。

旧聊天 JSONL 在：

`%USERPROFILE%\.cursor\projects\c-Users-<USER>-code\agent-transcripts\`

**白板 Agent 禁止拿旧 transcript 当标准答案。** 用户明确说「接着上次 whiteboard 会话」时，可以读 `c979c597-f4b0-46a1-beff-4a5f5da4a4f6` 这类文件了解进度，但仍遵守白板「不给完整答案」——除非用户像源机那样**明确要标准答案/HTML**。

---

## 5. 你该怎么开场（新机第一条消息）

1. 确认工作区根目录是 `C:\Users\<USER>\code` 或用户指定的仓库。
2. 问用户当前要做：**白板 / 验证 / Playwright 日练 / 起 ERP**，不要三个区的规则搅在一个 Chat。
3. 若用户说「继续学习」：默认下一件是 Week04 Playwright（UI 自动化 + 已有 API lab），不是重写 Week01。

---

## 6. 常见文件速查

| 用户在找 | 文件 |
|----------|------|
| 九周总表 | `ai-testing-learning-lab\docs\accounted-study-plan.html` |
| 发票 UI 测试点 | `whiteboard\materials\invoice-ui-test-points.html` |
| Playwright UI 总览 | `whiteboard\materials\week04-playwright-ui-automation-guide.html` |
| Task03 审核标准答案 | `whiteboard\work\week02-skills\task-03-invocation-samples-standard.html` |
| 测试计划 Skill | `whiteboard\work\week02-skills\my-test-plan-skill.md` |
| 失败日志 Skill | `whiteboard\work\week02-skills\my-failure-log-skill.md` |
| Context 模板 | `whiteboard\work\week01\test-task-template.md` |

用户要 HTML 链接时给 `file:///C:/Users/<USER>/code/...` 这种本地路径。
