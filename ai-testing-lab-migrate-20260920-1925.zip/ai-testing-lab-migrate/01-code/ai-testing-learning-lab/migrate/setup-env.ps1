﻿#Requires -Version 5.1
<#
.SYNOPSIS
  Recreate Python venv, install Playwright, verify restored tree, print next steps.

.EXAMPLE
  powershell -ExecutionPolicy Bypass -File .\setup-env.ps1
#>
[CmdletBinding()]
param(
    [string]$CodeRoot = "$env:USERPROFILE\code"
)

$ErrorActionPreference = "Stop"

function Test-Cmd {
    param([string]$Name)
    return [bool](Get-Command $Name -ErrorAction SilentlyContinue)
}

Write-Host "=== 1. Directory tree ==="
$required = @(
    "AI_TESTING_AGENT_ZONES.md",
    "ai-testing-learning-lab\docs\accounted-study-plan.html",
    "ai-testing-learning-lab\migrate\AGENT-MIGRATE-GUIDE.md",
    "ai-testing-lab-whiteboard\AGENT-WHITEBOARD.md",
    "ai-testing-lab-whiteboard\work\week02-skills\my-test-plan-skill.md",
    "ai-testing-lab-whiteboard\project\meridian-erp-starter\pom.xml",
    "ai-testing-lab-evaluator\AGENT-EVALUATOR.md",
    "playwright-api-lab\requirements.txt",
    "playwright-api-lab\meridian-autotest\conftest.py",
    "meridian-erp\pom.xml"
)
$missing = @()
foreach ($rel in $required) {
    $p = Join-Path $CodeRoot $rel
    if (Test-Path -LiteralPath $p) {
        Write-Host "  OK  $rel"
    } else {
        Write-Host "  MISS $rel"
        $missing += $rel
    }
}
if ($missing.Count -gt 0) {
    Write-Warning "Tree incomplete. Did restore-migrate.ps1 run? CodeRoot=$CodeRoot"
}

Write-Host ""
Write-Host "=== 2. Python + venv + Playwright ==="
if (-not (Test-Cmd "python")) {
    Write-Host "python not on PATH. Install: winget install Python.Python.3.12"
    throw "Python missing"
}
python --version
$lab = Join-Path $CodeRoot "playwright-api-lab"
$venv = Join-Path $lab ".venv"
$py = Join-Path $venv "Scripts\python.exe"
$req = Join-Path $lab "requirements.txt"
if (-not (Test-Path $py)) {
    Write-Host "Creating $venv"
    python -m venv $venv
}
& $py -m pip install --upgrade pip
& $py -m pip install -r $req
Write-Host "playwright install chromium (needed for UI; APIRequestContext also uses the Playwright package)"
& $py -m playwright install chromium

Write-Host ""
Write-Host "=== 3. Skills ==="
$skills = Join-Path $env:USERPROFILE ".cursor\skills-cursor"
if (Test-Path $skills) {
    $n = (Get-ChildItem $skills -Directory).Count
    Write-Host "  OK  $skills ($n skill folders)"
} else {
    Write-Warning "Skills folder missing. Re-run restore-migrate.ps1 without -SkipCursor"
}

Write-Host ""
Write-Host "=== 4. JDK / Maven (Meridian) ==="
$javaOk = Test-Cmd "java"
$mvnOk = Test-Cmd "mvn"
if ($javaOk) { java -version 2>&1 | Select-Object -First 1 } else {
    Write-Host "java MISSING -> winget install Microsoft.OpenJDK.21   then reopen terminal"
}
if ($mvnOk) { mvn -version 2>&1 | Select-Object -First 1 } else {
    Write-Host "mvn  MISSING -> winget install Apache.Maven   then reopen terminal"
}

Write-Host ""
Write-Host "=== 5. Cursor transcripts ==="
$slug = "c-Users-$($env:USERNAME)-code"
$tx = Join-Path $env:USERPROFILE ".cursor\projects\$slug\agent-transcripts"
if (Test-Path $tx) {
    $tn = (Get-ChildItem $tx -Directory -ErrorAction SilentlyContinue | Measure-Object).Count
    Write-Host "  OK  $tx ($tn chats)"
} else {
    Write-Warning "No transcripts at $tx (optional; Memories still need same Cursor account)"
}

$treeFile = Join-Path $CodeRoot "ai-testing-learning-lab\migrate\RESTORED-TREE.txt"
$listing = Get-ChildItem -LiteralPath $CodeRoot -Directory | ForEach-Object { $_.Name }
@(
    "codeRoot=$CodeRoot",
    "user=$env:USERNAME",
    "checked=$(Get-Date -Format o)",
    "dirs:",
    ($listing | ForEach-Object { "  $_" })
) | Set-Content -LiteralPath $treeFile -Encoding UTF8

Write-Host ""
Write-Host "=== DONE ==="
Write-Host "1. Install Cursor, sign in, paste migrate\user-rules-to-paste.md into User Rules"
Write-Host "2. Open folder: $CodeRoot"
Write-Host "3. New Agent chat: @ $($CodeRoot)\ai-testing-learning-lab\migrate\AGENT-MIGRATE-GUIDE.md"
Write-Host "4. Start ERP:  cd $CodeRoot\meridian-erp ; mvn spring-boot:run"
Write-Host "5. Smoke pytest after ERP is up:"
Write-Host "   cd $lab\meridian-autotest"
Write-Host "   $py -m pytest tests\api\test_login.py --tb=short"
if ($missing.Count -gt 0) { exit 1 }
exit 0
