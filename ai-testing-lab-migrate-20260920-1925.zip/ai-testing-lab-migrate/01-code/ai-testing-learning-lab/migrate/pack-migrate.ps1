﻿#Requires -Version 5.1
<#
.SYNOPSIS
  Pack AI Testing Lab repos + Cursor transcripts/skills into a zip (excludes .git/.venv/target).

.EXAMPLE
  powershell -ExecutionPolicy Bypass -File .\pack-migrate.ps1
  powershell -ExecutionPolicy Bypass -File .\pack-migrate.ps1 -IncludeSnapshotPack
#>
[CmdletBinding()]
param(
    [string]$CodeRoot = "C:\Users\hma\code",
    [string]$OutDir = "$env:USERPROFILE\Desktop",
    [switch]$IncludeSnapshotPack,
    [switch]$SkipZip
)

$ErrorActionPreference = "Stop"
$Stamp = Get-Date -Format "yyyyMMdd-HHmm"
$StageRoot = Join-Path $OutDir "ai-testing-lab-migrate-staging"
$BundleName = "ai-testing-lab-migrate"
$Stage = Join-Path $StageRoot $BundleName
$ZipPath = Join-Path $OutDir "ai-testing-lab-migrate-$Stamp.zip"

$ExcludeDirs = @(
    ".git", ".venv", "venv", "target", "__pycache__", ".pytest_cache",
    "node_modules", ".idea", "dist", "build", ".gradle"
)
if (-not $IncludeSnapshotPack) {
    $ExcludeDirs += "interview-sprint-complete-pack"
}

$Repos = @(
    "ai-testing-learning-lab",
    "ai-testing-lab-whiteboard",
    "playwright-api-lab",
    "meridian-erp",
    "ai-testing-lab-evaluator"
)
$LooseFiles = @("AI_TESTING_AGENT_ZONES.md")

$CursorProjects = @(
    "c-Users-hma-code",
    "c-Users-hma-code-playwright-api-lab",
    "c-Users-hma-code-ai-testing-lab-evaluator"
)

function Invoke-RobocopySafe {
    param(
        [Parameter(Mandatory)][string]$Source,
        [Parameter(Mandatory)][string]$Dest
    )
    if (-not (Test-Path -LiteralPath $Source)) {
        Write-Warning "SKIP missing: $Source"
        return
    }
    New-Item -ItemType Directory -Force -Path $Dest | Out-Null
    $xd = @()
    foreach ($d in $ExcludeDirs) { $xd += @("/XD", $d) }
    $args = @(
        $Source, $Dest, "/E", "/COPY:DAT", "/R:1", "/W:1", "/MT:8",
        "/NFL", "/NDL", "/NJH", "/NP"
    ) + $xd
    & robocopy @args | Out-Host
    $code = $LASTEXITCODE
    # robocopy: 0-7 = success-ish
    if ($code -ge 8) {
        throw "robocopy failed ($code): $Source -> $Dest"
    }
}

function Copy-FileSafe {
    param([string]$Source, [string]$Dest)
    if (-not (Test-Path -LiteralPath $Source)) {
        Write-Warning "SKIP missing file: $Source"
        return
    }
    New-Item -ItemType Directory -Force -Path (Split-Path $Dest) | Out-Null
    Copy-Item -LiteralPath $Source -Destination $Dest -Force
}

Write-Host "Staging: $Stage"
if (Test-Path $StageRoot) {
    Remove-Item -LiteralPath $StageRoot -Recurse -Force
}
New-Item -ItemType Directory -Force -Path $Stage | Out-Null

# 0) migrate docs + scripts (this folder)
$migrateSrc = $PSScriptRoot
$migrateDst = Join-Path $Stage "migrate-kit"
Invoke-RobocopySafe -Source $migrateSrc -Dest $migrateDst

# 1) code
$codeDst = Join-Path $Stage "01-code"
New-Item -ItemType Directory -Force -Path $codeDst | Out-Null
foreach ($repo in $Repos) {
    Write-Host "Copy repo $repo ..."
    Invoke-RobocopySafe -Source (Join-Path $CodeRoot $repo) -Dest (Join-Path $codeDst $repo)
}
foreach ($f in $LooseFiles) {
    Copy-FileSafe -Source (Join-Path $CodeRoot $f) -Dest (Join-Path $codeDst $f)
}

# 2) cursor
$curDst = Join-Path $Stage "02-cursor"
New-Item -ItemType Directory -Force -Path $curDst | Out-Null
$skills = Join-Path $env:USERPROFILE ".cursor\skills-cursor"
Invoke-RobocopySafe -Source $skills -Dest (Join-Path $curDst "skills-cursor")

$txRoot = Join-Path $curDst "agent-transcripts"
foreach ($slug in $CursorProjects) {
    $src = Join-Path $env:USERPROFILE ".cursor\projects\$slug\agent-transcripts"
    Invoke-RobocopySafe -Source $src -Dest (Join-Path $txRoot $slug)
}

Copy-FileSafe -Source (Join-Path $env:APPDATA "Cursor\User\settings.json") -Dest (Join-Path $curDst "User\settings.json")
$snip = Join-Path $env:APPDATA "Cursor\User\snippets"
if (Test-Path $snip) {
    Invoke-RobocopySafe -Source $snip -Dest (Join-Path $curDst "User\snippets")
}
Copy-FileSafe -Source (Join-Path $migrateSrc "user-rules-to-paste.md") -Dest (Join-Path $curDst "user-rules-to-paste.md")
Copy-FileSafe -Source (Join-Path $migrateSrc "AGENT-MIGRATE-GUIDE.md") -Dest (Join-Path $curDst "AGENT-MIGRATE-GUIDE.md")

# README at bundle root
Copy-FileSafe -Source (Join-Path $migrateSrc "README.md") -Dest (Join-Path $Stage "README.md")
Copy-FileSafe -Source (Join-Path $migrateSrc "migrate-checklist.md") -Dest (Join-Path $Stage "migrate-checklist.md")
Copy-FileSafe -Source (Join-Path $migrateSrc "AGENT-MIGRATE-GUIDE.md") -Dest (Join-Path $Stage "AGENT-MIGRATE-GUIDE.md")
Copy-FileSafe -Source (Join-Path $migrateSrc "restore-migrate.ps1") -Dest (Join-Path $Stage "restore-migrate.ps1")
Copy-FileSafe -Source (Join-Path $migrateSrc "setup-env.ps1") -Dest (Join-Path $Stage "setup-env.ps1")
Copy-FileSafe -Source (Join-Path $migrateSrc "pack-migrate.ps1") -Dest (Join-Path $Stage "pack-migrate.ps1")
Copy-FileSafe -Source (Join-Path $migrateSrc "restore-migrate.sh") -Dest (Join-Path $Stage "restore-migrate.sh")
Copy-FileSafe -Source (Join-Path $migrateSrc "setup-env.sh") -Dest (Join-Path $Stage "setup-env.sh")
Copy-FileSafe -Source (Join-Path $migrateSrc "run-meridian-smoke.sh") -Dest (Join-Path $Stage "run-meridian-smoke.sh")

# MANIFEST
$files = Get-ChildItem -LiteralPath $Stage -Recurse -File
$manifest = Join-Path $Stage "MANIFEST.txt"
$lines = @(
    "packed=$Stamp",
    "sourceUser=$env:USERNAME",
    "codeRoot=$CodeRoot",
    "fileCount=$($files.Count)",
    "excludeDirs=$($ExcludeDirs -join ',')",
    ""
)
$lines += ($files | ForEach-Object { $_.FullName.Substring($Stage.Length + 1) })
Set-Content -LiteralPath $manifest -Value $lines -Encoding UTF8

Write-Host ("FILE_COUNT={0}" -f $files.Count)

if ($SkipZip) {
    Write-Host "Skip zip. Staging left at $Stage"
    exit 0
}

if (Test-Path $ZipPath) { Remove-Item -LiteralPath $ZipPath -Force }
Write-Host "Zipping $ZipPath ..."
Push-Location $StageRoot
try {
    tar.exe -a -c -f $ZipPath $BundleName
    if ($LASTEXITCODE -ne 0) { throw "tar exit $LASTEXITCODE" }
}
finally {
    Pop-Location
}

Remove-Item -LiteralPath $StageRoot -Recurse -Force
Write-Host ""
Write-Host "ZIP=$ZipPath"
Write-Host "Copy this zip to the Mac, then run restore-migrate.sh"
