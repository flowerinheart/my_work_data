const milestones = [
  {
    id: "m1",
    exerciseAnchor: "m1-ai-编程基本模型",
    weeks: "第 1 周上半周",
    title: "建立 AI 编程基本模型",
    goal: "以 B 端财务系统为贯穿项目，理解 AI 编程不是让模型自由发挥，而是通过上下文、约束、反馈和验收标准管理输出。",
    learn: ["上下文工程", "提示词结构", "任务拆解", "验收标准", "代码审查提示"],
    exercises: [
      "让 AI 阅读一份 B 端财务系统需求，输出支付、入账、退款、对账、结算、发票模块地图。",
      "把“企业客户付款后入账”分别写成模糊提示和结构化提示，对比输出差异。",
      "设计财务需求任务模板：业务背景、交易状态、金额口径、幂等规则、异常处理、验收标准。"
    ],
    acceptance: [
      "能解释 prompt、context、constraint、acceptance criteria 的区别。",
      "能写出一份可复用的 AI 编程任务模板。",
      "能指出 AI 输出中的假设、遗漏和不可验证内容。"
    ],
    deliverables: ["B 端财务系统任务模板", "一次 AI 输出审查记录", "财务交易链路提示词检查清单"]
  },
  {
    id: "m2",
    exerciseAnchor: "m2-rules",
    weeks: "第 1 周下半周",
    title: "掌握 Rules：把工程约束固定下来",
    goal: "把反复出现的代码规范、测试要求、目录约定和安全边界写成规则，让 AI 每次工作时自动遵守。",
    learn: ["Cursor Rules", "项目约定", "文件作用域规则", "测试规范", "安全约束"],
    exercises: [
      "为支付、入账、退款 API 写测试规则：新增交易状态必须补单元测试和 API 测试。",
      "为财务后台页面写 UI 规则：账单、流水、退款单、对账差异必须有稳定选择器和错误态。",
      "故意让 AI 忽略金额精度、幂等键或重复回调，观察能否被规则纠正。"
    ],
    acceptance: [
      "能说明 rule 与普通 prompt 的区别。",
      "至少写出 3 条可执行、可检查的规则。",
      "规则不使用空泛词，例如“写高质量代码”，而是写可验收行为。"
    ],
    deliverables: ["财务交易测试规则草案", "财务后台可测试性规则草案", "规则有效性实验记录"]
  },
  {
    id: "m3",
    exerciseAnchor: "m3-skills",
    weeks: "第 2 周",
    title: "掌握 Skills：把重复流程封装成能力",
    goal: "把测试计划生成、失败分析、报告总结等重复流程沉淀成 Skill，使 AI 能按固定步骤执行。",
    learn: ["Skill 结构", "触发条件", "输入输出契约", "工作流封装", "复用与版本化"],
    exercises: [
      "设计一个“根据财务需求生成测试计划”的 Skill。",
      "设计一个“分析支付回调、入账、退款失败日志”的 Skill。",
      "把 Skill 的输出格式固定为 Markdown 表格或 JSON，字段包含交易号、账单号、流水号、金额和状态。"
    ],
    acceptance: [
      "能区分 Rule 管约束、Skill 管流程。",
      "Skill 包含触发场景、步骤、输入、输出、失败处理。",
      "同一类任务重复执行时，输出结构稳定。"
    ],
    deliverables: ["财务链路测试计划 Skill 设计", "交易失败日志分析 Skill 设计", "Skill 调用样例"]
  },
  {
    id: "m4",
    exerciseAnchor: "m4-单元测试",
    weeks: "第 3 周",
    skipped: true,
    title: "单元测试基本功",
    goal: "建立测试金字塔底层能力，先让核心业务逻辑可测、快速、稳定。",
    learn: ["测试金字塔", "pytest/Jest", "Mock", "Fixture", "覆盖率", "边界值"],
    exercises: [
      "实现订单应付金额、支付手续费、实收金额、可退金额计算函数，并补单元测试。",
      "用 AI 生成金额精度、零金额、超额退款、重复退款边界测试，再人工删除无价值测试。",
      "制造一个分转元、四舍五入或退款金额校验 bug，确认测试能失败并定位原因。"
    ],
    acceptance: [
      "单元测试能在 10 秒内完成。",
      "关键路径覆盖正常、异常、边界三类输入。",
      "失败信息能直接指向业务规则，而不是只显示空指针或 500。"
    ],
    deliverables: ["财务金额计算单元测试样例", "覆盖率报告", "AI 生成测试的人工审查记录"]
  },
  {
    id: "m5",
    exerciseAnchor: "m5-api-测试",
    weeks: "第 4 周（原 4+5 合并）",
    title: "API 自动化为主，关键 UI E2E 为辅",
    goal: "围绕接口契约建立可自动运行的 API 测试，覆盖鉴权、参数校验、状态码和数据一致性。",
    learn: ["OpenAPI", "契约测试", "HTTP 状态码", "测试数据隔离", "幂等性"],
    exercises: [
      "为账单创建、支付发起、支付回调、资金入账、退款申请、退款回调接口写 API 测试。",
      "用 OpenAPI 文档让 AI 生成支付和退款链路接口测试草案。",
      "实现测试前准备企业客户、账单、支付单、资金流水，测试后清理数据。"
    ],
    acceptance: [
      "API 测试能一键运行。",
      "测试之间没有顺序依赖。",
      "失败时报告包含请求、响应、断言和关联用例编号。"
    ],
    deliverables: ["财务交易 API 测试集合", "接口测试报告", "测试数据管理说明"]
  },
  {
    id: "m6",
    exerciseAnchor: "m6-ui-自动化",
    weeks: "第 5 周",
    skipped: true,
    title: "UI 自动化与可测试前端（已精简并入第 4 周）",
    goal: "掌握 Playwright/Cypress 等 UI 自动化方法，并理解前端代码如何为测试设计。",
    learn: ["Playwright", "可测试选择器", "页面对象模型", "等待策略", "截图与 Trace"],
    exercises: [
      "写一个财务后台端到端测试：登录、查看账单、发起退款、查看退款状态和资金流水。",
      "为账单列表、支付状态、退款弹窗、对账差异表添加稳定选择器。",
      "故意制造支付状态异步刷新问题，修复 flaky test。"
    ],
    acceptance: [
      "UI 测试不依赖随机 sleep。",
      "失败时能生成截图、trace 或视频。",
      "核心路径在本地连续运行 5 次无偶发失败。"
    ],
    deliverables: ["财务后台端到端测试脚本", "UI 测试失败证据", "前端可测试性清单"]
  },
  {
    id: "m7",
    exerciseAnchor: "m7-用例管理和自动化运行",
    weeks: "第 6 周",
    title: "测试用例管理和自动化运行",
    goal: "把测试用例从脚本中抽象出来，建立用例编号、标签、优先级、执行记录和调度入口。",
    learn: ["用例模型", "标签体系", "任务队列", "调度器", "执行历史", "状态机"],
    exercises: [
      "设计财务测试用例模型：case、suite、run、result，并给用例打上 payment、ledger、refund、reconcile 标签。",
      "实现一个命令行或 Web API，用来触发支付链路、退款链路、对账链路 suite。",
      "把执行结果写入数据库或 JSON 文件，保留交易号、账单号、流水号和失败原因。"
    ],
    acceptance: [
      "能按标签运行 smoke、regression、performance 三类测试。",
      "每次运行都有唯一 run id。",
      "执行结果包含开始时间、结束时间、耗时、状态和失败原因。"
    ],
    deliverables: ["财务链路测试用例管理原型", "自动化运行入口", "执行历史样例数据"]
  },
  {
    id: "m8",
    exerciseAnchor: "m8-性能测试",
    weeks: "第 7 周",
    skipped: true,
    title: "性能测试与基线管理",
    goal: "建立性能测试入门能力，重点关注 P95 latency、吞吐、错误率和资源使用趋势。",
    learn: ["k6/Locust", "P95 latency", "吞吐量", "容量基线", "瓶颈分析", "回归阈值"],
    exercises: [
      "为支付回调、资金入账、账务流水查询 API 编写 k6 或 Locust 性能脚本。",
      "分别跑 smoke、load、stress 三种场景，区分支付峰值和账务查询峰值。",
      "让 AI 根据 P95、错误率、数据库耗时生成瓶颈假设，再用指标验证。"
    ],
    acceptance: [
      "报告至少包含 P50/P95/P99、RPS、错误率。",
      "有明确通过阈值，例如 P95 < 300ms。",
      "能解释性能失败是服务端、数据库、网络还是测试脚本导致。"
    ],
    deliverables: ["财务核心接口性能测试脚本", "性能基线报告", "性能回归阈值配置"]
  },
  {
    id: "m9",
    exerciseAnchor: "m9-报告和-bug-追踪",
    weeks: "第 8 周",
    skipped: true,
    title: "测试报告和 Bug 追踪闭环",
    goal: "把执行结果变成可消费的报告，并把失败自动转换成缺陷草稿或 issue。",
    learn: ["Allure/HTML 报告", "趋势图", "失败聚类", "Issue 模板", "缺陷生命周期"],
    exercises: [
      "生成一份财务链路 HTML 测试报告，包含支付、入账、退款、对账各模块通过率和失败详情。",
      "为失败用例生成 bug 标题、复现步骤、期望结果、实际结果，必须包含交易号和账务证据。",
      "模拟 issue 状态流转：New -> Confirmed -> Fixed -> Finance Verified。"
    ],
    acceptance: [
      "报告能被非测试人员读懂。",
      "bug 草稿包含足够复现信息。",
      "同一失败不重复创建多个缺陷。"
    ],
    deliverables: ["财务链路 HTML 测试报告", "Bug 模板", "缺陷闭环演示记录"]
  },
  {
    id: "m10",
    exerciseAnchor: "m10-最终集成",
    weeks: "第 9 周",
    skipped: true,
    title: "集成最终原型",
    goal: "把前面的能力合成一个最小可用平台，围绕 B 端财务系统管理用例、触发运行、展示报告并辅助创建缺陷。",
    learn: ["系统集成", "模块边界", "CI/CD", "可观测性", "AI 辅助质量工程"],
    exercises: [
      "实现一个简单 Web 页面展示支付、入账、退款、对账测试运行历史。",
      "接入一个 CI 任务或本地定时任务自动跑财务核心链路回归测试。",
      "用 AI 对失败报告生成修复建议，并要求引用交易日志、账务流水、断言或指标。"
    ],
    acceptance: [
      "从页面或命令触发测试后，能看到执行结果。",
      "支付、入账、退款、对账链路至少各有一个可运行样例。",
      "AI 生成的建议必须引用日志、断言或指标，不接受无证据猜测。"
    ],
    deliverables: ["B 端财务自动化测试平台原型", "最终演示脚本", "复盘报告和下一阶段 backlog"]
  }
];

const list = document.querySelector("#milestone-list");

function renderItems(items) {
  return `<ul>${items.map((item) => `<li>${item}</li>`).join("")}</ul>`;
}

list.innerHTML = milestones
  .map(
    (milestone) => `
      <article class="milestone${milestone.skipped ? " skipped" : ""}">
        <header>
          <p class="eyebrow">${milestone.weeks}</p>
          <h3>${milestone.title}${milestone.skipped ? ' <span class="status-skip">跳过 · 不需要做</span>' : ""}</h3>
          <p>${milestone.goal}${milestone.skipped ? " 本里程碑已标记跳过，到达该周时直接跳过。" : ""}</p>
          <div class="tag-row">
            ${milestone.learn.map((item) => `<span class="tag">${item}</span>`).join("")}
          </div>
        </header>
        <div class="milestone-body">
          <section>
            <h4>练习题</h4>
            ${renderItems(milestone.exercises)}
          </section>
          <section>
            <h4>验收标准</h4>
            ${renderItems(milestone.acceptance)}
          </section>
          <section>
            <h4>阶段成果</h4>
            ${renderItems(milestone.deliverables)}
          </section>
          <section>
            <h4>学到的知识</h4>
            ${renderItems(milestone.learn)}
          </section>
        </div>
        <div class="milestone-actions">
          <a href="../exercises/milestone-exercises.md#${milestone.exerciseAnchor}">查看对应练习说明</a>
        </div>
      </article>
    `
  )
  .join("");
