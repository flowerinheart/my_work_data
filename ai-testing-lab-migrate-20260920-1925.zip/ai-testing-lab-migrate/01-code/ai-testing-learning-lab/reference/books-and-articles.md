# Books and Articles

## 书籍

- 《测试驱动开发》Kent Beck
- 《重构》Martin Fowler
- 《持续交付》Jez Humble, David Farley
- 《Google 软件测试之道》
- 《代码整洁之道》Robert C. Martin
- 《高性能 MySQL》
- 《Site Reliability Engineering》

## 官方文档

- Cursor Docs: https://docs.cursor.com/
- pytest: https://docs.pytest.org/
- Playwright: https://playwright.dev/
- k6: https://k6.io/docs/
- Locust: https://docs.locust.io/
- Allure: https://docs.qameta.io/allure/
- GitHub Actions: https://docs.github.com/actions
- OpenAPI: https://spec.openapis.org/oas/latest.html

## 中文文章搜索关键词

不要只收藏文章。每个关键词都要落到一个练习。

- Cursor Rules 最佳实践
- Cursor Skills 使用方法
- AI 编程 上下文工程
- AI 生成单元测试
- pytest fixture 参数化 mock
- Playwright trace viewer
- k6 P95 latency 性能测试
- Allure 报告 CI 集成
- 测试用例管理 平台设计
- 缺陷生命周期 Bug 追踪

## 阅读验收

读完一份资料后必须产出至少一个结果：

- 一条 rule
- 一个 skill 流程
- 一个测试样例
- 一个报告模板
- 一个设计决策记录
