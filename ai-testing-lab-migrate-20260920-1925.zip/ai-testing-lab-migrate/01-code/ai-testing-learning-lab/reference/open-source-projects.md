# Open Source Projects to Study

## 测试框架

- pytest: https://github.com/pytest-dev/pytest
  - 学习点：fixture、插件机制、断言重写、测试发现。
- Vitest: https://github.com/vitest-dev/vitest
  - 学习点：前端单元测试、watch 模式、覆盖率。

## UI 自动化

- Playwright: https://github.com/microsoft/playwright
  - 学习点：浏览器自动化、trace、reporter、隔离上下文。
- Cypress: https://github.com/cypress-io/cypress
  - 学习点：端到端测试体验、命令链、调试能力。

## 性能测试

- k6: https://github.com/grafana/k6
  - 学习点：性能场景、阈值、指标输出。
- Locust: https://github.com/locustio/locust
  - 学习点：Python 用户行为建模、分布式压测。

## 报告和测试管理

- Allure2: https://github.com/allure-framework/allure2
  - 学习点：测试结果模型、HTML 报告、附件和历史趋势。
- Kiwi TCMS: https://github.com/kiwitcms/Kiwi
  - 学习点：测试用例管理、计划、执行记录。
- TestLink: https://github.com/TestLinkOpenSourceTRMS/testlink-code
  - 学习点：传统测试管理系统的信息架构。

## 缺陷和可观测性

- Sentry: https://github.com/getsentry/sentry
  - 学习点：事件聚合、错误归因、issue 生命周期。
- GlitchTip: https://gitlab.com/glitchtip/glitchtip
  - 学习点：轻量错误追踪系统。

## AI 编程参考项目

- aider: https://github.com/Aider-AI/aider
  - 学习点：AI 辅助代码修改、上下文选择、diff 工作流。
- OpenHands: https://github.com/All-Hands-AI/OpenHands
  - 学习点：Agent 执行任务、工具调用、沙箱。

## 拆解方法

每次只拆一个问题：

- 这个项目如何组织测试？
- 失败结果如何表示？
- 报告如何生成？
- 配置如何传递？
- 任务如何被调度？
- 哪些模块适合用 AI 生成，哪些必须人工审查？
