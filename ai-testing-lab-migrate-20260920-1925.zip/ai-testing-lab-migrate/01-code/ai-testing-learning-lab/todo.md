# todo.md

## Workflow

Analyze -> Plan -> Code -> Benchmark -> Refine

## Current Track

- [x] Create project scaffold
- [ ] Review the learning roadmap in `docs/index.html`
- [ ] Complete milestone 1 exercises
- [ ] Create first Cursor rule for testing standards
- [ ] Create first reusable AI skill for generating test plans
- [ ] Build a minimal backend service with unit tests
- [ ] Add API test automation
- [ ] Add performance smoke benchmark
- [ ] Generate a test report
- [ ] Connect bug tracking workflow

## Local Notes

Use this file as the running plan. Every milestone should end with:

- what was built
- what was measured
- what failed
- what changed in the next iteration
