# AI Testing Learning Lab

这个项目用于系统学习 AI 编程，并逐步落地一套自动化测试系统。

目标系统包含：

- 单元测试与测试金字塔实践
- API/UI 自动化测试
- 性能测试与容量基线
- 测试用例管理
- 自动化调度运行
- 测试报告生成
- Bug 追踪与缺陷闭环
- AI Rules、Skills、提示词、上下文工程和代码审查流程

## 如何查看学习计划

直接打开：

```text
docs/index.html
```

本轮 Playwright API + 九周第 4 周合并课表的**分类完整快照**（学习计划、白板周任务、prompt/rule/skill、每日练习、pytest 工程、Meridian 摘录）：

```text
interview-sprint-complete-pack/README.md
```

绝对路径：`C:\Users\hma\code\ai-testing-learning-lab\interview-sprint-complete-pack`

辅助页面：

- `docs/resources.html`：参考资料、书籍、中文文章、开源项目
- `docs/glossary.html`：关键概念术语表
- `exercises/milestone-exercises.md`：每个里程碑的练习题
- `reference/books-and-articles.md`：扩展阅读
- `reference/open-source-projects.md`：可拆解学习的开源项目

## 建议节奏

默认按 9 周脱产强化节奏推进。每周只交付一个明确成果，不把学习停留在概念层。

每个 milestone 都要产出可检查的资产，例如规则文件、测试样例、CI 配置、性能报告、缺陷流转记录或演示系统。

## 最终交付目标

完成后应能独立搭建一套测试自动化平台原型：

```text
Web UI
  -> Test Case Management
  -> Test Runner Service
  -> Unit/API/UI/Performance Jobs
  -> Report Generator
  -> Bug Tracker Integration
  -> AI Assisted Review and Test Generation
```
