"""Snapshot pack for the Playwright API + 9-week interview sprint.

Copies (does not move) files from the original repos into a classified folder.
Excludes: .venv, .git, pytest cache, pycache, full Meridian ERP, whiteboard starter app.
"""

from __future__ import annotations

import shutil
from pathlib import Path

CODE = Path(r"C:\Users\hma\code")
LAB9 = CODE / "ai-testing-learning-lab"
PACK = LAB9 / "interview-sprint-complete-pack"
WHITEBOARD = CODE / "ai-testing-lab-whiteboard"
PLAY = CODE / "playwright-api-lab"
ERP = CODE / "meridian-erp"

SKIP_DIR_NAMES = {
    ".git",
    ".venv",
    "venv",
    "__pycache__",
    ".pytest_cache",
    "node_modules",
    "interview-sprint-complete-pack",
}


def should_skip_dir(path: Path) -> bool:
    return path.name in SKIP_DIR_NAMES


def copy_tree(src: Path, dst: Path) -> None:
    if not src.exists():
        raise FileNotFoundError(src)
    dst.parent.mkdir(parents=True, exist_ok=True)
    if src.is_file():
        shutil.copy2(src, dst)
        return
    shutil.copytree(
        src,
        dst,
        dirs_exist_ok=True,
        ignore=shutil.ignore_patterns(
            ".git",
            ".venv",
            "venv",
            "__pycache__",
            ".pytest_cache",
            "node_modules",
            "interview-sprint-complete-pack",
        ),
    )


def copy_file(src: Path, dst: Path) -> None:
    if not src.exists():
        print("SKIP missing:", src)
        return
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)


def wipe_pack() -> None:
    if PACK.exists():
        shutil.rmtree(PACK)
    PACK.mkdir(parents=True)


def collect_files(root: Path) -> list[Path]:
    files: list[Path] = []
    skip = SKIP_DIR_NAMES - {"interview-sprint-complete-pack"}
    for p in root.rglob("*"):
        if not p.is_file():
            continue
        rel_parts = p.relative_to(root).parts
        if any(part in skip for part in rel_parts):
            continue
        files.append(p)
    return sorted(files)


def main() -> None:
    wipe_pack()

    # 01 study plans (9-week + 8-day calendar)
    plans = PACK / "01-study-plans"
    for name in [
        "index.html",
        "nine-week-plan.html",
        "playwright-api-knowledge-and-8h-plan.html",
        "sprint-week04-api-first.html",
        "meridian-plan-api-first-week4-merged.html",
        "meridian-study-plan-interview-api-first.html",
        "accounted-study-plan.html",
        "accounted-business-summary.html",
        "career-direction-ai-testing.html",
        "qa-version-lifecycle.html",
        "prompt-context-constraint-ac.html",
        "gemini-pytest-fixture-conftest.html",
        "glossary.html",
        "resources.html",
    ]:
        copy_file(LAB9 / "docs" / name, plans / name)
    copy_tree(LAB9 / "docs" / "assets", plans / "assets")
    copy_file(LAB9 / "todo.md", plans / "nine-week-todo.md")
    copy_file(LAB9 / "README.md", plans / "nine-week-README.md")

    # 02 weekly whiteboard (all week folders + materials)
    weekly = PACK / "02-weekly-whiteboard"
    copy_tree(WHITEBOARD / "work", weekly / "work")
    copy_tree(WHITEBOARD / "materials", weekly / "materials")
    copy_file(WHITEBOARD / "README.md", weekly / "whiteboard-README.md")
    copy_file(WHITEBOARD / "AGENT-WHITEBOARD.md", weekly / "AGENT-WHITEBOARD.md")

    # 03 prompts / rules / skills (flat by type, copies of the files this sprint patched)
    prs = PACK / "03-prompts-rules-skills"
    prompt_src = WHITEBOARD / "work" / "week01"
    for name in [
        "prompt-context-constraint-ac.md",
        "prompt-checklist.md",
        "test-task-template.md",
    ]:
        copy_file(prompt_src / name, prs / "prompts" / name)
    copy_file(
        LAB9 / "docs" / "prompt-context-constraint-ac.html",
        prs / "prompts" / "prompt-context-constraint-ac.html",
    )

    rules_src = WHITEBOARD / "work" / "week01b-rules"
    for name in [
        "testing-rules.md",
        "data-and-db-rules.md",
        "ui-testability-rules.md",
        "http-transport-interview-addendum.md",
        "http-transport-interview-addendum.html",
        "rule-effectiveness-review.md",
        "README.md",
    ]:
        copy_file(rules_src / name, prs / "rules" / name)
    copy_file(
        LAB9 / "templates" / "testing-rules-template.md",
        prs / "rules" / "testing-rules-template.md",
    )

    skills_src = WHITEBOARD / "work" / "week02-skills"
    for name in [
        "my-test-plan-skill.md",
        "my-failure-log-skill.md",
        "skill-template.md",
        "task-01-test-plan-skill.md",
        "task-02-failure-log-skill.md",
        "task-03-invocation-samples.md",
        "task-03-invocation-samples-standard.md",
        "task-03-invocation-samples-standard.html",
        "task-03-invocation-samples.html",
        "task-03-audit-guide.html",
        "self-review.md",
        "todo.md",
        "README.md",
    ]:
        copy_file(skills_src / name, prs / "skills" / name)
    copy_file(
        LAB9 / "templates" / "test-plan-skill-template.md",
        prs / "skills" / "test-plan-skill-template.md",
    )

    # zone / agent routing note used across whiteboard + tutorial chats
    copy_file(CODE / "AI_TESTING_AGENT_ZONES.md", prs / "meta" / "AI_TESTING_AGENT_ZONES.md")

    # 04 knowledge notes + HTML guides produced in this conversation
    knowledge = PACK / "04-knowledge-notes"
    copy_tree(PLAY / "notes", knowledge / "daily-notes")
    for src, dst_name in [
        (PLAY / "day03" / "redirect-302-explained.html", "day03-redirect-302-explained.html"),
        (PLAY / "day05" / "json-write-then-read-explained.html", "day05-json-write-then-read-explained.html"),
        (PLAY / "day07" / "idempotency-concurrency-explained.html", "day07-idempotency-concurrency-explained.html"),
        (PLAY / "day04" / "auth_client-source.html", "day04-auth_client-source.html"),
        (PLAY / "day04" / "conftest-source.html", "day04-conftest-source.html"),
        (PLAY / "day04" / "test_login-source.html", "day04-test_login-source.html"),
        (LAB9 / "docs" / "gemini-pytest-fixture-conftest.html", "day04-gemini-pytest-fixture-conftest.html"),
        (WHITEBOARD / "work" / "week01b-rules" / "http-transport-interview-addendum.html", "http-transport-interview-addendum.html"),
    ]:
        copy_file(src, knowledge / "html-guides" / dst_name)

    # 05 playwright daily labs (Days 1-8 materials; 6/8 may be empty until those days)
    daily = PACK / "05-playwright-daily-labs"
    copy_file(PLAY / "AGENT.md", daily / "AGENT.md")
    copy_file(PLAY / "README.md", daily / "README.md")
    copy_file(PLAY / "requirements.txt", daily / "requirements.txt")
    copy_file(PLAY / ".gitignore", daily / ".gitignore")
    for day in ["day01", "day02", "day03", "day04", "day05", "day06", "day07", "day08"]:
        src = PLAY / day
        if src.exists():
            copy_tree(src, daily / day)

    # 06 pytest project: student code + corrected comments (meridian-autotest)
    copy_tree(PLAY / "meridian-autotest", PACK / "06-pytest-project" / "meridian-autotest")

    # 07 SUT excerpts actually opened/cited this sprint (not the whole ERP)
    sut = PACK / "07-sut-meridian-excerpts"
    excerpts = [
        ERP / "src/main/resources/templates/auth/login.html",
        ERP / "src/main/resources/templates/accounting/invoices/form.html",
        ERP / "src/main/resources/templates/accounting/invoices/detail.html",
        ERP / "src/main/resources/templates/accounting/invoices/list.html",
        ERP / "src/main/java/com/erp/accounting/controller/InvoiceController.java",
        ERP / "src/main/java/com/erp/accounting/service/InvoiceForm.java",
        ERP / "src/main/java/com/erp/accounting/service/InvoiceService.java",
        ERP / "src/main/java/com/erp/accounting/service/AccountingDataInitializer.java",
        ERP / "src/main/java/com/erp/accounting/entity/Invoice.java",
        ERP / "src/main/java/com/erp/accounting/entity/InvoiceItem.java",
        ERP / "src/main/java/com/erp/accounting/repository/InvoiceRepository.java",
        ERP / "src/main/java/com/erp/accounting/enums/InvoiceStatus.java",
        ERP / "src/main/java/com/erp/common/enums/PermissionType.java",
        ERP / "src/main/java/com/erp/core/service/SecurityDataInitializer.java",
    ]
    for src in excerpts:
        rel = src.relative_to(ERP)
        copy_file(src, sut / rel)

    # 08 remainder of the 9-week lab (templates / exercises / reference)
    orig = PACK / "08-nine-week-lab-rest"
    copy_tree(LAB9 / "templates", orig / "templates")
    copy_tree(LAB9 / "exercises", orig / "exercises")
    copy_tree(LAB9 / "reference", orig / "reference")

    files = collect_files(PACK)
    index_lines = [f"{p.relative_to(PACK).as_posix()}" for p in files]
    (PACK / "FILE-INDEX.txt").write_text(
        "\n".join(index_lines) + "\n",
        encoding="utf-8",
    )

    readme = """# 九周学习 + 白板 + Playwright 完整打包（快照）

路径：

```text
C:\\Users\\hma\\code\\ai-testing-learning-lab\\interview-sprint-complete-pack
```

这是**复制快照**，不是把原工程搬走。日常继续在原仓库改。

刷新快照：

```powershell
python C:\\Users\\hma\\code\\ai-testing-learning-lab\\_build_interview_sprint_pack.py
```

## 分类目录

| 文件夹 | 内容 |
|---|---|
| `01-study-plans/` | 九周总表、面试课表、Week4 sprint、业务摘要等 HTML/MD |
| `02-weekly-whiteboard/` | 白板 `work/week01`～`week04` + `materials/`（含 UI/DB/Skill/Playwright 指南） |
| `03-prompts-rules-skills/` | Prompt / Rule / Skill 按类型再拆；含 Task03 样例与标准答案 |
| `04-knowledge-notes/` | day01～day07 笔记 + 302/写后读/幂等/登录原文 HTML |
| `05-playwright-daily-labs/` | Playwright 日练 TODAY.md / 练习 py / 讲解 HTML |
| `06-pytest-project/` | `meridian-autotest/` 项目代码 |
| `07-sut-meridian-excerpts/` | 会话用到的 Meridian 源码摘录 |
| `08-nine-week-lab-rest/` | templates / exercises / reference |
| `FILE-INDEX.txt` | 本包全部文件清单 |

## 原仓库

| 用途 | 原路径 |
|---|---|
| 九周学习计划 | `C:\\Users\\hma\\code\\ai-testing-learning-lab` |
| 白板周任务 / prompt / rule / skill | `C:\\Users\\hma\\code\\ai-testing-lab-whiteboard` |
| Playwright 实验室 | `C:\\Users\\hma\\code\\playwright-api-lab` |
| 被测 Meridian ERP | `C:\\Users\\hma\\code\\meridian-erp` |

## 故意没打进来的

- `playwright-api-lab\\.venv`
- `.pytest_cache` / `__pycache__` / `.git`
- 完整 `meridian-erp`（只收摘录）
- 白板 `project/meridian-erp-starter` 整仓
"""
    (PACK / "README.md").write_text(readme, encoding="utf-8")

    # keep rebuild helper inside the pack
    tools = PACK / "tools"
    tools.mkdir(parents=True, exist_ok=True)
    shutil.copy2(LAB9 / "_build_interview_sprint_pack.py", tools / "rebuild-pack.py")

    print("PACK", PACK)
    print("FILE_COUNT", len(files))


if __name__ == "__main__":
    main()
