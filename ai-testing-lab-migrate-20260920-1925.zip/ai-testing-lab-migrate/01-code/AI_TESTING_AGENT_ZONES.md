# AI Testing Agent Zones

你现在有两个分区。

## 1. 白板练习区

路径：

`C:\Users\hma\code\ai-testing-lab-whiteboard`

用途：

- 从零开始学习九周 AI 测试计划。
- 不看标准答案。
- 不看原始单元测试。
- 不看原始自动化脚本。
- 不看验证区 rubrics。

白板区 Agent 规则：

`C:\Users\hma\code\ai-testing-lab-whiteboard\AGENT-WHITEBOARD.md`

练习成果放这里：

`C:\Users\hma\code\ai-testing-lab-whiteboard\work`

## 2. 验证 / 标准答案区

路径：

`C:\Users\hma\code\ai-testing-lab-evaluator`

用途：

- 批改你的白板练习成果。
- 对照九周计划、Meridian ERP 项目、测试流程验证、业务流程验证。
- 给出通过 / 需修改 / 不通过。
- 不直接把完整答案倒回白板区。

验证区 Agent 规则：

`C:\Users\hma\code\ai-testing-lab-evaluator\AGENT-EVALUATOR.md`

评分规则：

`C:\Users\hma\code\ai-testing-lab-evaluator\rubrics\week-01-02-04-06-rubric.md`

## 正确切换方式

### 进入白板区

1. 在 Cursor 里打开文件夹：

   `C:\Users\hma\code\ai-testing-lab-whiteboard`

2. 开一个全新的 Chat，不要复用当前聊天。

3. 对白板 Agent 说：

   “读取 `AGENT-WHITEBOARD.md`，我要开始九周 AI 测试计划第 1 周练习。”

4. 从任务卡开始：

   `materials/week-plan-task-card.md`

### 进入验证区

1. 在 Cursor 里打开文件夹：

   `C:\Users\hma\code\ai-testing-lab-evaluator`

2. 可以回到当前这个聊天，也可以开新 Chat。

3. 对验证 Agent 说：

   “读取 `AGENT-EVALUATOR.md`，请验证白板区 `work/week01` 的学习成果。”

4. 验证 Agent 会读取：

   `C:\Users\hma\code\ai-testing-lab-whiteboard\work\week01`

   然后按 rubrics 批改。

## 重要隔离规则

- 白板区不能打开验证区。
- 白板区不能读取当前这个聊天记录。
- 白板区不能读取 evaluator/oracle/rubrics。
- 验证区可以读取白板区成果。
- 当前聊天已经知道完整计划，所以当前聊天只能当验证区，不适合当白板区。

## 学习顺序

先只做这四个阶段：

1. 第 1 周：测试模板。
2. 第 2 周：测试计划。
3. 第 4 周：API 测试。
4. 第 6 周：测试用例管理和自动化运行。

每一阶段流程：

1. 进白板区。
2. 自己做练习。
3. 把结果写到 `work/weekXX`。
4. 进验证区。
5. 让验证 Agent 批改。
6. 按反馈回白板区修改。
