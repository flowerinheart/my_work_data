"""练习 B：302 和 Location（标准答案，回头对照 HTML 讲解看）。

运行（在仓库根目录）：
    $env:PYTHONPATH = "C:\\Users\\hma\\code\\playwright-api-lab\\day03"
    .\\.venv\\Scripts\\python.exe day03\\practice_b_redirect_302.py
"""

from playwright.sync_api import sync_playwright

from assert_http import assert_status

# REDIRECT 不是 Playwright 内置变量，只是我们自己起的常量：
# 请求 httpbin 的「请 302 跳到 /get」这个路径。
REDIRECT = "/redirect-to?url=/get&status_code=302"


def main():
    with sync_playwright() as p:
        api = p.request.new_context(
            base_url="https://httpbin.org",
            ignore_https_errors=True,
        )

        print("=== GET 不跟随 ===")
        r_get_stop = api.get(REDIRECT, max_redirects=0)
        print("GET stop status =", r_get_stop.status)
        print("GET stop url =", r_get_stop.url)
        print("GET stop location =", r_get_stop.headers.get("location"))
        assert_status(r_get_stop, 302, "重定向 GET")

        print("=== GET 跟随（默认）===")
        r_get_follow = api.get(REDIRECT)
        print("GET follow status =", r_get_follow.status)
        print("GET follow url =", r_get_follow.url)

        print("=== POST 不跟随 ===")
        r_post_stop = api.post(
            REDIRECT,
            form={"title": "INV"},
            max_redirects=0,
        )
        print("POST stop status =", r_post_stop.status)
        print("POST stop url =", r_post_stop.url)
        print("POST stop location =", r_post_stop.headers.get("location"))
        assert_status(r_post_stop, 302, "重定向 POST")

        api.dispose()


if __name__ == "__main__":
    main()
