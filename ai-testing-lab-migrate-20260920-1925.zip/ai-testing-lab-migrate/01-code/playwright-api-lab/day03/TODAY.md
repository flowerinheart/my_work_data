# 第 3 天：APIResponse、200 / 302 / 403、Location

目标结束时你能自己说清：

1. `response.ok` 只表示 200–299，**不能**用来断言 302、403。
2. 默认会跟随重定向：你看到的可能是最终 200 和最终 url，而不是 302。
3. `max_redirects=0` 时才能读到 302 和 `Location`。
4. GET 和 POST 都要会断言状态码；失败信息里要有 url 和 body 摘要。

练习站仍是 httpbin，`ignore_https_errors=True`。不要 launch 浏览器，不要打 Meridian。

## 步骤

- [ ] 1. 读完「ok vs status」说明
- [ ] 2. 完成 `assert_http.py` 里的 `assert_status`
- [ ] 3. 完成 `practice_a_status_200.py`（GET + POST）
- [ ] 4. 完成 `practice_b_redirect_302.py`（不跟随 vs 跟随）
- [ ] 5. 完成 `practice_c_403.py`（GET + POST，禁止 assert ok）
- [ ] 6. 记 `notes/day03.md`
