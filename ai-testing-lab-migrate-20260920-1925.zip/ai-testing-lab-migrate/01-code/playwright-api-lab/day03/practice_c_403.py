"""练习 C：403。resp.ok 为 False，但要用 status == 403，禁止 assert resp.ok。

GET  /status/403
POST /status/403  form={"title": "INV"}

先故意体会：assert r_get.ok 在 403 时会失败，但报错信息没有「期望 403」。
再用 assert_status(..., 403, "无权限 GET")。

运行：
    python day03/practice_c_403.py
"""

from playwright.sync_api import sync_playwright

from assert_http import assert_status


def main():
    with sync_playwright() as p:
        api = p.request.new_context(
            base_url="https://httpbin.org",
            ignore_https_errors=True,
        )

        r_get = api.get("/status/403")
        print("GET ok =", r_get.ok, "status =", r_get.status)
        # TODO: assert_status(r_get, 403, "无权限 GET")
        assert_status(r_get,403, "无权限 GET")

        # TODO: POST /status/403
        r_post = api.post("/status/403",form={"title": "INV"})
        # 打印 ok、status，assert_status(..., 403, "无权限 POST")
        print("POST ok =", r_post.ok, "status =", r_post.status)
        assert_status(r_post, 403, "无权限 POST")
        api.dispose()


if __name__ == "__main__":
    main()
