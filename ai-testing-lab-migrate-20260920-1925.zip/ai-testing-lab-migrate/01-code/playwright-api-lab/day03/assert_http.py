"""失败时要把 scene、期望码、实际码、url、body 前 200 字打出来。"""


def assert_status(resp, expected: int, scene: str) -> None:
    # TODO: 取出 actual = resp.status
    actual = resp.status
    url = resp.url

    # TODO: body 用 resp.text()[:200]；若 text 失败就用 "<no body>"    
    try:
        body = resp.text()[:200]
    except Exception:
        body = "<no body>"


    # TODO: actual != expected 时 assert False 或 raise AssertionError
    assert actual == expected, f"expected{expected}, actual{actual}, scene{scene}，url{url},body={body!r}"

   #if actual != expected:
       #raise AssertionError(f"expected{expected}, actual{actual}, scene{scene}，url{url},body={body!r}")
    
