"""练习 A：200 必须写成 status == 200，不要写 assert response.ok。

GET  /status/200
POST /status/200  （body 用 form={"title": "INV"}）

运行：
    python day03/practice_a_status_200.py
"""

from playwright.sync_api import sync_playwright

from assert_http import assert_status


def main():
    with sync_playwright() as p:
        api = p.request.new_context(
            base_url="https://httpbin.org",
            ignore_https_errors=True,
        )

        r_get = api.get("/status/200")
        print("GET ok =", r_get.ok, "status =", r_get.status)
        # TODO: assert_status(r_get, 200, "健康检查 GET")
        assert_status(r_get, 200, "健康检查 GET")
        
        #assert r_get.status == 200,  "健康检查 GET"
        #expect(r_get).to_have_status(200)

        # TODO: POST /status/200 ，form={"title": "INV"}
        # 打印 ok 和 status，再 assert_status(..., 200, "健康检查 POST")

        r_post = api.post("/status/200", form={"title": "INV"})
        print("Post ok",r_post.ok, "post status", r_post.status)
        assert_status(r_post, 200, "健康检查 POST")

        #assert r_post.status ==200, "健康检查 POST"
       #expect(r_post).to_have_status(200)

        api.dispose()


if __name__ == "__main__":
    main()
