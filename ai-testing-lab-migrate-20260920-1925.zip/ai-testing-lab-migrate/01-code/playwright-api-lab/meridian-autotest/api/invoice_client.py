"""发票写后读。测试只看见 JSON 语义，不要断言 Location。

对外：
  create(...) -> {"code": 0, "data": {"id", "invoiceNumber", "status"}}
  get_by_id(api, invoice_id) -> 同样形状，id 必须等于入参

内部可以：GET /accounting/invoices/new 取 CSRF → POST /save（form=）→ 再 GET 详情。
表单字段名对齐 InvoiceForm / 新建页 input name。
"""

from api.auth_client import _extract_csrf


def create(api, fields: dict) -> dict:
    # TODO: GET /accounting/invoices/new ，取 CSRF（可复用 _extract_csrf）
    # TODO: POST /accounting/invoices/save ，form= 对齐页面 name，id 为空
    # TODO: 从结果里取出新票 id、发票号、DRAFT（适配层自己消化 302/HTML）
    # TODO: 返回 {"code": 0, "data": {"id": ..., "invoiceNumber": ..., "status": "DRAFT"}}
    raise NotImplementedError("create")


def get_by_id(api, invoice_id: str) -> dict:
    # TODO: 入参必须是 create 返回的 data.id，禁止手填
    # TODO: GET /accounting/invoices/{id}
    # TODO: 返回 {"code": 0, "data": {"id": invoice_id, "invoiceNumber": ..., "status": ...}}
    raise NotImplementedError("get_by_id")
