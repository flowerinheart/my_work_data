"""登录：表单 POST + Session Cookie，不是 Bearer Token。

登录页：meridian-erp/src/main/resources/templates/auth/login.html
- GET  /login
- POST /login
- 字段名：username、password（email 填在 username 上）
- th:action 会往表单里塞 CSRF hidden。先 GET 页面再 POST，不要猜 JSON 登录接口。

今天不要 chromium.launch，不要写发票 save。
"""

import re


def _extract_csrf(html: str) -> str:
    # TODO: 从登录页 HTML 取出 CSRF token。
    # 常见：hidden input name="_csrf" ，或 name 等于 _csrf.parameterName。
    match = re.search(r'name="_csrf"\s+value="([^"]+)"', html)
    if match is None:
        match = re.search(r'value="([^"]+)"\s+name="_csrf"', html)
    if match is None:
        raise ValueError("CSRF token not found")
    return match.group(1)

    #soup = BeautifulSoup(str, "html.parser")
    #csrf_input =soup.find("input",{"name":"_csrf"})
    #if csrf_input is None:
        #raise ValueError("CSRF token not found")
    #csrf_token = csrf_input.get("value")
    #print(f"\n成功获取动态 CSRF Token: {csrf_token}")


def login(api, username: str, password: str) -> None:
    """在传入的 APIRequestContext 上完成登录，Cookie 留在这个 context 里。"""
    # TODO 1: GET /login，打印 status（今天的 GET）
    response = api.get("/login")
    print("GET /login status =", response.status)
    html_text = response.text()

    # TODO 2: 取出 CSRF
    csrf_token = _extract_csrf(html_text)

    # TODO 3: POST /login，form={"username": ..., "password": ..., CSRF键: token}（今天的 POST）
    login_response = api.post(
        "/login",
        form={
            "username": username,
            "password": password,
            "_csrf": csrf_token,
        },
    )

    # TODO 4: 登录失败要看得出：url 仍带 /login 或 status 不对时，断言信息里写 scene
    # 默认会跟随 302，成功时常是最终 /dashboard 的 200，不要把成功写成必须 302。
    body = login_response.text()[:200]
    if login_response.status not in (200, 302):
        raise AssertionError(
            f"登录失败 scene=POST /login status={login_response.status} url={login_response.url} body={body!r}"
        )
    if "/login" in login_response.url:
        raise AssertionError(
            f"登录失败 scene=仍停在登录页 status={login_response.status} url={login_response.url} body={body!r}"
        )

    #response = api.get("/login")
    #html_text = response.text
    #csrf_token = _extract_csrf(html_text)
    #login_response =api.post("/login", data={"username": username, "password": password, "_csrf": csrf_token})
    #if login_response.statue !=302:
        #raise AssertionError(f"登录失败",login_response.status, login_response.url)
    #if "/login" in login_response.url"
        #raise AssertionError(f"登录失败，url 仍带 /login: {login_response.url}")
