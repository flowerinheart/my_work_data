"""pytest fixture。

session：playwright 进程、admin 已登录的 APIRequestContext（登录一次）。
function：未登录的 api_context（以后权限用例用，不要和 admin 串 Cookie）。

禁止：每条测试里 new_context 却不 dispose；禁止 chromium.launch。
"""

import pytest
from playwright.sync_api import sync_playwright

from api.auth_client import login
from config.settings import ADMIN_EMAIL, ADMIN_PASSWORD, BASE_URL


@pytest.fixture(scope="session")
def playwright_instance():
    # TODO: pw = sync_playwright().start()；yield pw；最后 pw.stop()
    pw = sync_playwright().start()
    yield pw
    pw.stop()
    #pw = sync_playwright().start();
    #yeild pw
    #pw.stop()


@pytest.fixture
def api_context(playwright_instance):
    """未登录。function 级，用完 dispose。"""
    # TODO: new_context(base_url=BASE_URL, ignore_https_errors=True)
    # HTTP 客户端在 playwright.request 上，不在 Playwright 根对象上。
    context = playwright_instance.request.new_context(
        base_url=BASE_URL,
        ignore_https_errors=True,
    )
    yield context
    context.dispose()
    #context = playwright_instance.new_context(base_url=BASE_URL, ignore_https_errors=True)
    #yeild context
    #context.dispose()


@pytest.fixture(scope="session")
def admin_api(playwright_instance):
    """已登录 admin。session 级，全场复用同一 Cookie 罐子。"""
    # TODO: new_context(...)
    login_context = playwright_instance.request.new_context(
        base_url=BASE_URL,
        ignore_https_errors=True,
    )
    # TODO: login(context, ADMIN_EMAIL, ADMIN_PASSWORD)
    login(login_context, ADMIN_EMAIL, ADMIN_PASSWORD)
    yield login_context
    login_context.dispose()
    #login_context = playwright_instance.new_context(base_url=BASE_URL, ignore_https_errors=True)
    #login_response = login(login_context,ADMIN_EMAIL,ADMIN_PASSWORD)
    #yeild login_context
    #login_context.dispose()
