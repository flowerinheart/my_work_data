# 被测环境。不要把密码再抄进每条测试。

BASE_URL = "http://localhost:8080"

ADMIN_EMAIL = "admin@erp.com"
ADMIN_PASSWORD = "Admin@1234"
