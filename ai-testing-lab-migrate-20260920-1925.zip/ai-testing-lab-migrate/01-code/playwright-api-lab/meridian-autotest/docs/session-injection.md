# 会话注入

对照：`api/auth_client.py`、`conftest.py`、`tests/api/test_login.py`。
被测：`http://localhost:8080`。账号：`admin@erp.com` / `Admin@1234`。

## 登录 URL 与字段

- GET 登录页：`http://localhost:8080/login`（代码里 `api.get("/login")`，`base_url` 已是 `http://localhost:8080`）
- POST 登录：同一个路径 `http://localhost:8080/login`（`api.post("/login", form=...)`）
- 表单字段名：`username`、`password`、`_csrf`
  - 邮箱填在 `username` 上，没有 `email` 这个 name
  - `form=` 发 `application/x-www-form-urlencoded`；Python Playwright 没有 `json=`，登录也绝不能用 `data=`（`data=字典` 会变成 JSON）

## CSRF 怎么取

- 从哪次响应里取：先 **GET `/login`**，从响应 **HTML 正文** 取，不是 Query 参数，也不是 JSON 字段。
- 用什么方式取：`html = response.text()`（必须调用 `text()`），再用正则匹配 hidden input：
  - `name="_csrf" value="..."` 或属性反序 `value="..." name="_csrf"`
- hidden 的 **name 就是 `_csrf`**
  - 模板里的 `_csrf.parameterName` 是 Thymeleaf/Spring 表达式，渲染后仍是 `name="_csrf"`。不要去匹配一个叫 `_csrf.parameterName` 的字段。

## 成功怎么判定

分两层，不要混到第 5 天的「200 + JSON code」。

1. **登录这一跳（`login()` 内部）**  
   Playwright 默认跟随 302。成功时常见是最终 `/dashboard` 的 **HTTP 200**，`url` 里不再带 `/login`。  
   不要把成功写成「必须 302」。  
   失败要看得出：`status` 不是 200/302，或 `url` 仍含 `/login`。`AssertionError` 里带 `scene`、status、url、body 前 200 字。

2. **会话真的注入了（冒烟用例）**  
   用已登录的 `admin_api` 再 **GET `/accounting/invoices`**：`status == 200` 且最终 url **不含** `/login`。  
   被踢回登录页 = Cookie 没建上。这才是「session 注入成功」的证据。

登录成功返回的是 HTML 页面，不是 `{"code": 0, "data": ...}`。那套 JSON 是第 5 天 `invoice_client.create()` 给测试看的适配层契约。

## Cookie 落在哪个对象上（不是 Bearer）

- 对象：Playwright 的 **`APIRequestContext`**。本工程里就是 fixture 交出的 `admin_api`（内部变量名 `login_context`）。
- 机制：`login(api, ...)` 在**传入的那个 context** 上 GET/POST。服务器 `Set-Cookie`（`JSESSIONID`）由 Playwright **自动存进这个 context 的 Cookie 罐**，后续 `admin_api.get(...)` 会自动带上。
- 不是：从 POST 响应里把 cookie 手工赋值给另一个对象；也不是请求头里的 `Authorization: Bearer ...`。
- 未登录罐是另一个 context：`api_context`（function 级）。两个罐子不能串。

## 第 8 天 hybrid 预告

今天只写思路，不要写 UI 代码。

会话凭证是 **Cookie（JSESSIONID）**，不是 CSRF。CSRF 是表单防伪，每次打开带表单的页面都会再发一个；不要把 CSRF token 塞进 `storage_state` 当登录态。

正确顺序：

1. API 侧已经用 `admin_api` 登录过，Cookie 已在这个 `APIRequestContext` 上。
2. 导出：`state = admin_api.storage_state()`（或写到 json 文件）。这里是**把当前 Cookie 倒出来**，不是把你拼的 CSRF JSON 传进去。
3. UI 侧：`browser.new_context(storage_state=state)`，或对新的 **`BrowserContext`** 做 `add_cookies(state["cookies"])`。
4. 然后 `page.goto` 列表/详情。`add_cookies` 属于浏览器 context，不是 `APIRequestContext` 的方法。
