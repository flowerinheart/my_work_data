# meridian-autotest

Pytest + Playwright `APIRequestContext`。第 4 天只做登录冒烟。

```powershell
cd C:\Users\hma\code\playwright-api-lab\meridian-autotest
..\.venv\Scripts\python.exe -m pytest tests\api\test_login.py --tb=short
```

被测：`http://localhost:8080` 必须已启动。
