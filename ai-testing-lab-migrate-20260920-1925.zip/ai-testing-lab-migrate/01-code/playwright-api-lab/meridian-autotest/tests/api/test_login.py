"""冒烟：登录后能打开发票列表。

GET  /login              → 未登录 context，页面 200
POST /login              → 在 admin_api fixture 里完成
GET  /accounting/invoices → 已登录，200，url 不是登录页

不要 assert resp.ok 当唯一契约；写 status == 200，失败信息带 url 和 body 前 200 字。
"""

import pytest


@pytest.mark.api
def test_login_page_get(api_context):
    # TODO: GET /login，断言 status == 200
    res = api_context.get("/login")
    body = res.text()[:200]
    assert res.status == 200, (
        f"打开登录页失败 status={res.status} url={res.url} body={body!r}"
    )
    #print("登陆失败”，res.status)
    #print("登陆失败”，res.url)
    #print("登陆失败”，res.text[:200])


@pytest.mark.api
def test_admin_invoice_list_get(admin_api):
    # TODO: GET /accounting/invoices
    # TODO: status == 200
    # TODO: 最终 url 不含 "/login"（被踢回登录页就是会话没建上）
    res = admin_api.get("/accounting/invoices")
    body = res.text()[:200]
    assert res.status == 200, (
        f"发票列表失败 status={res.status} url={res.url} body={body!r}"
    )
    assert "/login" not in res.url, (
        f"被踢回登录页 url={res.url} body={body!r}"
    )
    #response = admin_api.get("/login")
    #html_text = response.text
    #csrf_token = _extract_csrf(html_text)
    #login_response =api.post("/login", data={"username": username, "password": password, "_csrf": csrf_token})
    #if login_response.statue == 200:
        #raise AssertionError(f"登录失败",login_response.status, login_response.url)
    #if "/login" in login_response.url"
        #raise AssertionError(f"登录失败，url 仍带 /login: {login_response.url}")
    #res = admin_api.get("/accounting/invoices")
    #assert res.status == 200
    #if "/login" in res.url:
        #raise AssertionError(f"登录失败，url 仍带 /login: {res.url}")
