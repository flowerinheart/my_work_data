"""INV-CREATE-001：写接口成功 → 用返回 JSON 调查询。

断言：
- create 的 code == 0
- data.id / data.invoiceNumber 来自返回值
- get_by_id(data.id) 的 id、发票号与 create 一致
- status 为 DRAFT，号码匹配 INV- 加 4 位数字
- 不要 assert Location，不要 assert resp.ok 覆盖一切
"""

import pytest

from api.invoice_client import create, get_by_id


@pytest.mark.api
@pytest.mark.invoice
def test_create_then_query_same_id(admin_api):
    # TODO: fields 从已冒烟数据抄客户/行项目（不要 AutoTest_时间戳）
    # TODO: created = create(admin_api, fields)
    # TODO: 断言 code、id、invoiceNumber、DRAFT
    # TODO: detail = get_by_id(admin_api, created["data"]["id"])
    # TODO: 断言 detail["data"]["id"] == created["data"]["id"]
    # TODO: 手算 1 组 HALF_UP（subtotal × taxRate / 100，2 位），和详情能读到的税/合计对照；不要断言 Location
    raise NotImplementedError("写后读")
