# 第 1 天笔记

## 我理解的 APIRequestContext

`APIRequestContext` 是 Playwright 里发 HTTP 的客户端：用 `p.request.new_context()` 创建，里面有 `get()` / `post()` 等方法。它可以带 `base_url`，也可以对 `get()` 传入完整 URL。用完要 `dispose()`。

`p.request.new_context()` 会得到一套**独立 cookie 存储**，默认不和浏览器里的登录态共用。只有从已有的 `BrowserContext` 上取 `browser_context.request` 时，接口客户端才和那个浏览器共用 cookie。

## 它和 Page 的区别

- `APIRequestContext`：接口层，发 GET/POST，看 status、url、headers、text。今天这条路**不会弹出浏览器**。
- `Page`：UI 层，要先 `chromium.launch()` 得到 `Browser`，再 `browser.new_page()` 得到 `Page`，才能 `goto()`、点击。`launch()` 返回的是 Browser，不是 Page。
- 不写 `chromium.launch()`，就不会启动浏览器。没弹窗口是因为走了 request，不是因为 cookie 隔离。

## 今天踩到的坑

1. **编辑器改了但没保存**：终端跑的是磁盘旧文件。练习 A 仍打印 `status = TODO`；练习 C 请求成功但一行输出都没有（旧文件没有 `print`）。要先 `Ctrl + S`。
2. **JS 和 Python API 混用**：文档里 JS 是 `newContext()`，Python 必须 `new_context()`。
3. **只有路径 `/`、没有主机**：没有 `base_url` 时，`get("/")` 不知道打哪台机器。后来改成 `base_url="https://example.com"` 再 `get("/")`，或直接 `get("https://example.com")`。
4. **把 HTML 当 JSON**：`example.com` 返回 HTML。`response.json()` 会失败。看正文用 `response.text()`。
5. **拼写**：`reponse` 应为 `response`，否则 `NameError`。
6. **切片**：`text()[:200]` 是左闭右开，从下标 0 到 199，共 200 个字符；不是取「第 200 个字符」。`[2:4]` 是下标 2 和 3（第 3、第 4 个字符）。

## 第 2 天想继续搞清的问题

1. `form=`、`data=`、`json=` 三种 POST body，服务端看到的 Content-Type 有什么不同。
2. 同一 `APIRequestContext` 连续两次请求，Set-Cookie 会不会自动带上第二次。

## 面试收口（第 1 天，对着说一遍）

接口自动化走 Playwright 的 `request` 客户端，不 `launch` Chromium。`APIRequestContext` 发 HTTP；`Page` 是 UI 对象。没弹浏览器是因为根本没开 Browser，不是因为 Cookie 隔离。

