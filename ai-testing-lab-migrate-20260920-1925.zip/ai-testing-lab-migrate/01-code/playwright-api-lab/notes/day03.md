# 第 3 天笔记

今天核心就一件事：**断言写 `status`，不要写 `ok`。** 200、302、403 都用同一套 `assert_status(resp, 期望码, 场景)`。GET 和 POST 写法一样，POST 发票风格继续用 `form=`。

对照文件：`day03/assert_http.py`、`practice_a_status_200.py`、`practice_b_redirect_302.py`、`practice_c_403.py`。练习 B 讲解：`day03/redirect-302-explained.html`。

## ok 和 status 的区别

`resp.status` 是真实 HTTP 状态码（200 / 302 / 403 …）。

`resp.ok` 只是「status 在 200–299 吗」的布尔值：

| status | ok | 能不能用 `assert resp.ok` 当断言 |
|---|---|---|
| 200 | True | 碰巧能过，但失败信息没有「期望 200」 |
| 302 | False | 会失败。保存成功本来就是 302，用 ok 等于把成功当失败 |
| 403 | False | 会失败，但报错里没有「期望 403」 |

所以：`ok` 只能当调试打印；契约断言一律 `status == 期望码`。练习 A 打印过 `GET ok = True status = 200`；练习 C 打印过 `GET ok = False status = 403`。同一条规则，码不同。

## 不跟随重定向时我看到的 302 / Location

`REDIRECT` **不是** Playwright 内置变量，只是自己写的路径常量：

`"/redirect-to?url=/get&status_code=302"`

拼上 `base_url` 就是：请 httpbin 回 302，并把下一跳写在 **Location 响应头**里（指向 `/get`）。Location 不是请求体，也不是 httpbin JSON 里那个 `headers` 回显。读法：`resp.headers.get("location")`（key 一般小写）。

默认 `APIRequestContext` **会跟随** 302：自动再去请求 Location。第一跳的 302 被吃掉，你拿到的往往是最终 200。

`max_redirects=0` = 最多再跳 0 次 = **停在第一跳**。这时才能断言 302，并读 Location。

不跟随（`api.get(REDIRECT, max_redirects=0)` 或 POST 同样加这个参数）时：

- `status` = 302
- `response.url` = **你第一次请求的地址**（redirect-to 那条），不是下一跳
- `headers.get("location")` = 服务器让你去的下一跳（如带 `/get`）

发票 `POST /save` 成功就是这种：先 302，Location 里带详情 uuid。测契约必须停住，不能默认跟随。

## 跟随重定向后 url 变成了什么

`api.get(REDIRECT)` 不写 `max_redirects`，默认跟随。拿到的是**跳完以后**的那一跳：

- `status` 常常是 200（`/get` 的结果）
- `response.url` 变成**最终到达**的地址，里面应出现 `/get`
- 这时再断言 302 会失败，因为 302 已经不是当前这条 response 了

两个 url 别混：不跟随看 `response.url`（请求地址）+ Location（下一跳）；跟随看 `response.url`（最终地址）。

## 403 时如果写 assert resp.ok 会怎样

403 时 `ok` 已经是 False，`assert r_get.ok` 会立刻失败。失败信息大致是「断言 True 失败」，**没有「期望 403」**，也没有 url / body 摘要。权限用例要的是「明确 403」，不是「随便一个非 2xx」。

正确写法：`assert_status(r_get, 403, "无权限 GET")`（POST 同理）。练习 C 实测：`ok = False`、`status = 403`，helper 不报错。

## GET 和 POST 是否同一套断言

是。都调用 `assert_status`，只换期望码和 scene 字符串：

- 200：`assert_status(..., 200, "健康检查 GET/POST")`
- 302：`assert_status(..., 302, "重定向 GET/POST")`，且必须 `max_redirects=0`
- 403：`assert_status(..., 403, "无权限 GET/POST")`，禁止 `assert resp.ok`

helper 在 `actual != expected` 时把 scene、期望码、实际码、`resp.url`、body 前 200 字打进失败信息。body 用 `resp.text()[:200]`，读失败就 `"<no body>"`。

POST 今天统一 `form={"title": "INV"}`，和以后 Meridian 发票 save 同一类 body。

## 今天的坑

1. **`ok` 覆盖一切**：200 碰巧能过；302 / 403 语义全错。面试就讲这句。
2. **默认跟随会把 302 吃掉**：不写 `max_redirects=0` 时，你看到的是最终 200 和最终 url，误以为保存接口返回 200。
3. **`response.url` 不是 Location**：不跟随时 url 是当前请求地址，下一跳在 Location 头里。
4. **`assert_http.py` 要能被练习脚本 import**：在仓库根目录跑，并设 `$env:PYTHONPATH` 指向 `day03`。路径写成 `..\ .venv`（中间多空格）会找不到解释器。
5. **练习 C 跳过了「先写 `assert r_get.ok`」那一步**：功能对了，但没亲眼看过那种不含「期望 403」的报错。回头补看一次 traceback 更牢。
6. **注释掉的 `assert` / `expect` / `raise` 是语法对照，不要删。**
7. 失败信息字符串里 `expected` / `actual` / `scene` 之间最好加空格或分隔符，真失败时才好读；不影响今天绿的那几次运行。

## 面试收口（第 3 天，对着说一遍）

契约看 `status`，不看 `ok`。保存成功期望 302 加 Location，不是 200 JSON。默认跟随会把 302 吃掉，所以 `max_redirects=0`。`response.url` 是当前请求地址，下一跳在 Location 头。403 时 `ok` 是 False，仍要断言 `status == 403`，失败信息带场景、url、body 摘要。

