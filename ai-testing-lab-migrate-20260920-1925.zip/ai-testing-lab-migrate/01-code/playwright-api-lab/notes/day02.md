# 第 2 天笔记

## json / form / data 我观察到的 Content-Type

Python Playwright 的 `post()` **没有 `json=` 参数**（那是 JS 写法）。

1. `data={"title": "INV"}`（传字典）→ 请求头 `Content-Type: application/json`，httpbin 回显在 `json()["json"]` → `{'title': 'INV'}`
2. `form={"title": "INV"}` → `application/x-www-form-urlencoded`，回显在 `json()["form"]`。**Meridian 发票 save 走这种。**
3. `data="raw-body"`（传字符串）→ `application/octet-stream`，回显在 `json()["data"]` → `'raw-body'`

路径必须是 `POST /post`。打到 `POST /` 会 405，响应体不是 JSON，`.json()` 会炸。

## Header：请求头 vs 响应头 vs 回显

一次 HTTP 有四块：请求头、请求体、响应头、响应体。它们不会混在同一段「头」里。

- `response.headers`：真正的 **响应头**。Playwright 里 key 一般小写。httpbin 返回 JSON，所以常见 `content-type: application/json`。
- `response.json()["headers"]`：httpbin 把 **这次请求头抄进响应体 JSON**，方便调试，不是协议规定的响应头。
- `extra_http_headers={"X-Test-Day": "2"}` 加在 context 上，**GET 和 POST 都会带**。
- 回显里取 `Content-Type` 要用 httpbin 的键名（大写 C）；取响应头用 `response.headers.get("content-type")`。键名大小写不一致时 `.get` 会得到 `None`。

## 同一 context 的 Cookie

`GET /cookies/set?day02=playwright` 会被跟到 `/cookies`，Set-Cookie 进入这个 `APIRequestContext` 的罐子。

- 之后同一 `api` 的 `GET /cookies` 能看到 `day02`
- 之后同一 `api` 的 `POST /post`，回显请求头里有 `Cookie: day02=playwright`
- `api.storage_state()["cookies"]` 要在 set **之后**打印。每条 cookie 是字典：`cookie["name"]`、`cookie["value"]`

## 新 context 的 Cookie

再 `new_context()` 得到空罐子：GET `/cookies` 为空，POST 回显里没有 `Cookie` 头（`.get("Cookie")` 为 `None`）。隔离的是客户端，不是「整个 Python 进程一份 Cookie」。

## 今天的坑

1. 按 JS 文档写了 `json=`，Python 报 `unexpected keyword argument 'json'`。发 JSON 用 `data=字典`。
2. 打印错了响应对象：TODO2/TODO3 仍读第一次的 `response_json`，form 变成 `{}`，data 变成第一次的 JSON 串。要用每次自己的 `response_form` / `response_data`。
3. 编辑器改了没保存，终端还在跑旧文件。
4. `TODO` 只是占位字符串，不会让程序停住；`print("TODO: ...")` 会原样打出这几个字。
5. httpbin 证书错误：`ignore_https_errors=True`。
6. 中文逗号 `，` 不能当 Python 参数分隔符，要用英文 `,`。
7. `print(res.json())["headers"]` 括号关早了，变成对 `print` 的返回值取下标。

## 面试收口（第 2 天，对着说一遍）

Python Playwright 没有 `json=`，字典走 `data=` 才是 JSON。Meridian 发票 save 必须 `form=`（`application/x-www-form-urlencoded`）。Cookie 活在某一个 `APIRequestContext` 里；新 `new_context()` 是空罐子。权限用例要第二个 context，不能串 Cookie。

