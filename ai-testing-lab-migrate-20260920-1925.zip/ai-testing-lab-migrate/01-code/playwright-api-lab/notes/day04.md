# 第 4 天笔记

对照：`meridian-autotest/api/auth_client.py`、`conftest.py`、`tests/api/test_login.py`。

## fixture：session 登录 vs function 金数据回放

- `admin_api` 为什么用 session：登录一次，JSESSIONID 留在**同一个** `APIRequestContext` 里，整场 pytest 复用。后面发票用例只要拿 `admin_api`，不必每条测试再 POST `/login`。
- `api_context` 为什么用 function：每条测试新建一个**未登录** context，测完 `dispose`。用途是登录页冒烟、以及以后的 403/无 VIEW。不能让它继承 `admin_api` 的 Cookie，否则权限用例全是假绿。
- 金数据回放为什么不能和 admin 共用同一个 Cookie 罐子：
  - **不是因为** `dispose` 已经把 admin 的 Cookie 清掉了。`admin_api` 是 session 级，整场跑完才 `dispose`，测试之间 Cookie 一直在。
  - **是因为** 两个 `new_context()` = 两个 Cookie 罐。回放/权限要独立身份（VIEW-only 或干净会话），一旦借用 `admin_api`，请求已经是管理员，403 和「未登录」都测不了。

## 登录请求：字段、CSRF、成功怎么判定

- 字段：`username`、`password`、`_csrf`。邮箱填 `username`。POST 必须 `form=`。
- CSRF：GET `/login` 的 **HTML 正文**里，hidden `name="_csrf"`。`_csrf.parameterName` 是模板表达式，渲染后仍叫 `_csrf`。
- 成功判定：
  - `login()`：默认跟随后常见 200 + url 不含 `/login`（成功不是「必须 302」）。
  - 冒烟：`admin_api.get("/accounting/invoices")` → `status == 200` 且 url 不含 `/login`。
  - 今天登录**没有** JSON `code`。`200 + JSON code` 是第 5 天写发票适配层的事，不要写进登录成功条件。

## Cookie / JSESSIONID 落在哪个对象上

- 对象名：`APIRequestContext`（fixture：`admin_api` / 内部 `login_context`）。
- 和 Bearer Token 的差别：Meridian 是 Spring Session Cookie（`JSESSIONID`），后续请求由 context 自动带 Cookie。Bearer 是每次自己放 `Authorization` 头。本系统登录不是发 JSON 换 token。

## 今天有没有 context 泄漏或误 launch 浏览器

- 有没有 `chromium.launch`：没有。全程 `playwright.request.new_context`，不弹窗。
- `new_context` 之后有没有 `dispose`：有，写在 fixture 的 `yield` **之后**（session 结束或该条测试结束），不是「每发完一个 GET/POST 就 dispose」。若每条请求后就 dispose，`admin_api` 的登录 Cookie 会立刻没掉。

## 今天的坑

- `yeild` 不是 `yield`，fixture 根本交不出对象。
- HTTP 客户端在 `playwright_instance.request.new_context`，不是 `playwright_instance.new_context`（那是浏览器档案）。
- 登录 POST 用了 `data=` 会变成 JSON；页面要的是表单，必须 `form=`。
- `response.text` 是方法，要 `text()`；断言写成 `statue` 会 AttributeError。
- 默认跟随 302 之后看到的是 dashboard **200**，把成功断言成必须 302 会误杀。
- CSRF 用 BeautifulSoup 时传入了类型名 `str`，且没 import，取不到 token。
- 打印字符串用了中文弯引号，Python 语法直接断。
- 冒烟用例里不要再手写一遍登录；登录已在 `admin_api` 里完成，用例只 GET 列表。

## 面试收口（对着说一遍）

Pytest 从 `conftest` 拿 fixture，用例里不再手写 `sync_playwright()` 套娃。`admin_api` 是 session 级：表单 POST `/login`（`username` / `password` / `_csrf`）一次，JSESSIONID 落在这个 `APIRequestContext` 上，不是 Bearer。登录成功不能只看 302，默认跟随后常是 200；我用 GET `/accounting/invoices` 等于 200 且 url 不回 `/login` 证明会话在。未登录另用 function 级 context，Cookie 不串罐。今天不写 save：先把会话底座立住，发票写后读是第 5 天适配层的 200 + JSON `code` + `data.id`。
