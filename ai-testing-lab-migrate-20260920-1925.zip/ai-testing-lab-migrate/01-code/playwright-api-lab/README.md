# Playwright 接口自动化学习区

这是 **10 天技能课** 的工作区，对应：

`ai-testing-learning-lab/docs/playwright-api-knowledge-and-8h-plan.html`

## 和别的目录怎么分

| 目录 | 干什么 | 本课用不用 |
|------|--------|------------|
| `playwright-api-lab`（这里） | Playwright 从零学接口自动化，写代码、记笔记 | **主学习区** |
| `ai-testing-lab-whiteboard` | Meridian ERP 九周计划白板（模板/Skill，不在这里写工具课） | 第 5 天起可参考你已写的 template，不要把 day01 练习塞进去 |
| `ai-testing-lab-evaluator` | 验证区 | 本课不进 |
| `meridian-erp` | 被测系统 | 第 1 天不用；第 5 天起才打本地 ERP |

不要在 `C:\Users\hma\code` 根目录乱放脚本。每天练习放在 `day01/`、`day02/` …

## 今天

先看 `day01/TODAY.md`，按步骤做。
