"""练习 C：把响应看清楚。

要求打印三行：
1. status
2. 最终 url（response.url）
3. 正文前 200 个字符（response.text()[:200]）

运行：
    python day01/practice_c_status.py
"""

from playwright.sync_api import sync_playwright


def main():
    with sync_playwright() as p:
        api = p.request.new_context(base_url = "https://example.com")
        # 用一个完整 URL，不设 base_url 也可以
        response = api.get("/")

        # TODO: 按上面三行要求打印。不要只打印 "ok"
        print("status = ", response.status)
        print("url = ",response.url)
        print(response.text()[:200])
        api.dispose()


if __name__ == "__main__":
    main()
