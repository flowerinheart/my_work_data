"""AI 第一稿（故意写肥）：请删掉所有浏览器相关代码，只保留 API GET。

练习要求：
1. 对照 Playwright 文档：接口走 APIRequestContext，不要 launch Chromium。
2. 删掉 browser / page / goto / wait_for_timeout。
3. 保留 sync_playwright、request.new_context、get、打印 status、dispose。
4. 改完运行：
    python day01/ai_overgenerated_demo.py
   应打印 200，且不弹出浏览器。
"""

from playwright.sync_api import sync_playwright


def main():
    with sync_playwright() as p:
        api = p.request.new_context(base_url="https://example.com")
        response = api.get("/")
        print("status =", response.status)

        api.dispose()


if __name__ == "__main__":
    main()
