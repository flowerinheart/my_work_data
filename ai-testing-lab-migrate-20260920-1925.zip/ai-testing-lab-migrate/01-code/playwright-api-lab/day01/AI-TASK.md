# 第 1 天补做：AI 生成后审查

计划原文：让 Cursor 根据官方文档写最小 demo，你对照文档删掉多余 browser 代码。

`ai_overgenerated_demo.py` 模拟「AI 分不清 Page 和 request、把浏览器也写进来」的初稿。

你要做的：

1. 打开该文件，删掉所有 UI 相关代码。
2. 留下：`new_context` → `get("/")` → 打印 `status` → `dispose()`。
3. 跑通且不 `launch`。
4. 在 `notes/day01.md` 末尾加一句：AI 多写了什么、你删了什么。
