"""练习 B：对比「接口客户端」和「浏览器」。

先只完成 PART 1。PART 2 是选做，用来亲眼看到两种对象不一样。
运行：
    python day01/practice_b_no_browser.py
"""

from playwright.sync_api import sync_playwright


def part1_api_only():
    with sync_playwright() as p:
        api = p.request.new_context(base_url="https://example.com")
        response = api.get("/")
        print("PART1 API status =", response.status)
        print("PART1 没有 launch 浏览器。")
        api.dispose()


def part2_browser_optional():
    """选做：只有当你想对比时才取消下面的注释并运行。

    你会看到 Chromium 窗口或无头浏览器启动，这和 PART1 不是同一条路。
    今天的接口课默认不要走这条。
    """
    # from time import sleep
    # with sync_playwright() as p:
    #     browser = p.chromium.launch(headless=False)
    #     page = browser.new_page()
    #     page.goto("https://example.com")
    #     print("PART2 Page title =", page.title())
    #     sleep(2)
    #     browser.close()
    print("PART2 未启用（今天正确）。")


if __name__ == "__main__":
    part1_api_only()
    part2_browser_optional()
