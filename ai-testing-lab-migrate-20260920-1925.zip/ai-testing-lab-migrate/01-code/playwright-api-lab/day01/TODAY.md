# 第 1 天：环境 + 第一个不启浏览器的 GET

目标结束时你能自己说清三句话：

1. 接口自动化可以不打开 Chromium。
2. `APIRequestContext` 负责发 HTTP；`Page` 负责操作网页，今天不用 Page。
3. 你会看 `status` 和响应正文的前几行。

预计：环境 2～3 小时（本机还没有 Python），概念 + 练习 3 小时，笔记 1 小时。

## 步骤清单（按顺序勾）

- [x] 0. 确认在 `playwright-api-lab` 目录学习
- [x] 1. 安装 Python 3.12+，终端能跑 `python --version`
- [x] 2. 建立虚拟环境并安装 `pytest`、`playwright`
- [x] 3. 读完「两个对象」说明，口头复述
- [x] 4. 完成 `practice_a_first_get.py` 的 TODO，跑通
- [x] 5. 完成 `practice_b_no_browser.py`：证明没有启动浏览器
- [x] 6. 完成 `practice_c_status.py`：打印 status / url / 正文前 200 字
- [x] 7. 写 `notes/day01.md`：三个坑 + 明天要问的问题
