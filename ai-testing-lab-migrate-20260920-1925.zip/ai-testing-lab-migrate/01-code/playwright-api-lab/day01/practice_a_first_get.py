"""练习 A：发出今天第一个 GET。

规则：
- 不要使用 playwright.chromium.launch()
- 不要使用 page.goto()
- 用 request.new_context() 发 HTTP

把下面 4 个 TODO 自己补全后运行：
    python day01/practice_a_first_get.py
"""

from playwright.sync_api import sync_playwright


def main():
    with sync_playwright() as p:
        # TODO 1: 用 p.request.new_context() 创建一个 API 客户端，变量名 api
        # 提示：可以带 base_url="https://example.com"
        api = p.request.new_context()
        url = 'https://example.com'# 改这里

        # TODO 2: 调用 api.get("/") ，把返回值赋给 response
        response = api.get(url)

        # TODO 3: 打印 response.status
        print("status =",response.status)
        print("text=",response.text())
       
        # TODO 4: 调用 api.dispose() 释放客户端（写在打印后面）
        print("练习 A 若能打印出 200，说明 GET 已发出。")
        api.dispose()


if __name__ == "__main__":
    main()
