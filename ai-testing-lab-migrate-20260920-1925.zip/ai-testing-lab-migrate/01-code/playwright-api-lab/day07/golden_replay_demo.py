"""第 7 天 Demo：金数据回放 + 200 JSON 写后读 + 幂等 / 并发。

不连 Meridian。步骤按企业 REST 口径：
  POST JSON → HTTP 200 + code=0 + data.id
  → GET /invoices/{id} 或 query(invoiceNumber=上一响应当入参)

对照讲解：
  day07/idempotency-concurrency-explained.html
  day05/json-write-then-read-explained.html
对照规则：RULE-TEST-012、补丁 RULE-TEST-007 / 016

运行（仓库根目录）：
    .\\.venv\\Scripts\\python.exe day07\\golden_replay_demo.py
"""

from __future__ import annotations

import io
import sys
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
from decimal import Decimal, ROUND_HALF_UP
from threading import Barrier, Lock
from time import sleep
from uuid import uuid4

if hasattr(sys.stdout, "buffer"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")


class JsonResponse:
    """形状对齐 Playwright APIResponse：status + json()。"""

    def __init__(self, status: int, payload: dict) -> None:
        self.status = status  # HTTP 状态
        self._payload = payload

    def json(self) -> dict:
        return self._payload

    @property
    def ok(self) -> bool:
        return 200 <= self.status < 300


class FakeErpDb:
    def __init__(self) -> None:
        self.invoices: list[dict] = []  # acc_invoices 行
        self.items: list[dict] = []  # acc_invoice_items 行
        self._number_lock = Lock()

    def snapshot(self) -> dict:
        return {"invoices": deepcopy(self.invoices), "items": deepcopy(self.items)}

    def restore(self, snap: dict) -> None:
        self.invoices = deepcopy(snap["invoices"])
        self.items = deepcopy(snap["items"])

    def count_invoices(self) -> int:
        return len(self.invoices)

    def next_invoice_number_unlocked(self) -> str:
        # 对齐 Meridian：count()+1，无锁并发会重号
        count = len(self.invoices)
        return f"INV-{count + 1:04d}"

    def insert_invoice(self, payload: dict, invoice_number: str) -> dict:
        header = {
            "id": str(uuid4()),
            "invoice_number": invoice_number,
            "customer_name": payload["customer_name"],
            "tax_rate": payload["tax_rate"],
            "discount": payload["discount"],
            "status": "DRAFT",
            "subtotal": payload["expected_subtotal"],
            "tax_amount": payload["expected_tax_amount"],
            "total": payload["expected_total"],
        }
        self.invoices.append(header)
        for line in payload["lines"]:
            self.items.append(
                {
                    "id": str(uuid4()),
                    "invoice_id": header["id"],
                    "description": line["description"],
                    "quantity": line["quantity"],
                    "unit_price": line["unit_price"],
                    "line_total": line["line_total"],
                }
            )
        return header

    def find_by_id(self, invoice_id: str) -> dict | None:
        return next((row for row in self.invoices if row["id"] == invoice_id), None)

    def find_by_number(self, invoice_number: str) -> dict | None:
        return next((row for row in self.invoices if row["invoice_number"] == invoice_number), None)


def half_up_tax(subtotal: Decimal, tax_rate: Decimal) -> Decimal:
    return (subtotal * tax_rate / Decimal("100")).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def seed_smoke_passed_db() -> FakeErpDb:
    """测试库里已经冒烟通过的行，不是脚本现场编的。"""
    db = FakeErpDb()
    line_total = Decimal("25000.00")
    tax_rate = Decimal("15.00")
    discount = Decimal("0.00")
    tax_amount = half_up_tax(line_total, tax_rate)
    total = line_total + tax_amount - discount
    header = {
        "id": "golden-uuid-beximco",
        "invoice_number": "INV-0001",
        "customer_name": "Beximco Group",
        "tax_rate": tax_rate,
        "discount": discount,
        "status": "DRAFT",
        "subtotal": line_total,
        "tax_amount": tax_amount,
        "total": total,
    }
    db.invoices.append(header)
    db.items.append(
        {
            "id": "golden-item-1",
            "invoice_id": header["id"],
            "description": "ERP License - Annual",
            "quantity": 1,
            "unit_price": Decimal("25000.00"),
            "line_total": line_total,
        }
    )
    return db


def load_golden_from_db(db: FakeErpDb, invoice_number: str) -> dict:
    """抽出重放开票字段。不带旧 id / 旧发票号。"""
    header = next(row for row in db.invoices if row["invoice_number"] == invoice_number)
    lines = [dict(item) for item in db.items if item["invoice_id"] == header["id"]]
    return {
        "customer_name": header["customer_name"],
        "tax_rate": header["tax_rate"],
        "discount": header["discount"],
        "lines": [
            {
                "description": item["description"],
                "quantity": item["quantity"],
                "unit_price": item["unit_price"],
                "line_total": item["line_total"],
            }
            for item in lines
        ],
        "expected_subtotal": header["subtotal"],
        "expected_tax_amount": header["tax_amount"],
        "expected_total": header["total"],
        "source_invoice_number": header["invoice_number"],
        "source_id": header["id"],
    }


def _to_data(row: dict) -> dict:
    return {
        "id": row["id"],
        "invoiceNumber": row["invoice_number"],
        "status": row["status"],
        "total": str(row["total"]),
    }


class FakeInvoiceApi:
    """企业口径：create 返回 200 JSON；get/query 用上一响应当入参。"""

    def __init__(self, db: FakeErpDb) -> None:
        self.db = db
        self._idem: dict[str, dict] = {}  # Idempotency-Key → data

    def create(
        self,
        payload: dict,
        *,
        idempotency_key: str | None = None,
        locked_number: bool = False,
        sleep_s: float = 0.05,
    ) -> JsonResponse:
        if idempotency_key and idempotency_key in self._idem:
            # To-Be：同一把钥匙重复到达，不二次 insert
            return JsonResponse(200, {"code": 0, "message": "OK", "data": self._idem[idempotency_key]})

        if locked_number:
            with self.db._number_lock:
                number = self.db.next_invoice_number_unlocked()
                row = self.db.insert_invoice(payload, number)
        else:
            number = self.db.next_invoice_number_unlocked()
            sleep(sleep_s)
            row = self.db.insert_invoice(payload, number)

        data = _to_data(row)
        if idempotency_key:
            self._idem[idempotency_key] = data
        return JsonResponse(200, {"code": 0, "message": "OK", "data": data})

    def get_by_id(self, invoice_id: str) -> JsonResponse:
        row = self.db.find_by_id(invoice_id)
        if row is None:
            return JsonResponse(404, {"code": 404, "message": "NOT_FOUND", "data": None})
        return JsonResponse(200, {"code": 0, "message": "OK", "data": _to_data(row)})

    def query(self, *, invoice_number: str) -> JsonResponse:
        row = self.db.find_by_number(invoice_number)
        if row is None:
            return JsonResponse(200, {"code": 0, "message": "OK", "data": None})
        return JsonResponse(200, {"code": 0, "message": "OK", "data": _to_data(row)})


def assert_write_then_read(api: FakeInvoiceApi, create_resp: JsonResponse) -> dict:
    """标准断言：200 + code + 用 data 当查询入参。"""
    assert create_resp.status == 200, create_resp.status
    body = create_resp.json()
    assert body["code"] == 0, body
    invoice_id = body["data"]["id"]
    invoice_no = body["data"]["invoiceNumber"]

    by_id = api.get_by_id(invoice_id)
    assert by_id.status == 200
    assert by_id.json()["data"]["id"] == invoice_id
    assert by_id.json()["data"]["invoiceNumber"] == invoice_no

    by_no = api.query(invoice_number=invoice_no)
    assert by_no.json()["data"]["id"] == invoice_id
    return body["data"]


def step_rollback_and_replay() -> None:
    print("\n=== STEP 1 金数据回放 + 写后读 ===")
    db = seed_smoke_passed_db()
    golden = load_golden_from_db(db, "INV-0001")
    print("金数据来源号码 =", golden["source_invoice_number"], "客户 =", golden["customer_name"])
    db.restore({"invoices": [], "items": []})
    print("回滚后主表条数 =", db.count_invoices())

    api = FakeInvoiceApi(db)
    created = api.create(golden, sleep_s=0)
    data = assert_write_then_read(api, created)
    print("POST /api/invoices → HTTP", created.status, "code", created.json()["code"])
    print("data.id =", data["id"], "≠ 金数据 id", golden["source_id"])
    print("data.invoiceNumber =", data["invoiceNumber"])
    print("GET /api/invoices/{data.id} 对得上；query(invoiceNumber=data.invoiceNumber) 对得上")
    print("金额是否等于金数据 total：", data["total"] == str(golden["expected_total"]))
    print("主表条数 =", db.count_invoices())


def step_idempotency_same_session() -> None:
    print("\n=== STEP 2 幂等：同一会话、同一金数据、连续两次 POST ===")
    print("幂等 = 同一业务请求重复到达，副作用仍是一次。钥匙常用 Idempotency-Key。")

    db = seed_smoke_passed_db()
    golden = load_golden_from_db(db, "INV-0001")
    db.restore({"invoices": [], "items": []})
    api_raw = FakeInvoiceApi(db)
    first = api_raw.create(golden, sleep_s=0)
    second = api_raw.create(golden, sleep_s=0)
    print("无钥匙：两次都 HTTP 200，条数 =", db.count_invoices(), "两个 id =", first.json()["data"]["id"], second.json()["data"]["id"])
    print("这是 As-Is（Meridian 新建没有幂等键）。记两条，不准改口成幂等通过。")

    db.restore({"invoices": [], "items": []})
    api_key = FakeInvoiceApi(db)
    a = api_key.create(golden, idempotency_key="save-once", sleep_s=0)
    b = api_key.create(golden, idempotency_key="save-once", sleep_s=0)
    print("有钥匙：两次 HTTP", a.status, b.status, "同一 id =", a.json()["data"]["id"] == b.json()["data"]["id"], "条数 =", db.count_invoices())
    print("这是 To-Be。面试讲：企业用幂等键，不是靠客户名撞车。")


def step_two_sessions_not_idempotency() -> None:
    print("\n=== STEP 3 两会话各 POST 一次（不是幂等） ===")
    db = seed_smoke_passed_db()
    golden = load_golden_from_db(db, "INV-0001")
    db.restore({"invoices": [], "items": []})
    api = FakeInvoiceApi(db)
    session_a = api.create(golden, sleep_s=0)
    session_b = api.create(golden, sleep_s=0)
    id_a = session_a.json()["data"]["id"]
    id_b = session_b.json()["data"]["id"]
    no_a = session_a.json()["data"]["invoiceNumber"]
    no_b = session_b.json()["data"]["invoiceNumber"]
    print("会话A", no_a, "会话B", no_b, "两个不同号码 =", no_a != no_b)
    print("查询入参必须用各自 JSON，不能拿 A 的 id 去断言 B。")
    assert api.get_by_id(id_a).json()["data"]["invoiceNumber"] == no_a
    assert api.get_by_id(id_b).json()["data"]["invoiceNumber"] == no_b
    print("不要把这个场景说成幂等测试。期望就是 2 条。")


def _concurrent_create(api: FakeInvoiceApi, golden: dict, barrier: Barrier, locked: bool) -> str:
    barrier.wait()
    resp = api.create(golden, locked_number=locked, sleep_s=0.05)
    return resp.json()["data"]["invoiceNumber"]


def step_concurrent_number_collision() -> None:
    print("\n=== STEP 4 并发：两个线程同时 count()+1 ===")
    db = seed_smoke_passed_db()
    golden = load_golden_from_db(db, "INV-0001")
    empty = {"invoices": [], "items": []}

    db.restore(empty)
    api = FakeInvoiceApi(db)
    barrier = Barrier(2)
    with ThreadPoolExecutor(max_workers=2) as pool:
        unlocked = list(pool.map(lambda _: _concurrent_create(api, golden, barrier, False), range(2)))
    print("无锁并发发出的号码 =", unlocked)
    if unlocked[0] == unlocked[1]:
        print("碰撞：两个 id 抢到同一 INV 号。这是发号缺陷，不是幂等成功。")
    else:
        print("这次没撞上（竞态不是每次必现）。算法仍是 count()+1，存在碰撞窗口。")

    db.restore(empty)
    api2 = FakeInvoiceApi(db)
    barrier2 = Barrier(2)
    with ThreadPoolExecutor(max_workers=2) as pool:
        locked = list(pool.map(lambda _: _concurrent_create(api2, golden, barrier2, True), range(2)))
    print("加锁后号码 =", locked, "唯一 =", locked[0] != locked[1])
    print("生产应 DB sequence / 唯一约束，不是线程锁。")


def main() -> None:
    step_rollback_and_replay()
    step_idempotency_same_session()
    step_two_sessions_not_idempotency()
    step_concurrent_number_collision()
    print("\n面试四句：金数据来自已冒烟库，先回滚再重放；写接口 200+JSON，查询入参来自 data；")
    print("幂等只讨论同一请求重复到达（幂等键）；两会话各一张期望两条；count()+1 并发有重号窗口。")


if __name__ == "__main__":
    main()
