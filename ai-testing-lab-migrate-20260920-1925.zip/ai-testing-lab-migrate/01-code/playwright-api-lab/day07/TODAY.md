# 第 7 天：金数据回放 + 幂等 / 并发

今天**不学造数工厂**，不写 `unique_customer_name()`，不做付款扩展。

目标结束时你能自己说清：

1. 数据来自库里已冒烟通过的单据，先回滚再重放开票。
2. 写接口：HTTP 200 + JSON `code` 成功；查询入参来自 `data.id` / `data.invoiceNumber`。
3. **幂等**只适用于同一请求重复到达（幂等键）；两会话各开一张**不是**幂等。
4. `count()+1` 发号在并发下有重号窗口。

讲解：

- [幂等 / 并发 / 金数据](idempotency-concurrency-explained.html)
- [写后读 200 JSON](../day05/json-write-then-read-explained.html)

Demo：`golden_replay_demo.py`（内存假库，不连 Meridian）

## 步骤

- [ ] 1. 读两份 HTML，把造数 vs 金数据、302 跳转 vs 200 JSON 写后读的差别说给自己听
- [ ] 2. 跑 Demo，对照四个 STEP 的打印
- [ ] 3. 打开 `meridian-erp` 里 `InvoiceService.nextInvoiceNumber()`，对照 STEP 4
- [ ] 4. 填 `notes/day07.md`，把面试收口对着说一遍

pytest markers / AI 审查挪到第 8 天上午。

## 运行

```powershell
cd C:\Users\hma\code\playwright-api-lab
.\.venv\Scripts\python.exe day07\golden_replay_demo.py
```
