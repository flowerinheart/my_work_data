# 第 5 天：发票新建正向 + 金额（200 JSON 写后读）

讲解：[json-write-then-read-explained.html](json-write-then-read-explained.html)

今天目标：

1. `invoice_client.create(api, fields)` 对外返回  
   `{"code": 0, "data": {"id": "...", "invoiceNumber": "INV-xxxx", "status": "DRAFT"}}`
2. 查询入参**只能**用上一步的 `data.id` / `data.invoiceNumber`，禁止手填旧单号
3. 至少 1 组金额 HALF_UP 手算，和查询结果（或详情页能读到的数）对照
4. 用例里**不要**断言 Location / 302

Meridian 页面提交仍可能是表单。适配层可以内部 POST `/accounting/invoices/save`，但 `create()` 给测试的必须是上面那套 JSON 语义。

登录继续用 session 级 `admin_api`。保存页也有 CSRF：先 GET `/accounting/invoices/new` 再 POST。字段对齐 `InvoiceForm`：`customerName`、`issueDate`、`dueDate`、`taxRate`、`discount`、`items[0].description` / `quantity` / `unitPrice`。`id` 空着才是新建。

客户、行项目优先从库里已有冒烟票抄字段（第 7 天会系统做回放）；今天不要发明时间戳客户名当主路径。

## 步骤

- [ ] 1. 读讲解 HTML
- [ ] 2. 填 `meridian-autotest/api/invoice_client.py` 的 TODO
- [ ] 3. 填 `tests/api/test_invoice_create.py`
- [ ] 4. 跑：`pytest tests/api/test_invoice_create.py --tb=short`
- [ ] 5. 填 `notes/day05.md` 面试收口

今天不做：403、hybrid、幂等。

```powershell
cd C:\Users\hma\code\playwright-api-lab\meridian-autotest
..\.venv\Scripts\python.exe -m pytest tests\api\test_invoice_create.py --tb=short
```
