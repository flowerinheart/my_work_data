# 第 4 天：Pytest 工程骨架 + Meridian 登录

课表：`ai-testing-learning-lab/docs/playwright-api-knowledge-and-8h-plan.html` 第 4 天。
今天 = 原 Playwright 第 4～5 天 + 九周第 4 周 Day 1。
面试口述今晚写进 `notes/day04.md`，不要留到第 8 天。

目标结束时你能自己说清：

1. pytest 从 `conftest.py` 拿 fixture，用例里不再手写 `sync_playwright()` 套娃。
2. `session` 级登录 vs `function` 级金数据回放。
3. Meridian 登录是**表单 POST + Session Cookie**，不是 Bearer Token。
4. 登录成功的判定：GET `/accounting/invoices` 为 200，且不是登录页。

被测：`http://localhost:8080`，账号 `admin@erp.com` / `Admin@1234`。
工程目录：本仓库 `meridian-autotest/`（今天建）。今天**不要** `chromium.launch()`，**不要**写发票 save。

## 步骤

- [ ] 0. 浏览器打开 `http://localhost:8080/login`，确认能手工登录（Meridian 必须已启动）
- [ ] 1. 读课表第 4 天「块 A / 块 B / 面试收口」
- [ ] 2. 建 `meridian-autotest/` 目录：`config/` `api/` `pages/` `tests/api/` `tests/hybrid/` `docs/`
- [ ] 3. 写 `pytest.ini`：`testpaths`、`markers` 至少先声明 `api`
- [ ] 4. 写 `config/settings.py`：`BASE_URL`、admin 账号
- [ ] 5. 写 `api/auth_client.py`：登录（先看登录页有没有 CSRF hidden，有就带上）
- [ ] 6. 写 `conftest.py`：`api_context`（未登录）→ `admin_api`（已登录，session）
- [ ] 7. 写 `tests/api/test_login.py`：登录后 GET `/accounting/invoices`，断言 200
- [ ] 8. 仓库根或 `meridian-autotest` 下跑通：`pytest tests/api/test_login.py --tb=short`
- [ ] 9. 写 `docs/session-injection.md`：URL、字段、成功判定、Cookie 以后怎么给 hybrid
- [ ] 10. 填 `notes/day04.md`（含面试收口），对着说一遍

## 运行（在 meridian-autotest 目录）

```powershell
cd C:\Users\hma\code\playwright-api-lab\meridian-autotest
..\.venv\Scripts\python.exe -m pytest tests\api\test_login.py --tb=short
```

`..\.venv` 中间不能有空格。若你习惯在仓库根目录跑，把 `pytest.ini` 的 `testpaths` 指到 `meridian-autotest`，或 `cd` 进子目录再跑。

## 检查有没有踩这些坑

- 每条测试里又 `new_context` 却不 `dispose`
- 写了 `chromium.launch`
- POST JSON 登录（字段应对齐登录页 form）
- 把 302 跟随后的登录跳转误当成失败，或反过来没检查是否仍停在 `/login`
