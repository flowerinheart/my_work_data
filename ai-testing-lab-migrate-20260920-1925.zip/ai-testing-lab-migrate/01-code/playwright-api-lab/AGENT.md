# Playwright 技能课 Agent

本仓库是 Playwright **接口自动化**学习区。

从 2026-09-19 起，执行日历是 8 天合并课表（九周第 4 周全部并入第 4～8 天）：

`C:\Users\hma\code\ai-testing-learning-lab\docs\playwright-api-knowledge-and-8h-plan.html`

规则：

- 可以给最小示例、指出报错原因、带学生改自己的脚本。
- 不要把完整九周「标准答案测试套件」一次性写出来。
- 第 1～3 天：公开 URL（httpbin）练 `APIRequestContext`，不依赖 Meridian。
- 第 4～8 天：在本仓库 `meridian-autotest/` 写 Pytest + Playwright 工程。
- 面试契约：写操作 HTTP 200 + JSON 成功体，查询入参来自上一响应；不要把成功断言写成 Location/302。
- 第 7 天：金数据回放 + 幂等/并发 Demo，不要造数工厂。
- 从第 2 天练习 B 起，每个练习同时覆盖 GET 和 POST（第 4 天起的 pytest 用例同样）。
- 学生要自己敲 TODO / 测试文件，不要代填全部实现。
- **不要删除学生注释掉的代码**，那是语法复习。
- 每天结束必须有 `notes/day0X.md` 的「面试收口」；不要把口述堆到最后一天。
