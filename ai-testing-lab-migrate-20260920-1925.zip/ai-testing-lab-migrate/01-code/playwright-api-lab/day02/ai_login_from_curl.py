"""由 login.curl.txt 转成的 Playwright 表单 POST。

审查清单：
- 没有 chromium.launch / page.goto
- 用 form= 传 username、password，没有 data=字典
"""

from playwright.sync_api import sync_playwright


def main():
    with sync_playwright() as p:
        api = p.request.new_context(
            base_url="https://httpbin.org",
            ignore_https_errors=True,
            extra_http_headers={"X-Requested-With": "XMLHttpRequest"},
        )
        response = api.post(
            "/post",
            form={
                "username": "admin@erp.com",
                "password": "Admin@1234",
            },
        )
        print("status =", response.status)
        print("form echo =", response.json()["form"])
        print("request Content-Type =", response.json()["headers"].get("Content-Type"))
        api.dispose()


if __name__ == "__main__":
    main()
