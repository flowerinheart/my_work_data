"""练习 A：同一种 POST，三种 body。

httpbin 会在 JSON 里回显：
- 你发的 JSON 业务体    -> 字段 "json"
- 你发的表单            -> 字段 "form"
- 你发的原始字符串      -> 字段 "data"
- 你这次请求的头        -> 字段 "headers"（这是回显，不是说你只传了请求头）

Python Playwright 发 JSON 用 data=字典，不要写 json=（没有这个参数）。
"""

from playwright.sync_api import sync_playwright


def main():
    with sync_playwright() as p:
        api = p.request.new_context(
            base_url="https://httpbin.org",
            ignore_https_errors=True,
        )
        url = "/post"

        response_json = api.post(url, data={"title": "INV"})
        print("TODO1 status", response_json.status)
        print("TODO1 json body", response_json.json()["json"])
        print("TODO1 Content-Type", response_json.json()["headers"].get("Content-Type"))

        response_form = api.post(url, form={"title": "INV"})
        print("TODO2 status", response_form.status)
        print("TODO2 form body", response_form.json()["form"])
        print("TODO2 Content-Type", response_form.json()["headers"].get("Content-Type"))

        response_data = api.post(url, data="raw-body")
        print("TODO3 status", response_data.status)
        print("TODO3 raw body", response_data.json()["data"])
        print("TODO3 Content-Type", response_data.json()["headers"].get("Content-Type"))

        api.dispose()


if __name__ == "__main__":
    main()
