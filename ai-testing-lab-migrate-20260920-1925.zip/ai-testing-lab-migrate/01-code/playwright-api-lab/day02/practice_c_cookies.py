"""练习 C：Cookie 是否自动带上（GET + POST）。

同一 APIRequestContext：
1. GET /cookies/set?day02=playwright  → 服务端 Set-Cookie
2. GET /cookies                      → JSON 里应有 day02
3. POST /post form={"title": "INV"}  → 回显 headers 里应带 Cookie
4. 新 context：GET /cookies 和 POST /post，都不应带 day02

运行：
    python day02/practice_c_cookies.py
"""

from playwright.sync_api import sync_playwright

BASE = "https://httpbin.org"


def main():
    with sync_playwright() as p:
        api = p.request.new_context(base_url = BASE, ignore_https_errors=True)

        # TODO 1: 同一 api GET /cookies ，打印 JSON
        response_get = api.get("/cookies/set?day02=playwright")
        print("SET GET status =",response_get.status)
        print("SET GET final url =",response_get.url)
        print("same context GET /cookies = ", response_get.json().get("cookies"))

        cookies = api.storage_state()["cookies"]
        for cookie in cookies:
            print("Cookie name=", cookie["name"], "value=", cookie["value"])


        # TODO 2: 同一 api POST /post ，form={"title": "INV"}
        # 打印 status、json()["form"]、json()["headers"].get("Cookie")
        response_post = api.post("/post", form ={"title": "INV"})
        print("Post status = ",response_post.status)
        print("same context POST Cookie header =", response_post.json()["headers"].get("Cookie"))


        # TODO 3: 打印 api.storage_state() ，看 cookies 里有没有 day02
        other_api = p.request.new_context(base_url = BASE,ignore_https_errors=True)

        res_get = other_api.get("/cookies")
        print("new context GET /cookies =", res_get.json().get("cookies"))

        cookies_other = other_api.storage_state()["cookies"]
        for cookie in cookies_other:
            print("new context Cookie name=", cookie["name"], "value=", cookie["value"])

        res_post = other_api.post("/post", form = {"title": "INV"})
        print("new context POST Cookie =", res_post.json()["headers"].get("Cookie"))

        api.dispose()
        other_api.dispose()


if __name__ == "__main__":
    main()
