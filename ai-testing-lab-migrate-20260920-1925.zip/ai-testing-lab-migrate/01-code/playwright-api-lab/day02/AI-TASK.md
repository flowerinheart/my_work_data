# 第 2 天补做：curl → Playwright form POST

计划原文：把浏览器里复制的登录 curl 丢给 Cursor，改成 Playwright post(form=)。

1. 打开 `login.curl.txt`
2. 在本对话把 curl 贴出来，加上约束（只要 API、只要 form=、不要浏览器）
3. 对 AI 写出的脚本做审查后再保存为 `day02/ai_login_from_curl.py`
4. 运行并看 httpbin 回显的 form 是否是 username / password
