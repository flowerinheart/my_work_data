"""练习 B：自定义请求头（GET + POST）。

分清两种 headers：
- response.json()["headers"]  → httpbin 回显的【请求头】（你发出去的）
- response.headers            → HTTP【响应头】（服务器回给你的，key 一般小写）

运行：
    python day02/practice_b_headers.py
"""

from playwright.sync_api import sync_playwright

BASE = "https://httpbin.org"


def main():
    with sync_playwright() as p:
        api = p.request.new_context(
            base_url=BASE,
            ignore_https_errors=True,
            extra_http_headers={"X-Test-Day": "2"},
        )

        # ---------- GET /headers ----------
        r_get = api.get("/headers")
        print("GET status =", r_get.status)
        print("GET echoed request headers =", r_get.json()["headers"])
        print("GET echoed X-Test-Day =",r_get.json()["headers"].get("X-Test-Day"))
        print("GET response content-type =",r_get.headers.get("content-type"))

        # ---------- POST /post（表单，和练习 A 的 form= 一样）----------
        # TODO: 用 form={"title": "INV"} POST 到 /post，变量名 r_post
        r_post = api.post("/post",form={"title":"INV"})

        print("POST status = ",r_post.status)
        print("POST echoed X-Test-Day = ",r_post.json()["headers"].get("X-Test-Day"))
        print("POST echoed Headers",r_post.json()["headers"])
        print("POST echoed Content-Type = ", r_post.json()["headers"].get("Content-Type"))
        print("POST form body =",r_post.json()["form"])
        print("POST response content-type = ", r_post.headers.get("content-type"))

        api.dispose()


if __name__ == "__main__":
    main()
