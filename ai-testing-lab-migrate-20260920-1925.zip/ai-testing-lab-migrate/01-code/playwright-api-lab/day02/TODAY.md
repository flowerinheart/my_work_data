# 第 2 天：POST body、Header、Cookie

目标结束时你能自己说清：

1. Python 里用 `data=字典`（JSON）、`form=`（表单）、`data=字符串`（原始 body）三种 POST。没有 `json=` 参数。
2. 怎么给 GET 和 POST 加自定义 Header；区分回显请求头和响应头。
3. 同一 context 里 Cookie 会不会自动出现在后续 **GET 和 POST** 上。

练习站：`https://httpbin.org`（会把你发的 body / header / cookie 原样回显）。
本机 HTTPS 可能报 `unable to get local issuer certificate`（公司代理证书）。创建 context 时加上 `ignore_https_errors=True`。练习文件里已带上这一项。若仍超时，把 `BASE` 改成 `https://httpbingo.org`。

## 步骤

- [x] 1. 读完下面「三种 body」说明
- [x] 2. 完成 `practice_a_three_bodies.py`
- [x] 3. 完成 `practice_b_headers.py`
- [x] 4. 完成 `practice_c_cookies.py`
- [x] 5. 把现象记进 `notes/day02.md`

今天仍然 **不要** `chromium.launch()`，仍然 **不要** 打 Meridian。
从练习 B 起，每个练习都要同时覆盖 **GET 和 POST**。
